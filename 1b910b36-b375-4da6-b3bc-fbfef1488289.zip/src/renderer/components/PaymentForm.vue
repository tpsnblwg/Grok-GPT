<template>
  <a-form :model="form" layout="vertical">
    <a-row :gutter="12">
      <a-col :xs="24" :md="12">
        <a-form-item label="虚拟卡卡号" field="cardNumber" required>
          <a-input v-model="form.cardNumber" placeholder="4242 4242 4242 4242" :max-length="23" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="CVV" field="cvv" required>
          <a-input-password v-model="form.cvv" placeholder="123" :max-length="4" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="过期时间 (MM/YY)" field="expiry" required>
          <a-input v-model="form.expiry" placeholder="12/28" :max-length="5" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="国家或地区" field="country" required>
          <a-select v-model="form.country" placeholder="选择国家或地区" allow-search>
            <a-option v-for="c in countries" :key="c.code" :value="c.code">{{ c.name }}</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="持卡人姓名" field="name">
          <a-input v-model="form.name" placeholder="Cardholder Name" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="邮箱" field="email">
          <a-input v-model="form.email" placeholder="billing@example.com" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="账单地址" field="address">
          <a-input v-model="form.address" placeholder="Street Address" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="邮编" field="zip">
          <a-input v-model="form.zip" placeholder="Postal Code" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="电话" field="phone">
          <a-input v-model="form.phone" placeholder="Phone" allow-clear />
        </a-form-item>
      </a-col>
    </a-row>

    <template v-if="unknownFields.length > 0">
      <a-divider orientation="left">页面要求其他字段</a-divider>
      <a-row :gutter="12">
        <a-col v-for="f in unknownFields" :key="f.key" :xs="24" :md="12">
          <a-form-item :label="f.label || '其他字段'">
            <a-input v-model="form.extra[f.key]" placeholder="选填" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
    </template>

    <a-alert type="warning" style="margin-bottom: 12px">
      支付信息仅用于本次填表，校验后立即使用，不写入日志、数据库或长期存储。
    </a-alert>

    <a-button type="primary" long :loading="loading" @click="emitSubmit">
      校验并生成填表预览
    </a-button>
  </a-form>
</template>

<script setup lang="ts">
import { computed, reactive } from 'vue';
import { Message } from '@arco-design/web-vue';
import type { PaymentField, PaymentPayload } from '@shared/runEvents';

const props = defineProps<{
  fields: PaymentField[];
  loading?: boolean;
}>();

const emit = defineEmits<{
  (e: 'submit', payload: PaymentPayload): void;
}>();

const countries = [
  { code: 'US', name: '美国 US' },
  { code: 'GB', name: '英国 GB' },
  { code: 'DE', name: '德国 DE' },
  { code: 'FR', name: '法国 FR' },
  { code: 'NL', name: '荷兰 NL' },
  { code: 'JP', name: '日本 JP' },
  { code: 'KR', name: '韩国 KR' },
  { code: 'BR', name: '巴西 BR' },
  { code: 'IN', name: '印度 IN' },
  { code: 'AU', name: '澳大利亚 AU' },
  { code: 'CA', name: '加拿大 CA' },
  { code: 'VN', name: '越南 VN' },
  { code: 'PH', name: '菲律宾 PH' },
  { code: 'SG', name: '新加坡 SG' },
  { code: 'HK', name: '香港 HK' }
];

const form = reactive<PaymentPayload>({
  cardNumber: '',
  cvv: '',
  expiry: '',
  country: '',
  name: '',
  email: '',
  address: '',
  zip: '',
  phone: '',
  extra: {}
});

const unknownFields = computed(() => props.fields.filter((f) => f.type === 'unknown'));

function emitSubmit() {
  const digits = form.cardNumber.replace(/\D/g, '');
  if (digits.length < 13 || digits.length > 19) {
    Message.warning('卡号长度应在 13-19 位数字之间');
    return;
  }
  if (!/^\d{3,4}$/.test(form.cvv.replace(/\D/g, ''))) {
    Message.warning('CVV 应为 3-4 位数字');
    return;
  }
  if (!/^(0[1-9]|1[0-2])\D?(\d{2})$/.test(form.expiry.trim())) {
    Message.warning('过期时间格式应为 MM/YY');
    return;
  }
  if (!form.country) {
    Message.warning('请选择国家或地区');
    return;
  }
  emit('submit', { ...form, extra: { ...form.extra } });
}
</script>
