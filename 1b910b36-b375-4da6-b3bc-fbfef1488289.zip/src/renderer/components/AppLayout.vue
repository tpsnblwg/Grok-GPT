<template>
  <a-layout class="app-shell">
    <a-layout-sider
      v-model:collapsed="collapsed"
      :width="200"
      :collapsed-width="60"
      collapsible
      breakpoint="lg"
      class="app-sidebar"
    >
      <div class="sidebar-brand">
        <span v-if="!collapsed" class="brand-title">grok-reg-tool</span>
        <span v-else class="brand-title brand-short">GRT</span>
      </div>
      <a-menu
        :selected-keys="[activeKey]"
        :collapsed="collapsed"
        class="sidebar-menu"
        @menu-item-click="onMenuClick"
      >
        <a-menu-item key="dashboard">
          <template #icon><icon-dashboard /></template>仪表盘
        </a-menu-item>
        <a-menu-item key="register">
          <template #icon><icon-play-circle /></template>Grok 注册机
        </a-menu-item>
        <a-menu-item key="gpt">
          <template #icon><icon-play-circle /></template>GPT 注册机
        </a-menu-item>
        <a-menu-item key="pool">
          <template #icon><icon-storage /></template>号池
        </a-menu-item>
        <a-menu-item key="update">
          <template #icon><icon-refresh /></template>更新
        </a-menu-item>
        <a-menu-item key="settings">
          <template #icon><icon-settings /></template>配置
        </a-menu-item>
      </a-menu>
      <div class="sidebar-footer">
        <template v-if="collapsed">
          <a-button size="mini" shape="circle" title="退出登录" @click="onLogout">
            <template #icon><icon-poweroff /></template>
          </a-button>
        </template>
        <template v-else>
          <span class="sidebar-user"><icon-user /> {{ auth.username }}</span>
          <a-button size="mini" status="danger" @click="onLogout">
            <template #icon><icon-poweroff /></template>退出
          </a-button>
        </template>
      </div>
    </a-layout-sider>

    <a-layout>
      <a-layout-header class="app-header">
        <h2 class="header-title">{{ currentTitle }}</h2>
        <a-space>
          <a-tag :color="phaseColor" size="large">
            <span class="status-dot" :style="{ background: phaseDotColor }"></span>{{ run.status.phase }}
          </a-tag>
          <a-button size="small" @click="toggleTheme">
            <template #icon>
              <icon-moon v-if="dark" />
              <icon-sun v-else />
            </template>
            {{ dark ? '深色' : '浅色' }}
          </a-button>
        </a-space>
      </a-layout-header>
      <a-layout-content class="app-main">
        <router-view />
      </a-layout-content>
    </a-layout>
  </a-layout>

  <a-modal
    v-model:visible="showChangePwd"
    title="首次登录需要修改账号密码"
    :footer="false"
    :mask-closable="false"
    :closable="false"
  >
    <a-form :model="pwdForm" layout="vertical">
      <a-form-item label="当前密码" field="currentPassword" :rules="[{ required: true, message: '请输入当前密码' }]">
        <a-input-password v-model="pwdForm.currentPassword" placeholder="当前密码" />
      </a-form-item>
      <a-form-item label="新用户名" field="username" :rules="[{ required: true, message: '请输入新用户名' }]">
        <a-input v-model="pwdForm.username" placeholder="新用户名" />
      </a-form-item>
      <a-form-item label="新密码" field="password" :rules="[{ required: true, message: '请输入新密码' }]">
        <a-input-password v-model="pwdForm.password" placeholder="新密码（至少 6 位）" />
      </a-form-item>
      <a-form-item label="确认密码" field="confirmPassword" :rules="[{ required: true, message: '请再次输入新密码' }]">
        <a-input-password v-model="pwdForm.confirmPassword" placeholder="确认密码" />
      </a-form-item>
      <a-button type="primary" long :loading="savingPwd" @click="submitPwd">保存并继续</a-button>
    </a-form>
  </a-modal>

  <a-modal
    v-model:visible="updateNotifyVisible"
    title="发现新版本"
    :ok-text="'前往更新'"
    cancel-text="稍后"
    @ok="goUpdate"
  >
    <a-space direction="vertical" fill>
      <a-space wrap>
        <a-tag color="green">新版本 v{{ updateNotify?.latest }}</a-tag>
        <a-tag v-if="updateNotify?.forceUpdate" color="red">强制更新</a-tag>
        <a-tag v-if="updateNotify?.source === 'auth'" color="arcoblue">授权系统源</a-tag>
      </a-space>
      <a-typography-text style="white-space: pre-wrap; font-size: 13px">
        {{ updateNotify?.updateLog || '暂无更新日志' }}
      </a-typography-text>
      <a-typography-text type="secondary" style="font-size: 12px">
        当前版本 v{{ updateNotify?.current }} → 最新版本 v{{ updateNotify?.latest }}
      </a-typography-text>
    </a-space>
  </a-modal>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { Message } from '@arco-design/web-vue';
import { api, onRegisterEvent } from '@renderer/api';
import { useAuthStore } from '@renderer/stores/auth';
import { useRunStore } from '@renderer/stores/run';
import { useAccountsStore } from '@renderer/stores/accounts';
import { useSettingsStore } from '@renderer/stores/settings';
import type { ChangeCredentialsInput, UpdateInfo } from '@shared/ipc';

const auth = useAuthStore();
const run = useRunStore();
const accounts = useAccountsStore();
const settings = useSettingsStore();
const route = useRoute();
const router = useRouter();

const dark = ref(localStorage.getItem('theme') === 'dark');
const collapsed = ref(false);

function applyTheme() {
  if (dark.value) {
    document.body.setAttribute('arco-theme', 'dark');
  } else {
    document.body.removeAttribute('arco-theme');
  }
  localStorage.setItem('theme', dark.value ? 'dark' : 'light');
}
function toggleTheme() {
  dark.value = !dark.value;
  applyTheme();
}

const titles: Record<string, string> = {
  dashboard: '仪表盘',
  register: 'Grok 注册机',
  gpt: 'GPT 注册机',
  pool: '号池',
  update: '在线更新',
  settings: '配置'
};
const currentTitle = computed(() => titles[String(route.name)] || 'grok-reg-tool');
const activeKey = computed(() => String(route.name));

function onMenuClick(key: string) {
  router.push({ name: key });
}

const phaseColor = computed(() => {
  switch (run.status.phase) {
    case 'running':
    case 'starting':
      return 'orange';
    case 'error':
      return 'red';
    case 'done':
      return 'green';
    case 'killed':
      return 'gray';
    default:
      return 'arcoblue';
  }
});
const phaseDotColor = computed(() => {
  switch (run.status.phase) {
    case 'running':
    case 'starting':
      return '#ff7d00';
    case 'error':
      return '#f53f3f';
    case 'done':
      return '#00b42a';
    default:
      return '#86909c';
  }
});

async function onLogout() {
  await auth.logout();
  router.push({ name: 'login' });
}

onMounted(() => {
  applyTheme();
  api
    .getStatus()
    .then((s) => run.setStatus(s))
    .catch(() => undefined);
  onRegisterEvent((event) => {
    run.applyEvent(event);
    if (event.type === 'account') accounts.applyAccount(event.record);
  });
  void settings.reload().catch(() => undefined);
  // 在线更新检测：打开页面立即检测一次，之后每 60 秒轮询
  void pollUpdate();
  updateTimer = window.setInterval(() => { void pollUpdate(); }, 60 * 1000);
});

onBeforeUnmount(() => {
  if (updateTimer) window.clearInterval(updateTimer);
});

// ===== 在线更新自动检测与弹窗 =====
const updateNotifyVisible = ref(false);
const updateNotify = ref<UpdateInfo | null>(null);
let updateTimer: number | null = null;
let lastNotifiedUpdate: string | null = null;

async function pollUpdate() {
  try {
    const info = await api.checkUpdate();
    // 有更新且是该版本第一次通知时弹窗，避免每 60 秒重复打扰
    if (info?.hasUpdate && info.latest && info.latest !== lastNotifiedUpdate) {
      updateNotify.value = info;
      updateNotifyVisible.value = true;
      lastNotifiedUpdate = info.latest;
    }
  } catch {
    /* 网络或授权系统不可用时静默跳过 */
  }
}

function goUpdate() {
  updateNotifyVisible.value = false;
  router.push({ name: 'update' });
}

const showChangePwd = computed(() => auth.authenticated && auth.mustChangePassword);
const pwdForm = reactive<ChangeCredentialsInput>({
  currentPassword: '',
  username: auth.username || '',
  password: '',
  confirmPassword: ''
});
const savingPwd = ref(false);

async function submitPwd() {
  if (!pwdForm.currentPassword || !pwdForm.username || !pwdForm.password || !pwdForm.confirmPassword) {
    Message.warning('请填写完整信息');
    return;
  }
  if (pwdForm.password !== pwdForm.confirmPassword) {
    Message.warning('两次输入的新密码不一致');
    return;
  }
  savingPwd.value = true;
  try {
    await auth.changeCredentials(pwdForm);
    Message.success('账号密码已更新');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    savingPwd.value = false;
  }
}
</script>

<style scoped>
.app-sidebar {
  background: var(--color-bg-2);
  border-right: 1px solid var(--color-border-2);
  display: flex;
  flex-direction: column;
}
.sidebar-brand {
  padding: 16px 20px;
  font-weight: 600;
  font-size: 16px;
  border-bottom: 1px solid var(--color-border-2);
  white-space: nowrap;
  overflow: hidden;
}
.brand-short {
  font-size: 15px;
  letter-spacing: 0.05em;
}
.sidebar-menu {
  flex: 1;
  border-right: none;
  padding: 8px;
}
.sidebar-footer {
  padding: 12px 16px;
  border-top: 1px solid var(--color-border-2);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.sidebar-user {
  font-size: 13px;
  color: var(--color-text-2);
  display: inline-flex;
  align-items: center;
}
.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  height: 60px;
  background: var(--color-bg-2);
  border-bottom: 1px solid var(--color-border-2);
}
.header-title {
  margin: 0;
  font-size: 20px;
}
</style>
