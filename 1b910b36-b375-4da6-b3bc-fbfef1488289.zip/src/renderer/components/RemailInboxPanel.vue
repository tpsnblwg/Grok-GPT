<template>
  <a-card title="人工收件" size="small" class="mb-3">
    <template #extra>
      <a-tag color="arcoblue">Remail 人工邮箱 + 验证码</a-tag>
    </template>

    <a-space direction="vertical" fill>
      <a-space>
        <a-select
          v-model="selected"
          multiple
          placeholder="可多选订单"
          style="min-width: 420px"
          @change="onSelectOrders"
        >
          <a-option v-for="order in orders" :key="order.orderNo" :value="order.orderNo">
            {{ order.deliveryEmail }} · {{ order.status }} · {{ order.orderNo }}
          </a-option>
        </a-select>
        <a-button :loading="busy" @click="loadOrders">加载订单</a-button>
        <a-button size="small" :disabled="orders.length === 0" @click="selectAllOrders">全选</a-button>
      </a-space>

      <a-descriptions v-if="selectedOrders.length" :column="3" size="small" bordered>
        <a-descriptions-item label="轮询进度">{{ pollIndex + 1 }} / {{ selectedOrders.length }}</a-descriptions-item>
        <a-descriptions-item label="当前轮询邮箱">{{ selectedOrder?.deliveryEmail || '--' }}</a-descriptions-item>
        <a-descriptions-item label="订单号">{{ selectedOrder?.orderNo || '--' }}</a-descriptions-item>
      </a-descriptions>

      <!-- 注册邮箱队列：批量提交 -->
      <a-card size="small" :bordered="true">
        <a-space direction="vertical" fill>
          <a-space>
            <span class="queue-label">注册邮箱队列</span>
            <a-tag color="arcoblue">{{ emailQueueLength }} 个待用</a-tag>
          </a-space>
          <a-space>
            <a-button type="primary" size="small" :disabled="selectedOrders.length === 0" :loading="submittingEmail" @click="submitEmails">
              <template #icon><icon-send /></template>批量提交 {{ selectedOrders.length }} 个邮箱到队列
            </a-button>
          </a-space>
          <a-typography-text type="secondary" class="queue-hint">
            把所选订单的交付邮箱批量提交到邮箱队列（先进先出）。每轮注册消耗 1 个邮箱，请在 Remail 手动下单补充。
          </a-typography-text>
        </a-space>
      </a-card>

      <a-space>
        <a-button :disabled="!selectedOrder || busy" @click="checkMail(false)">
          <template #icon><icon-inbox /></template>立即检查(当前)
        </a-button>
        <a-button :status="polling ? 'danger' : 'normal'" :disabled="!selectedOrder" @click="togglePolling">
          <template #icon><icon-sync v-if="polling" /><icon-bell v-else /></template>
          {{ polling ? '停止轮询' : '轮询当前' }}
        </a-button>
      </a-space>

      <a-alert v-if="lastCode" type="success" show-icon>
        <template #title>
          最新验证码 <b style="font-size: 18px; letter-spacing: 0.2em">{{ lastCode }}</b>
        </template>
        已自动填入下方输入框，可提交到取码队列供注册脚本使用。
      </a-alert>

      <!-- 手动验证码队列 -->
      <a-card size="small" :bordered="true">
        <a-space direction="vertical" fill>
          <a-space>
            <span class="queue-label">手动验证码输入</span>
            <a-tag color="arcoblue">取码队列 {{ queueLength }} 个待用</a-tag>
          </a-space>
          <a-space>
            <a-input v-model="manualCode" placeholder="在这里输入或编辑验证码" style="width: 220px" />
            <a-button type="primary" size="small" :disabled="!manualCode.trim()" @click="submitCode">
              <template #icon><icon-send /></template>提交到队列
            </a-button>
            <a-button size="small" :disabled="!manualCode.trim()" @click="copyCode">复制</a-button>
            <a-button size="small" status="danger" :disabled="!manualCode" @click="clearCode">清空</a-button>
          </a-space>
          <a-typography-text type="secondary" class="queue-hint">
            提交后进入取码队列（先进先出），注册脚本在需要验证码时会自动取用并填写。
          </a-typography-text>
        </a-space>
      </a-card>

      <a-card size="small" :bordered="true">
        <template #title>
          <a-typography-text type="secondary">{{ polling ? 'polling / 4s' : 'mail result' }}</a-typography-text>
        </template>
        <pre class="result-pre">{{ lastResult ? JSON.stringify(lastResult, null, 2) : '暂无收件结果' }}</pre>
      </a-card>
    </a-space>
  </a-card>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { api } from '@renderer/api';

interface RemailOrder {
  orderNo?: string;
  status?: string;
  deliveryEmail?: string;
  serviceToken?: string;
  verificationCode?: string;
  receiveUntil?: string | null;
}

const orders = ref<RemailOrder[]>([]);
const selected = ref<string[]>([]);
const busy = ref(false);
const polling = ref(false);
const submittingEmail = ref(false);
const lastCode = ref('');
const manualCode = ref('');
const lastResult = ref<unknown>(null);
const queueLength = ref(0);
const emailQueueLength = ref(0);
const seenCode = ref('');
const pollIndex = ref(0);

const selectedOrders = computed(() =>
  orders.value.filter((o) => o.orderNo && selected.value.includes(String(o.orderNo)))
);
const selectedOrder = computed(() => selectedOrders.value[pollIndex.value] ?? null);

function extractCode(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const item = value as Record<string, unknown>;
  const direct = item.verificationCode;
  if (typeof direct === 'string' && direct.trim()) return direct.trim();
  const items = Array.isArray(item.items) ? item.items : [];
  for (const entry of items) {
    const code = extractCode(entry);
    if (code) return code;
  }
  return null;
}

async function loadOrders() {
  busy.value = true;
  try {
    const response = (await api.listRemailOrders()) as { items?: RemailOrder[] } | RemailOrder[];
    const summaries = Array.isArray(response) ? response : response.items ?? [];
    const details = await Promise.all(
      summaries
        .filter((item) => item.orderNo)
        .map(async (item) => {
          if (item.deliveryEmail && item.serviceToken) return item;
          try {
            const detail = (await api.getRemailOrder(String(item.orderNo))) as RemailOrder;
            return { ...item, ...detail };
          } catch {
            return item;
          }
        })
    );
    const usable = details.filter((item) => item.orderNo && item.deliveryEmail && item.serviceToken);
    orders.value = usable;
    if (usable.length > 0) {
      selected.value = usable.some((item) => selected.value.includes(String(item.orderNo)))
        ? selected.value.filter((v) => usable.some((u) => String(u.orderNo) === v))
        : [String(usable[0].orderNo)];
    } else {
      selected.value = [];
    }
    pollIndex.value = 0;
    Message.success(`已加载 ${usable.length} 个可取件订单`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    busy.value = false;
  }
}

async function checkMail(silent = false) {
  const order = selectedOrder.value;
  if (!order?.deliveryEmail || !order.serviceToken) return;
  try {
    const response = await api.pickupRemail({
      email: order.deliveryEmail,
      token: order.serviceToken
    });
    lastResult.value = response;
    const code = extractCode(response);
    if (code && code !== seenCode.value) {
      seenCode.value = code;
      lastCode.value = code;
      manualCode.value = code;
      if (!silent) Message.success(`检测到新验证码：${code}`);
      // 当前邮箱已取到验证码，自动切到下一个邮箱继续轮询
      advancePoll();
    } else if (!silent) {
      Message.info('检查完成，暂未发现新验证码');
    }
  } catch (err) {
    if (!silent) Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function loadQueue() {
  try {
    const { queueLength: length } = await api.getManualCodeStatus();
    queueLength.value = length;
  } catch {
    /* ignore */
  }
}

async function loadEmailQueue() {
  try {
    const { queueLength: length } = await api.getManualEmailStatus();
    emailQueueLength.value = length;
  } catch {
    /* ignore */
  }
}

async function submitCode() {
  const code = manualCode.value.trim();
  if (!code) {
    Message.warning('请先输入验证码');
    return;
  }
  try {
    const res = await api.submitManualCode(code);
    queueLength.value = res.queueLength;
    manualCode.value = '';
    Message.success(`验证码已提交到取码队列，当前队列 ${res.queueLength} 个`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function submitEmails() {
  const emails = selectedOrders.value.map((o) => o.deliveryEmail).filter(Boolean) as string[];
  if (emails.length === 0) {
    Message.warning('请先选择可取件订单');
    return;
  }
  submittingEmail.value = true;
  try {
    let length = emailQueueLength.value;
    for (const email of emails) {
      const res = await api.submitManualEmail(email);
      length = res.queueLength;
    }
    emailQueueLength.value = length;
    Message.success(`已批量提交 ${emails.length} 个邮箱到注册邮箱队列，当前队列 ${length} 个`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    submittingEmail.value = false;
  }
}

async function copyCode() {
  try {
    await navigator.clipboard.writeText(manualCode.value.trim());
    Message.success('验证码已复制');
  } catch {
    Message.error('复制失败');
  }
}

function clearCode() {
  manualCode.value = '';
  lastCode.value = '';
  seenCode.value = '';
}

function advancePoll() {
  const total = selectedOrders.value.length;
  if (total === 0) return;
  if (pollIndex.value >= total - 1) {
    // 已是最后一个邮箱，取到验证码后停止轮询
    polling.value = false;
    Message.success('所有选中邮箱均已取到验证码，已停止轮询');
  } else {
    pollIndex.value += 1;
    seenCode.value = '';
  }
}

function onSelectOrders() {
  polling.value = false;
  pollIndex.value = 0;
  lastCode.value = '';
  seenCode.value = '';
}

function selectAllOrders() {
  selected.value = orders.value.map((o) => String(o.orderNo));
  polling.value = false;
  pollIndex.value = 0;
  lastCode.value = '';
  seenCode.value = '';
}

function togglePolling() {
  if (!selectedOrder.value) {
    Message.warning('请先选择可取件订单');
    return;
  }
  if (!polling.value) {
    // 重新开始轮询时，从第一个选中的邮箱开始
    pollIndex.value = 0;
  }
  lastCode.value = '';
  seenCode.value = '';
  polling.value = !polling.value;
}

let timer: number | null = null;

watch(
  () => [polling.value, selected.value.join(',')],
  () => {
    if (timer !== null) {
      window.clearInterval(timer);
      timer = null;
    }
    if (polling.value && selectedOrder.value) {
      void checkMail(true);
      timer = window.setInterval(() => void checkMail(true), 4000);
    }
  }
);

onMounted(() => {
  void loadQueue();
  void loadEmailQueue();
});

onBeforeUnmount(() => {
  if (timer !== null) window.clearInterval(timer);
});
</script>

<style scoped>
.queue-label {
  font-weight: 600;
  font-size: 13px;
}
.queue-hint {
  font-size: 12px;
}
.result-pre {
  margin: 0;
  max-height: 200px;
  overflow: auto;
  white-space: pre-wrap;
  word-break: break-all;
  font-size: 12px;
}
</style>
