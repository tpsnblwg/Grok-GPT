<template>
  <a-card title="Remail 人工操作" size="small" class="mb-3">
    <template #extra>
      <a-tag color="arcoblue">查询 / 批量下单 / 取件</a-tag>
    </template>
    <a-space direction="vertical" fill>
      <!-- 余额与价格 -->
      <a-descriptions :column="4" size="small" bordered>
        <a-descriptions-item label="当前余额">
          <b style="color: #00b42a">{{ balanceText }}</b>
        </a-descriptions-item>
        <a-descriptions-item label="单价">
          {{ unitPriceText }}
          <a-tag size="small" style="margin-left: 6px">{{ settings.data?.remail.emailSuffix || '-' }}</a-tag>
        </a-descriptions-item>
        <a-descriptions-item label="总价(×{{ count }})">≈ {{ totalPriceText }}</a-descriptions-item>
        <a-descriptions-item label="购买后预计剩余">≈ {{ afterBalanceText }}</a-descriptions-item>
      </a-descriptions>

      <a-space wrap>
        <a-button :loading="busy === '查询项目'" @click="run('项目', () => api.listRemailProjects())">
          <template #icon><icon-list /></template>项目
        </a-button>
        <a-button :loading="busy === '查询资源'" @click="run('资源', () => api.listRemailResources())">
          <template #icon><icon-search /></template>资源
        </a-button>
        <a-button :loading="busy === '查询订单'" @click="run('订单', () => api.listRemailOrders())">
          <template #icon><icon-sync /></template>订单
        </a-button>
        <a-button type="primary" :loading="busy === '批量下单'" @click="createBatch">
          <template #icon><icon-shopping-cart /></template>批量下单
        </a-button>
        <a-input-number v-model="count" :min="1" :max="50" style="width: 90px" />
      </a-space>

      <a-space>
        <a-input v-model="orderNo" placeholder="订单号，例如 R2026..." style="width: 320px" />
        <a-button
          :loading="busy === '查询订单详情'"
          :disabled="!orderNo.trim()"
          @click="run('订单详情', () => api.getRemailOrder(orderNo.trim()))"
        >
          查询详情
        </a-button>
      </a-space>

      <a-space>
        <a-input v-model="email" placeholder="交付邮箱" style="width: 240px" />
        <a-input-password v-model="token" placeholder="服务凭证 token" style="width: 240px" />
        <a-button
          :loading="busy === '取件'"
          :disabled="!email.trim() || !token.trim()"
          @click="run('取件', () => api.pickupRemail({ email: email.trim(), token: token.trim() }))"
        >
          <template #icon><icon-inbox /></template>取件
        </a-button>
      </a-space>
    </a-space>
  </a-card>

  <!-- 结果弹窗 -->
  <a-modal v-model:visible="modalVisible" :title="modalTitle" :footer="false" width="760px">
    <a-list size="small" :bordered="false">
      <a-list-item v-for="(row, i) in modalRows" :key="i">
        <div class="row-item">
          <span class="row-label">{{ row.label }}</span>
          <span class="row-value">{{ row.value }}</span>
        </div>
      </a-list-item>
    </a-list>
  </a-modal>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { api, type RemailPricingInfo, type RemailWallet } from '@renderer/api';
import { useSettingsStore } from '@renderer/stores/settings';

const settings = useSettingsStore();
const busy = ref('');
const orderNo = ref('');
const email = ref('');
const token = ref('');
const count = ref(1);
const wallet = ref<RemailWallet | null>(null);
const pricing = ref<RemailPricingInfo | null>(null);

const balance = computed(() => Number(wallet.value?.consumerBalance || 0));
const balanceText = computed(() => (wallet.value ? balance.value.toFixed(2) : '--'));
const unitPriceText = computed(() => (pricing.value ? pricing.value.unitPrice.toFixed(4) : '--'));
const totalPrice = computed(() => (pricing.value?.unitPrice || 0) * count.value);
const totalPriceText = computed(() => totalPrice.value.toFixed(2));
const afterBalanceText = computed(() =>
  wallet.value ? (balance.value - totalPrice.value).toFixed(2) : '--'
);

async function refreshQuote() {
  try {
    const [w, p] = await Promise.all([api.getRemailWallet(), api.getRemailPricing()]);
    wallet.value = w;
    pricing.value = p;
  } catch {
    /* ignore */
  }
}

// 配置（后缀/模式/项目）变化后自动刷新价格
watch(
  () => settings.data?.remail,
  () => {
    void refreshQuote();
  },
  { deep: true }
);

// 结果弹窗
const modalVisible = ref(false);
const modalTitle = ref('');
const modalRows = ref<{ label: string; value: string }[]>([]);

function toRows(value: unknown): { label: string; value: string }[] {
  const rows: { label: string; value: string }[] = [];
  const push = (label: string, v: unknown) => {
    if (v === undefined || v === null) return;
    if (v && typeof v === 'object') {
      rows.push({ label, value: JSON.stringify(v) });
    } else {
      rows.push({ label, value: String(v) });
    }
  };
  if (Array.isArray(value)) {
    value.forEach((item, i) => {
      if (item && typeof item === 'object') {
        const obj = item as Record<string, unknown>;
        const keys = Object.keys(obj).filter(
          (k) => !['logoUrl', 'id', 'userId', 'offset', 'limit', 'total'].includes(k)
        );
        rows.push({
          label: `#${i + 1}`,
          value: keys.map((k) => `${k}: ${obj[k] ?? ''}`).join(' | ')
        });
      } else {
        rows.push({ label: `#${i + 1}`, value: String(item ?? '') });
      }
    });
  } else if (value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v && typeof v === 'object') {
        rows.push({ label: k, value: JSON.stringify(v) });
      } else {
        rows.push({ label: k, value: String(v ?? '') });
      }
    }
  } else {
    rows.push({ label: 'result', value: String(value ?? '') });
  }
  return rows;
}

async function run(label: string, operation: () => Promise<unknown>) {
  busy.value = label;
  try {
    const data = await operation();
    modalTitle.value = label;
    modalRows.value = toRows(data);
    modalVisible.value = true;
    Message.success(`${label}完成`);
  } catch (err) {
    Message.error(`${label}失败：${err instanceof Error ? err.message : String(err)}`);
  } finally {
    busy.value = '';
  }
}

async function createBatch() {
  if (!settings.data) return;
  const s = settings.data.remail;
  const n = count.value;
  const cost = (pricing.value?.unitPrice || 0) * n;
  const text = `确认创建 ${n} 个订单？\n项目 ID: ${s.projectId}\n邮箱后缀: ${s.emailSuffix}\n模式: ${s.serviceMode}\n预计费用: ${cost.toFixed(2)}，余额 ${balanceText.value} → 约 ${afterBalanceText.value}\n该操作会实际扣除 Remail 余额。`;
  if (!window.confirm(text)) return;
  busy.value = '批量下单';
  try {
    const data = await api.createRemailOrder({
      projectId: s.projectId,
      emailSuffix: s.emailSuffix,
      serviceMode: s.serviceMode,
      count: n
    });
    modalTitle.value = `批量下单结果`;
    modalRows.value = toRows(data);
    modalVisible.value = true;
    Message.success(`已创建 ${n} 个订单`);
    void refreshQuote();
  } catch (err) {
    Message.error(`批量下单失败：${err instanceof Error ? err.message : String(err)}`);
  } finally {
    busy.value = '';
  }
}

onMounted(() => {
  void refreshQuote();
});
</script>

<style scoped>
.row-item {
  display: flex;
  gap: 8px;
  width: 100%;
}
.row-label {
  flex-shrink: 0;
  min-width: 80px;
  font-weight: 600;
  color: var(--color-text-2);
}
.row-value {
  word-break: break-all;
  font-size: 13px;
}
.mb-3 {
  margin-bottom: 16px;
}
</style>
