<template>
  <a-card size="small">
    <a-space direction="vertical" fill>
      <a-space>
        <a-tag :color="phaseColor" size="large">{{ phaseLabel }}</a-tag>
        <a-tag v-if="status.pid" color="arcoblue">pid {{ status.pid }}</a-tag>
      </a-space>
      <a-descriptions :column="2" size="small" bordered>
        <a-descriptions-item label="current">{{ status.current }}</a-descriptions-item>
        <a-descriptions-item label="total">{{ status.total }}</a-descriptions-item>
        <a-descriptions-item label="success">{{ status.success }}</a-descriptions-item>
        <a-descriptions-item label="failed">{{ status.failed }}</a-descriptions-item>
      </a-descriptions>
      <a-typography-text type="secondary">{{ summary }}</a-typography-text>
    </a-space>
  </a-card>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import type { RunStatus } from '@shared/runEvents';

const props = defineProps<{ status: RunStatus }>();
const status = computed(() => props.status);

const phaseLabel = computed(() => {
  switch (status.value.phase) {
    case 'idle':
      return '待命';
    case 'starting':
      return '启动中';
    case 'running':
      return '运行中';
    case 'done':
      return '已完成';
    case 'killed':
      return '已停止';
    case 'error':
      return '已出错';
  }
});
const phaseColor = computed(() => {
  switch (status.value.phase) {
    case 'running':
    case 'starting':
      return 'orange';
    case 'error':
      return 'red';
    case 'done':
      return 'green';
    default:
      return 'arcoblue';
  }
});
const summary = computed(() => {
  switch (status.value.phase) {
    case 'idle':
      return '待命，可以开始注册。';
    case 'starting':
      return '正在启动 Python 子进程…';
    case 'running':
      return `正在运行第 ${Math.max(status.value.current, 1)}/${status.value.total} 轮`;
    case 'done':
      return '完成。SSO 结果已写入本地号池。';
    case 'killed':
      return '已停止。';
    case 'error':
      return status.value.errorMessage ?? '运行出错。';
  }
});
</script>
