<template>
  <a-card title="实时日志面板" size="small">
    <template #extra>
      <a-space>
        <a-tag :color="autoScroll ? 'green' : 'orange'">{{ autoScroll ? '自动滚动' : '已暂停滚动' }}</a-tag>
        <a-button size="mini" @click="copyAll">复制</a-button>
        <a-button size="mini" status="danger" @click="run.clearLogs()">清空</a-button>
      </a-space>
    </template>
    <div ref="logRef" class="log-console" @scroll="onScroll">
      <div v-if="run.logs.length === 0" class="log-empty">
        尚无日志。点击「开始注册」后这里会实时显示 Python 进程输出。
      </div>
      <div v-for="line in run.logs" :key="line.id" class="log-line">
        <span class="log-time">{{ fmtTime(line.ts) }}</span>
        <span class="log-level" :class="colorClass(line.level)">{{ line.level === 'stderr' ? '✘' : '›' }}</span>
        <span class="log-text" :class="colorClass(line.level)">{{ line.text }}</span>
      </div>
    </div>
  </a-card>
</template>

<script setup lang="ts">
import { nextTick, ref, watch } from 'vue';
import { useRunStore } from '@renderer/stores/run';

const run = useRunStore();
const logRef = ref<HTMLElement | null>(null);
const autoScroll = ref(true);

function fmtTime(ts: number) {
  return new Date(ts).toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

function colorClass(level: string) {
  switch (level) {
    case 'warn':
      return 'log-warn';
    case 'error':
    case 'stderr':
      return 'log-error';
    case 'tip':
      return 'log-tip';
    default:
      return 'log-info';
  }
}

watch(
  () => run.logs.length,
  async () => {
    if (autoScroll.value) {
      await nextTick();
      if (logRef.value) logRef.value.scrollTop = logRef.value.scrollHeight;
    }
  }
);

function onScroll() {
  const el = logRef.value;
  if (!el) return;
  autoScroll.value = el.scrollHeight - el.scrollTop - el.clientHeight < 24;
}

async function copyAll() {
  const text = run.logs.map((l) => l.text).join('\n');
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    /* ignore */
  }
}
</script>

<style scoped>
.log-console {
  height: 420px;
  overflow-y: auto;
  background: var(--color-fill-2);
  border-radius: 4px;
  padding: 12px;
  font-family: 'JetBrains Mono', Consolas, Menlo, monospace;
  font-size: 12px;
  line-height: 1.9;
}
.log-empty {
  color: var(--color-text-3);
  text-align: center;
  margin-top: 60px;
}
.log-line {
  display: grid;
  grid-template-columns: 80px 20px minmax(0, 1fr);
  gap: 8px;
  border-bottom: 1px solid var(--color-border-2);
  padding: 2px 0;
}
.log-line:last-child {
  border-bottom: none;
}
.log-time {
  color: var(--color-text-3);
  font-size: 11px;
}
.log-info {
  color: var(--color-text-1);
}
.log-warn {
  color: #ff7d00;
}
.log-error {
  color: #f53f3f;
}
.log-tip {
  color: #3491fa;
}
</style>
