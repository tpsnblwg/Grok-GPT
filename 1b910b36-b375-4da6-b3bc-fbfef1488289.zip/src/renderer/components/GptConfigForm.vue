<template>
  <a-form :model="model" layout="vertical">
    <a-row :gutter="12">
      <a-col :xs="24" :md="8">
        <a-form-item label="注册轮数"><a-slider v-model="model.runCount" :min="1" :max="50" /></a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="固定注册密码（留空自动生成）">
          <a-input v-model="model.registerPassword" placeholder="留空自动生成强密码" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="显示名（about-you）">
          <a-input v-model="model.displayName" placeholder="留空随机" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="出生日期（YYYY-MM-DD）">
          <a-input v-model="model.birthDate" placeholder="留空随机成年人" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="使用代理访问（chatgpt.com）">
          <a-switch v-model="model.useProxy" />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="18">
        <a-form-item label="注册代理地址" :extra="model.useProxy ? '注册浏览器将走此代理，绕过 Cloudflare 风控' : '开启「使用代理访问」后生效'">
          <a-input v-model="model.proxy" placeholder="http://user:pass@host:port 或 socks5://user:pass@host:port" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="支付链接提炼方式">
          <a-select v-model="model.payment.extractMode">
            <a-option value="manual">手动粘贴</a-option>
            <a-option value="external_api">CDK 提链服务</a-option>
            <a-option value="http">HTTP 提链 API</a-option>
            <a-option value="browser">浏览器驱动（打开网页填表）</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="提链类型（external_api）">
          <a-select v-model="model.payment.linkType">
            <a-option value="paypal">paypal</a-option>
            <a-option value="pix">pix</a-option>
            <a-option value="upi">upi</a-option>
            <a-option value="kakao_pay">kakao_pay</a-option>
            <a-option value="ideal">ideal</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="提链 CDK（external_api）">
          <a-input-password v-model="model.payment.cdk" placeholder="external_api 模式必填" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="8">
        <a-form-item label="支付通道（browser）">
          <a-select v-model="model.payment.channel">
            <a-option v-for="c in channelOptions" :key="c.value" :value="c.value">{{ c.label }}</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="国家/地区">
          <a-select v-model="model.payment.country" allow-search>
            <a-option v-for="c in countryOptions" :key="c.code" :value="c.code">{{ c.label }}</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="币种">
          <a-select v-model="model.payment.currency">
            <a-option v-for="c in currencyOptions" :key="c" :value="c">{{ c }}</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="订阅类型">
          <a-select v-model="model.payment.plan">
            <a-option v-for="p in planOptions" :key="p.value" :value="p.value">{{ p.label }}</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="Plus 试用检测">
          <a-switch v-model="model.payment.plusTrialCheck" />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="尝试优惠活动（usePromo）">
          <a-switch v-model="model.payment.tryPromo" />
        </a-form-item>
      </a-col>
      <a-col :xs="12" :md="6">
        <a-form-item label="SEN + SO（useSentinel）">
          <a-switch v-model="model.payment.useSentinel" />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链服务地址（external_api/http 模式）">
          <a-input v-model="model.payment.extractEndpoint" placeholder="https://..." allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链 API Token（http 模式）">
          <a-input-password v-model="model.payment.extractToken" placeholder="选填" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链网页地址（browser 模式）">
          <a-input v-model="model.payment.extractUrl" placeholder="https://pay.153.ink/" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链失败重试次数（browser）">
          <a-input-number v-model="model.payment.retryCount" :min="1" :max="50" style="width: 100%" />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="Plus 优惠 Campaign（选填）">
          <a-input v-model="model.payment.promoCampaign" placeholder="例如 plus-1-month-free" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链入口代理池（每行一个）" required>
          <a-textarea v-model="model.payment.entryProxy" placeholder="host:port:user:pass" :auto-size="{ minRows: 2, maxRows: 5 }" />
        </a-form-item>
      </a-col>
      <a-col :xs="24" :md="12">
        <a-form-item label="提链出口代理池（browser，可留空）">
          <a-textarea v-model="model.payment.exitProxy" placeholder="host:port:user:pass" :auto-size="{ minRows: 2, maxRows: 5 }" />
        </a-form-item>
      </a-col>
    </a-row>
  </a-form>
</template>

<script setup lang="ts">
import type { GptSettings } from '@shared/settings';

defineProps<{ model: GptSettings }>();

const planOptions = [
  { value: 'plus', label: 'Plus · 个人订阅' },
  { value: 'pro', label: 'Pro · 专业计划' },
  { value: 'team', label: 'Team · 工作空间' },
  { value: 'codex', label: 'Codex · 低价空间' }
];
const channelOptions = [
  { value: 'hosted', label: 'Hosted · 官方支付长链' },
  { value: 'ph_short', label: 'PH 菲律宾短链' },
  { value: 'paypal', label: 'PayPal · Approve 跳转' },
  { value: 'ideal', label: 'iDEAL · 荷兰银行支付' },
  { value: 'upi', label: 'UPI · 印度二维码' },
  { value: 'pix', label: 'PIX · 巴西即时支付' },
  { value: 'momo', label: 'MoMo · 越南电子钱包' },
  { value: 'gcash', label: 'GCash · 菲律宾电子钱包' },
  { value: 'kakao', label: 'Kakao Pay · 韩国' }
];
const countryOptions = [
  { code: 'US', label: 'US · 美国' },
  { code: 'DE', label: 'DE · 德国' },
  { code: 'FR', label: 'FR · 法国' },
  { code: 'NL', label: 'NL · 荷兰' },
  { code: 'IN', label: 'IN · 印度' },
  { code: 'BR', label: 'BR · 巴西' },
  { code: 'VN', label: 'VN · 越南' },
  { code: 'GB', label: 'GB · 英国' },
  { code: 'JP', label: 'JP · 日本' },
  { code: 'KR', label: 'KR · 韩国' },
  { code: 'PH', label: 'PH · 菲律宾' },
  { code: 'AU', label: 'AU · 澳大利亚' },
  { code: 'CA', label: 'CA · 加拿大' }
];
const currencyOptions = ['USD', 'EUR', 'INR', 'BRL', 'GBP', 'JPY', 'KRW', 'VND', 'PHP', 'AUD', 'CAD'];
</script>
