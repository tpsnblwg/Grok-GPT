<template>
  <div class="settings-form">
    <a-card title="WebUI 配置" size="small" class="mb-3">
      <a-descriptions :column="3" size="small" bordered>
        <a-descriptions-item label="访问地址">{{ origin }}</a-descriptions-item>
        <a-descriptions-item label="登录方式">cookie session</a-descriptions-item>
        <a-descriptions-item label="反向代理">未启用</a-descriptions-item>
      </a-descriptions>
    </a-card>

    <a-card title="邮件后端" size="small" class="mb-3">
      <template #extra>
        <a-button size="mini" :loading="testingMail" :disabled="!draft" @click="testMail">测试连接</a-button>
      </template>
      <a-form v-if="draft" :model="draft.mail" layout="vertical">
        <a-row :gutter="16">
          <a-col :span="12">
            <a-form-item label="mail api base" extra="例如 https://mail.example.com">
              <a-input v-model="draft.mail.apiBase" placeholder="https://mail.example.com" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="mail domain" extra="默认邮箱后缀，例如 example.com">
              <a-input v-model="draft.mail.domain" placeholder="example.com" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="可用邮箱后缀" extra="注册页 Cloudflare 下拉可选，逗号分隔，例如 omgai.edu.kg,xyz.com">
              <a-input v-model="domainsText" placeholder="后缀1,后缀2" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="收信方式" extra="决定注册脚本取邮箱的方式">
              <a-select v-model="draft.mail.mode">
                <a-option value="auto">自动（优先 Remail，回退 Cloudflare）</a-option>
                <a-option value="remail">仅 Remail 手动队列</a-option>
                <a-option value="cloudflare">仅 Cloudflare 临时邮箱</a-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="24">
            <a-form-item label="admin auth" extra="Cloudflare Temp Email 后端管理员密码">
              <a-input-password v-model="draft.mail.adminAuth" placeholder="管理员密码" />
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
    </a-card>

    <a-card title="Remail 人工邮箱工具" size="small" class="mb-3">
      <template #extra>
        <a-button size="mini" :loading="testingRemail" :disabled="!draft" @click="testRemail">测试连接</a-button>
      </template>
      <a-form v-if="draft" :model="draft.remail" layout="vertical">
        <a-row :gutter="16">
          <a-col :span="12">
            <a-form-item label="Remail API 地址" extra="默认 https://remail.aishop6.com">
              <a-input v-model="draft.remail.apiBase" placeholder="https://remail.aishop6.com" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="Remail API Key">
              <template #extra>
                rk- 开头的 Key，不会显示在日志中。
                <a-link href="https://remail.aishop6.com/register?aff=AFFIL434IPCMJ" target="_blank">
                  不知道 API Key？点我去获取（送 100 余额）
                </a-link>
              </template>
              <a-input-password v-model="draft.remail.apiKey" placeholder="rk-xxx" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="项目 ID" extra="Grok 项目通常为 3">
              <a-input-number v-model="draft.remail.projectId" :min="1" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="邮箱后缀" extra="从项目资源中选择，也可输入">
              <a-select
                v-model="draft.remail.emailSuffix"
                :options="suffixOptions.map((s) => ({ label: s, value: s }))"
                allow-create
                allow-search
                placeholder="选择或输入邮箱后缀"
              />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="服务模式">
              <a-select v-model="draft.remail.serviceMode">
                <a-option value="code">code / 短时取码</a-option>
                <a-option value="purchase">purchase / 长效购买</a-option>
              </a-select>
            </a-form-item>
          </a-col>
        </a-row>
        <a-typography-text type="secondary" style="font-size: 12px">
          仅支持单笔人工操作。系统不会提供批量下单、批量注册或自动循环任务。
        </a-typography-text>
      </a-form>
    </a-card>

    <a-card title="grok2api 账号上传" size="small" class="mb-3">
      <template #extra>
        <a-button size="mini" :loading="testingGrok2api" :disabled="!draft" @click="testGrok2api">测试连接</a-button>
      </template>
      <a-form v-if="draft" :model="draft.grok2api" layout="vertical">
        <a-row :gutter="16">
          <a-col :span="12">
            <a-form-item label="grok2api API 地址" extra="例如 http://host.docker.internal:8000">
              <a-input v-model="draft.grok2api.apiBase" placeholder="http://host.docker.internal:8000" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="管理用户名" extra="grok2api 管理后台账号">
              <a-input v-model="draft.grok2api.username" placeholder="admin" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="管理密码" extra="grok2api 管理后台密码">
              <a-input-password v-model="draft.grok2api.password" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="上传账号类型" extra="web=grok.com SSO 账号（默认，推荐）">
              <a-select v-model="draft.grok2api.provider">
                <a-option value="web">web / Grok Web SSO</a-option>
                <a-option value="build">build / Grok 控制台账号</a-option>
                <a-option value="console">console / Grok Console 账号</a-option>
              </a-select>
            </a-form-item>
          </a-col>
        </a-row>
        <a-typography-text type="secondary" style="font-size: 12px">
          在「号池」页点击「上传到 grok2api」按钮即可把选中（或全部）账号的 SSO 上传到 grok2api。密码保存在服务器数据目录，请妥善保管。
        </a-typography-text>
      </a-form>
    </a-card>

    <a-card title="GPT 注册机配置" size="small" class="mb-3">
      <GptConfigForm v-if="draft" :model="draft.gpt" />
      <a-typography-text type="secondary" style="font-size: 12px">
        GPT 注册机的注册参数与提链/支付参数（pay.153.ink 提链、Plus 试用检测等）。浏览器驱动提链会打开网页自动填表提交，用户只需在此选择/填写参数。
      </a-typography-text>
    </a-card>

    <a-card title="授权系统在线更新" size="small" class="mb-3">
      <template #extra>
        <a-switch v-if="draft" v-model="draft.authUpdate.enabled" />
      </template>
      <a-form v-if="draft" :model="draft.authUpdate" layout="vertical">
        <a-row :gutter="16">
          <a-col :span="12">
            <a-form-item label="授权系统地址" extra="例如 https://power.1tim.com">
              <a-input v-model="draft.authUpdate.server" placeholder="https://power.1tim.com" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="Open API Key" extra="xzak_ 开头的鉴权密钥">
              <a-input-password v-model="draft.authUpdate.apiKey" placeholder="xzak_xxx" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="应用 ID" extra="授权系统中创建的应用 ID">
              <a-input-number v-model="draft.authUpdate.applicationId" :min="1" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="本地版本 code" extra="例如 0.1.2 → 12；0.1.3 → 13；1.0.0 → 100">
              <a-input-number v-model="draft.authUpdate.versionCode" :min="1" />
            </a-form-item>
          </a-col>
        </a-row>
        <a-typography-text type="secondary" style="font-size: 12px">
          开启后，「首页」的检查更新将优先从授权系统查询版本；发现新版本时可一键下载完整更新包到数据目录
          <code>updates/</code>，再在宿主机解压并重建容器完成升级。
        </a-typography-text>
      </a-form>
    </a-card>

    <a-button type="primary" long :disabled="!dirty || saving" :loading="saving" @click="save">
      保存配置
    </a-button>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { useSettingsStore } from '@renderer/stores/settings';
import { api } from '@renderer/api';
import GptConfigForm from '@renderer/components/GptConfigForm.vue';
import type { AppSettings } from '@shared/settings';

const settings = useSettingsStore();
const draft = ref<AppSettings | null>(null);

watch(
  () => settings.data,
  (val) => {
    if (val && !draft.value) draft.value = JSON.parse(JSON.stringify(val));
  },
  { immediate: true }
);

const dirty = computed(
  () => !!settings.data && JSON.stringify(settings.data) !== JSON.stringify(draft.value)
);
const domainsText = computed({
  get: () => (draft.value?.mail?.domains || []).join(','),
  set: (val: string) => {
    if (!draft.value) return;
    draft.value.mail.domains = String(val || '')
      .split(/[,，\s]+/)
      .map((s) => s.trim())
      .filter(Boolean);
  }
});
const saving = ref(false);
const testingMail = ref(false);
const testingRemail = ref(false);
const testingGrok2api = ref(false);
const suffixOptions = ref<string[]>([]);

async function loadSuffixes() {
  try {
    const p = await api.getRemailPricing();
    const set = new Set<string>();
    for (const item of p.prices || []) {
      for (const s of item.suffixes || []) set.add(s);
    }
    suffixOptions.value = [...set].sort();
  } catch {
    /* ignore */
  }
}
onMounted(() => {
  void loadSuffixes();
});

const origin = typeof window === 'undefined' ? 'http://127.0.0.1:8098' : window.location.origin;

async function save() {
  if (!draft.value) return;
  saving.value = true;
  try {
    await api.saveSettings(draft.value);
    await settings.reload();
    Message.success('配置已保存');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    saving.value = false;
  }
}

async function testMail() {
  if (!draft.value) return;
  testingMail.value = true;
  try {
    const r = await api.testMail(draft.value.mail);
    r.ok ? Message.success(r.message) : Message.error(r.message);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    testingMail.value = false;
  }
}

async function testRemail() {
  if (!draft.value) return;
  testingRemail.value = true;
  try {
    const r = await api.testRemail();
    r.ok ? Message.success(r.message) : Message.error(r.message);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    testingRemail.value = false;
  }
}

async function testGrok2api() {
  if (!draft.value) return;
  testingGrok2api.value = true;
  try {
    const r = await api.testGrok2api(draft.value.grok2api);
    r.ok ? Message.success(r.message) : Message.error(r.message);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    testingGrok2api.value = false;
  }
}
</script>

<style scoped>
.mb-3 {
  margin-bottom: 16px;
}
</style>
