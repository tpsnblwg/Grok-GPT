<template>
  <a-card title="代理配置" size="small" class="mb-3">
    <template #extra>
      <a-tag color="arcoblue">手动代理 + 订阅代理</a-tag>
    </template>
    <a-space direction="vertical" fill>
      <!-- 手动代理 -->
      <a-card size="small" :bordered="true">
        <template #title>手动代理</template>
        <a-space wrap>
          <a-input v-model="manual.name" placeholder="代理名称" style="width: 140px" />
          <a-select v-model="manual.type" style="width: 110px">
            <a-option value="http">HTTP</a-option>
            <a-option value="https">HTTPS</a-option>
            <a-option value="socks4">SOCKS4</a-option>
            <a-option value="socks5">SOCKS5</a-option>
          </a-select>
          <a-input v-model="manual.server" placeholder="服务器 IP/域名" style="width: 170px" />
          <a-input-number v-model="manual.port" :min="1" :max="65535" placeholder="端口" style="width: 100px" />
          <a-input v-model="manual.username" placeholder="用户名(可选)" style="width: 120px" />
          <a-input-password v-model="manual.password" placeholder="密码(可选)" style="width: 130px" />
          <a-button type="primary" size="small" @click="addManual">添加</a-button>
        </a-space>
        <div class="proxy-list">
          <a-tag v-for="p in manualProxies" :key="p.name" closable @close="removeManual(p.name)" style="margin-bottom: 4px">
            {{ p.name }} · {{ p.type }}://{{ p.server }}:{{ p.port }}
          </a-tag>
        </div>
      </a-card>

      <!-- 订阅 -->
      <a-card size="small" :bordered="true">
        <template #title>机场订阅</template>
        <a-space wrap>
          <a-input v-model="sub.name" placeholder="订阅名称" style="width: 140px" />
          <a-select v-model="sub.type" style="width: 110px">
            <a-option value="clash">Clash</a-option>
            <a-option value="v2ray">V2Ray</a-option>
          </a-select>
          <span class="sub-tip">vless / vmess / trojan / ss 均支持</span>
          <a-input v-model="sub.url" placeholder="订阅地址 https://..." style="width: 300px" />
          <a-button type="primary" size="small" :loading="parsing" @click="parseSub">拉取解析</a-button>
        </a-space>
      </a-card>

      <!-- 节点列表 -->
      <a-card size="small" :bordered="true">
        <template #title>
          代理节点列表（{{ proxyNodes.length }}）
        </template>
        <template #extra>
          <a-button size="mini" status="danger" :disabled="selectedRowKeys.length === 0" @click="removeSelected">
            <template #icon><icon-delete /></template>删除选中（{{ selectedRowKeys.length }}）
          </a-button>
        </template>
        <a-table
          v-model:selectedKeys="selectedRowKeys"
          :data="proxyNodes"
          :pagination="false"
          size="small"
          :scroll="{ y: 320 }"
          :row-selection="{ type: 'checkbox', showCheckedAll: true }"
          row-key="name"
        >
          <template #columns>
            <a-table-column title="名称" data-index="name" :width="200" />
            <a-table-column title="类型" data-index="type" :width="90" />
            <a-table-column title="本机→节点" :width="100">
              <template #cell="{ record }">{{ fmtLatency(record.nodeLatency) }}</template>
            </a-table-column>
            <a-table-column title="节点→grok" :width="120">
              <template #cell="{ record }">
                <span :class="isEncrypted(record.type) ? 'muted' : ''">
                  {{ isEncrypted(record.type) ? 'N/A(加密协议)' : fmtLatency(record.grokLatency) }}
                </span>
              </template>
            </a-table-column>
            <a-table-column title="操作" :width="110">
              <template #cell="{ record }">
                <a-button size="mini" :loading="testingName === record.name" @click="test(record)">测延迟</a-button>
              </template>
            </a-table-column>
          </template>
        </a-table>
      </a-card>

      <a-button type="primary" long :loading="saving" @click="save">保存代理配置</a-button>
    </a-space>
  </a-card>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { api } from '@renderer/api';
import { useSettingsStore } from '@renderer/stores/settings';
import type { ManualProxy, ProxyNodeBrief } from '@shared/settings';

const settings = useSettingsStore();
const manual = ref<ManualProxy>({ name: '', type: 'http', server: '', port: 0, username: '', password: '' });
const sub = ref({ name: '', type: 'clash', url: '' });
const parsing = ref(false);
const saving = ref(false);
const testingName = ref('');
const selectedRowKeys = ref<string[]>([]);
const parsedNodes = ref<ProxyNodeBrief[]>([]);

const manualProxies = computed<ManualProxy[]>(() => settings.data?.proxyConfig?.manualProxies ?? []);
const proxyNodes = computed<ProxyNodeBrief[]>(() => {
  const manualNodes: ProxyNodeBrief[] = manualProxies.value.map((p) => ({
    name: p.name,
    type: p.type,
    server: p.server,
    port: p.port,
    source: 'manual',
    username: p.username,
    password: p.password,
    nodeLatency: null,
    grokLatency: null
  }));
  const subs = parsedNodes.value.length ? parsedNodes.value : (settings.data?.proxyConfig?.parsedNodes ?? []);
  return [...manualNodes, ...subs];
});

function fmtLatency(v: number | null | undefined): string {
  return v == null ? '--' : `${v}ms`;
}

function addManual() {
  if (!manual.value.name.trim() || !manual.value.server.trim() || !manual.value.port) {
    Message.warning('请填写完整的代理信息');
    return;
  }
  const list = [...manualProxies.value, { ...manual.value, name: manual.value.name.trim(), server: manual.value.server.trim() }];
  settings.save({ ...settings.data!, proxyConfig: { ...settings.data!.proxyConfig, manualProxies: list } });
  manual.value = { name: '', type: 'http', server: '', port: 0, username: '', password: '' };
  Message.success('已添加手动代理');
}

async function removeManual(name: string) {
  const list = manualProxies.value.filter((p) => p.name !== name);
  await settings.save({ ...settings.data!, proxyConfig: { ...settings.data!.proxyConfig, manualProxies: list } });
}

async function parseSub() {
  if (!sub.value.url.trim()) {
    Message.warning('请填写订阅地址');
    return;
  }
  parsing.value = true;
  try {
    const r = await api.parseSubscription({ url: sub.value.url.trim(), type: sub.value.type, name: sub.value.name.trim() || undefined });
    parsedNodes.value = r.nodeList as ProxyNodeBrief[];
    Message.success(`订阅解析成功，共 ${r.nodeCount} 个节点`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    parsing.value = false;
  }
}

async function test(node: ProxyNodeBrief) {
  testingName.value = node.name;
  try {
    const r = await api.testProxyLatency(node);
    node.nodeLatency = r.nodeLatency;
    node.grokLatency = r.grokLatency;
    Message.success(`${node.name}：本机→节点 ${r.nodeLatency ?? '--'}ms，节点→grok ${r.grokLatency ?? '--'}ms`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    testingName.value = '';
  }
}

function isEncrypted(type: string): boolean {
  return ['vless', 'vmess', 'trojan', 'ss', 'shadowsocks'].includes(String(type || '').toLowerCase());
}

async function removeSelected() {
  if (!selectedRowKeys.value.length) return;
  const names = new Set(selectedRowKeys.value);
  const manualList = manualProxies.value.filter((p) => !names.has(p.name));
  const subNodes = (settings.data?.proxyConfig?.parsedNodes ?? []).filter((n) => !names.has(n.name));
  await api.saveProxyManual({ manualProxies: manualList, parsedNodes: subNodes });
  await settings.reload();
  selectedRowKeys.value = [];
  Message.success('已删除选中的节点');
}

async function save() {
  saving.value = true;
  try {
    await api.saveProxyManual({
      manualProxies: manualProxies.value,
      parsedNodes: proxyNodes.value
    });
    await settings.reload();
    parsedNodes.value = [];
    Message.success('代理配置已保存');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    saving.value = false;
  }
}
</script>

<style scoped>
.sub-tip {
  font-size: 12px;
  color: var(--color-text-3);
}
.muted {
  color: var(--color-text-4);
}
.proxy-list {
  margin-top: 8px;
}
.mb-3 {
  margin-bottom: 16px;
}
</style>
