<template>
  <a-card title="代理选择" size="small" class="mb-3">
    <a-space direction="vertical" fill>
      <a-radio-group v-model="source" type="button">
        <a-radio value="none">不使用</a-radio>
        <a-radio value="manual">手动代理</a-radio>
        <a-radio value="subscription">订阅代理</a-radio>
      </a-radio-group>

      <a-radio-group v-if="source !== 'none'" v-model="mode" type="button">
        <a-radio value="fixed">固定节点</a-radio>
        <a-radio value="random">随机节点</a-radio>
        <a-radio value="round-robin">顺序轮询</a-radio>
      </a-radio-group>

      <a-radio-group v-if="source !== 'none'" v-model="applyTo" type="button">
        <a-radio value="register">仅注册</a-radio>
        <a-radio value="sso">仅测活</a-radio>
        <a-radio value="both">注册+测活</a-radio>
      </a-radio-group>

      <a-space v-if="source !== 'none'">
        <a-select
          v-model="selectedName"
          :options="availableNodes.map((n) => ({
            label: `${n.name}（本机→${fmt(n.nodeLatency)} / grok→${fmt(n.grokLatency)}）`,
            value: n.name
          }))"
          placeholder="选择具体代理"
          style="width: 320px"
          allow-search
        />
      </a-space>

      <a-space>
        <a-button type="primary" size="small" :loading="saving" :disabled="source !== 'none' && !selectedName" @click="saveSelection">
          保存选择
        </a-button>
      </a-space>

      <a-typography-text v-if="currentSelection" type="success" style="font-size: 12px">
        当前使用：{{ currentSelection }}（{{ settings.data?.proxy || '未设置' }}）
      </a-typography-text>
    </a-space>
  </a-card>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { api } from '@renderer/api';
import { useSettingsStore } from '@renderer/stores/settings';
import type { ProxyNodeBrief } from '@shared/settings';

const settings = useSettingsStore();

const source = ref<string>(settings.data?.proxyConfig?.selectedSource || 'none');
const selectedName = ref<string>(settings.data?.proxyConfig?.selectedName || '');
const mode = ref<string>(settings.data?.proxyConfig?.selectionMode || 'fixed');
const applyTo = ref<string>(settings.data?.proxyConfig?.applyTo || 'both');
const saving = ref(false);

const manualProxies = computed<ProxyNodeBrief[]>(
  () =>
    (settings.data?.proxyConfig?.manualProxies ?? []).map((p) => ({
      name: p.name,
      type: p.type,
      server: p.server,
      port: p.port,
      source: 'manual' as const
    }))
);
const subNodes = computed<ProxyNodeBrief[]>(() => settings.data?.proxyConfig?.parsedNodes ?? []);

const availableNodes = computed(() => (source.value === 'manual' ? manualProxies.value : subNodes.value));

const currentSelection = computed(() => {
  if (settings.data?.proxyConfig?.selectedSource === 'none') return null;
  return settings.data?.proxyConfig?.selectedName || '';
});

function fmt(v: number | null | undefined): string {
  return v == null ? '--' : `${v}ms`;
}

async function saveSelection() {
  if (source.value !== 'none' && !selectedName.value) return;
  saving.value = true;
  try {
    const r = await api.saveProxySelection({ source: source.value, name: selectedName.value, mode: mode.value, applyTo: applyTo.value });
    await settings.reload();
    Message.success(`已选择代理：${r.selectedName}（${r.proxy}）`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    saving.value = false;
  }
}
</script>

<style scoped>
.mb-3 {
  margin-bottom: 16px;
}
</style>
