import { http } from './http';
import type {
  AuthState,
  ChangeCredentialsInput,
  SystemHealth,
  UpdateInfo,
  SsoCheckResult,
  Grok2apiUploadResult,
  RemailOrderInput,
  RemailPickupInput,
  RemailMessageInput,
  MailCodeResult,
  GptSessionState,
  GptInspectResult,
  GptFillResult,
  GptSubmitResult
} from '@shared/ipc';
import type { AppSettings, Grok2apiSettings } from '@shared/settings';
import type { AccountRecord, RunStatus, TestResult, PaymentPayload } from '@shared/runEvents';

export interface RemailWallet {
  userId?: number;
  consumerBalance?: string;
  supplierAvailable?: string;
  supplierFrozen?: string;
  totalRecharged?: string;
  historicalSpend?: string;
  orderCount?: number;
  updatedAt?: string;
}
export interface RemailProductPrice {
  type: string;
  codePrice: number;
  purchasePrice: number;
  suffixes: string[];
}
export interface RemailPricingInfo {
  prices: RemailProductPrice[];
  unitPrice: number;
  projectId: number;
  serviceMode: string;
  emailSuffix: string;
}

async function get<T>(url: string): Promise<T> {
  const { data } = await http.get(url);
  return data as T;
}
async function post<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await http.post(url, body ?? {});
  return data as T;
}
async function put<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await http.put(url, body);
  return data as T;
}

/** 全部后端 API 方法 */
export const api = {
  // auth
  getAuthState: () => get<AuthState>('/api/auth/me'),
  login: (username: string, password: string) =>
    post<AuthState>('/api/auth/login', { username, password }),
  logout: () => post<{ ok: true }>('/api/auth/logout'),
  changeCredentials: (input: ChangeCredentialsInput) =>
    post<AuthState>('/api/auth/change', input),

  // settings
  getSettings: () => get<AppSettings>('/api/settings'),
  saveSettings: (s: AppSettings) => put<{ ok: true }>('/api/settings', s),

  // run
  startRegister: (args?: { runCount?: number }) =>
    post<{ runId: string }>('/api/run/start', args ?? {}),
  stopRegister: () => post<{ ok: true }>('/api/run/stop'),
  getStatus: () => get<RunStatus>('/api/run/status'),

  // GPT 注册机
  getGptState: () => get<GptSessionState>('/api/gpt/state'),
  startGpt: (args?: { runCount?: number }) =>
    post<{ runId: string }>('/api/gpt/start', args ?? {}),
  stopGpt: () => post<{ ok: true }>('/api/gpt/stop'),
  extractGptLink: () =>
    post<{ url: string | null; needManual: boolean; note?: string }>('/api/gpt/link/extract'),
  submitGptManualLink: (url: string) =>
    post<{ ok: true }>('/api/gpt/link/manual', { url }),
  inspectGptPayment: () => post<GptInspectResult>('/api/gpt/payment/inspect'),
  fillGptPayment: (payload: PaymentPayload) =>
    post<GptFillResult>('/api/gpt/payment/fill', payload),
  submitGptPayment: () => post<GptSubmitResult>('/api/gpt/payment/submit'),
  cancelGptPayment: () => post<{ ok: true }>('/api/gpt/payment/cancel'),

  // accounts
  listAccounts: () => get<AccountRecord[]>('/api/accounts'),

  // mail & sso
  getMailCode: (address: string) =>
    get<MailCodeResult>(`/api/mail/code?address=${encodeURIComponent(address)}`),
  checkSso: async (items: { id: string; sso: string }[]) => {
    // 测活可能触发浏览器化验活（启动浏览器+过CF验证），需要更长超时
    const { data } = await http.post<{ results: SsoCheckResult[] }>(
      '/api/sso/check',
      { items },
      { timeout: 120000 }
    );
    return data.results;
  },

  // manual code queue
  submitManualCode: (code: string) =>
    post<{ ok: true; queueLength: number }>('/api/manual-code', { code }),
  getManualCodeStatus: () => get<{ queueLength: number }>('/api/manual-code/status'),

  // manual email queue
  submitManualEmail: (email: string) =>
    post<{ ok: true; queueLength: number }>('/api/manual-email', { email }),
  getManualEmailStatus: () => get<{ queueLength: number }>('/api/manual-email/status'),

  // remail
  testRemail: () => get<TestResult>('/api/remail/test'),
  listRemailProjects: () => get<unknown>('/api/remail/projects'),
  listRemailResources: () => get<unknown>('/api/remail/resources'),
  listRemailOrders: () => get<unknown>('/api/remail/orders'),
  getRemailOrder: (orderNo: string) =>
    get<unknown>(`/api/remail/orders/${encodeURIComponent(orderNo)}`),
  createRemailOrder: (input: RemailOrderInput & { count?: number }) =>
    post<unknown>('/api/remail/orders', input),
  getRemailWallet: () => get<RemailWallet>('/api/remail/wallet'),
  getRemailPricing: () => get<RemailPricingInfo>('/api/remail/pricing'),
  pickupRemail: (input: RemailPickupInput) =>
    get<unknown>(
      `/api/remail/pickup?email=${encodeURIComponent(input.email)}&token=${encodeURIComponent(input.token)}`
    ),
  getRemailMessage: (input: RemailMessageInput) =>
    get<unknown>(
      `/api/remail/pickup/${input.messageId}?email=${encodeURIComponent(input.email)}&token=${encodeURIComponent(input.token)}`
    ),

  // grok2api
  testGrok2api: (settings?: Partial<Grok2apiSettings>) =>
    post<TestResult>('/api/grok2api/test', settings ?? {}),
  uploadToGrok2api: (input: { accountIds?: string[]; provider?: string }) =>
    post<Grok2apiUploadResult>('/api/grok2api/upload', input),
  getGrok2apiUploadedTokens: () =>
    get<{ tokens: string[] }>('/api/grok2api/uploaded-tokens'),

  // proxy
  parseSubscription: (input: { url: string; type: string; name?: string }) =>
    post<{ ok: true; nodeCount: number; nodeList: unknown[] }>('/api/proxy/subscription/parse', input),
  testProxyLatency: (node: unknown) =>
    post<{ nodeLatency: number | null; grokLatency: number | null }>('/api/proxy/test-latency', node),
  saveProxyManual: (input: { manualProxies?: unknown[]; parsedNodes?: unknown[] }) =>
    post<{ ok: true }>('/api/proxy/save-manual', input),
  saveProxySelection: (input: { source: string; name: string; mode?: string; applyTo?: string }) =>
    post<{ ok: true; selectedSource: string; selectedName: string; selectionMode: string; applyTo: string; proxy: string }>(
      '/api/proxy/save-selection',
      input
    ),

  // mail connection test
  testMail: (config: { apiBase: string; adminAuth: string; domain: string }) =>
    post<TestResult>('/api/test/mail', config),
  getCloudflareDomains: () => get<{ suffixes: string[] }>('/api/mail/cloudflare/domains'),
  generateCloudflareMail: (domain: string) =>
    post<{ ok: boolean; address: string; domain: string; poolCount: number; error?: string }>(
      '/api/mail/cloudflare/generate',
      { domain }
    ),
  getCloudflarePool: () =>
    get<{
      poolCount: number;
      items: { address: string; domain: string; createdAt: string }[];
    }>('/api/mail/cloudflare/pool'),

  // system
  getSystemHealth: () => get<SystemHealth>('/api/system/health'),
  checkUpdate: () => get<UpdateInfo>('/api/system/update-check'),
  getUpdateDetail: (versionCode?: number) =>
    post<UpdateInfo>('/api/system/update/detail', { versionCode: versionCode ?? 0 }),
  downloadUpdate: (versionCode?: number) =>
    post<{
      ok: boolean;
      versionName: string | null;
      versionCode: number | null;
      fileName: string | null;
      filePath: string | null;
      sizeBytes: number | null;
      sha256: string | null;
      error?: string;
    }>('/api/system/update/download', { versionCode: versionCode ?? 0 }),
  listUpdatePackages: () =>
    get<{ dir: string; packages: { fileName: string; sizeBytes: number; modifiedAt: string }[] }>(
      '/api/system/update/packages'
    ),
  applyUpdate: (versionCode?: number) =>
    post<{
      ok: boolean;
      versionName: string | null;
      versionCode: number | null;
      restarting?: boolean;
      error?: string;
    }>('/api/system/update/apply', { versionCode: versionCode ?? 0 })
};

export { onRegisterEvent } from './ws';
