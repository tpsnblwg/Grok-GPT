import type { RunEvent } from '@shared/runEvents';

type Listener = (event: RunEvent) => void;

const listeners = new Set<Listener>();
let ws: WebSocket | null = null;
let reconnectTimer: number | null = null;

function clearTimer() {
  if (reconnectTimer !== null) {
    window.clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}

function connect() {
  if (ws || listeners.size === 0) return;
  const url = new URL('/ws', window.location.href);
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(url.toString());
  ws.onmessage = (msg) => {
    try {
      const event = JSON.parse(String(msg.data)) as RunEvent;
      for (const listener of listeners) listener(event);
    } catch {
      /* ignore malformed frames */
    }
  };
  ws.onerror = () => {
    try {
      ws?.close();
    } catch {
      /* ignore */
    }
  };
  ws.onclose = () => {
    ws = null;
    if (listeners.size > 0) {
      clearTimer();
      reconnectTimer = window.setTimeout(() => {
        reconnectTimer = null;
        connect();
      }, 1500);
    }
  };
}

/** 订阅注册机实时事件，返回取消订阅函数 */
export function onRegisterEvent(cb: Listener): () => void {
  listeners.add(cb);
  connect();
  return () => {
    listeners.delete(cb);
    if (listeners.size === 0) {
      clearTimer();
      try {
        ws?.close();
      } catch {
        /* ignore */
      }
      ws = null;
    }
  };
}
