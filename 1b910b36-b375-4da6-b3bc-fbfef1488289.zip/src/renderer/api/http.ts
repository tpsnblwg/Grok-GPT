import axios from 'axios';

/** 统一 axios 实例：携带 Cookie，统一错误消息 */
export const http = axios.create({
  baseURL: '/',
  timeout: 20000,
  withCredentials: true
});

http.interceptors.response.use(
  (response) => response,
  (error) => {
    const data = error?.response?.data as Record<string, unknown> | undefined;
    const errorBody = data?.error as Record<string, unknown> | string | undefined;
    let message = '请求失败';
    if (errorBody && typeof errorBody === 'object' && typeof errorBody.message === 'string') {
      message = errorBody.message;
    } else if (typeof errorBody === 'string') {
      message = errorBody;
    } else if (data && typeof data.message === 'string') {
      message = data.message;
    } else if (error?.message) {
      message = error.message;
    }
    return Promise.reject(new Error(message));
  }
);
