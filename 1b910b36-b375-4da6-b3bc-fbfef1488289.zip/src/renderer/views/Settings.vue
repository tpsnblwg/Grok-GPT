<template>
  <div class="page">
    <a-card title="用户安全措施" size="small" class="mb-3">
      <a-form :model="pwdForm" layout="vertical">
        <a-row :gutter="16">
          <a-col :span="12">
            <a-form-item label="当前密码">
              <a-input-password v-model="pwdForm.currentPassword" placeholder="当前密码" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="新用户名">
              <a-input v-model="pwdForm.username" placeholder="新用户名" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="新密码">
              <a-input-password v-model="pwdForm.password" placeholder="新密码（至少 6 位）" />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="确认密码">
              <a-input-password v-model="pwdForm.confirmPassword" placeholder="确认密码" />
            </a-form-item>
          </a-col>
        </a-row>
        <a-button type="primary" :loading="savingPwd" @click="submitPwd">
          <template #icon><icon-lock /></template>修改账号密码
        </a-button>
      </a-form>
    </a-card>

    <SettingsForm />
    <ProxyConfig />
    <RemailTool />
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { useAuthStore } from '@renderer/stores/auth';
import { useSettingsStore } from '@renderer/stores/settings';
import SettingsForm from '@renderer/components/SettingsForm.vue';
import RemailTool from '@renderer/components/RemailTool.vue';
import ProxyConfig from '@renderer/components/ProxyConfig.vue';
import type { ChangeCredentialsInput } from '@shared/ipc';

const auth = useAuthStore();
const settings = useSettingsStore();

const pwdForm = reactive<ChangeCredentialsInput>({
  currentPassword: '',
  username: auth.username || '',
  password: '',
  confirmPassword: ''
});
const savingPwd = ref(false);

if (!settings.data) {
  void settings.reload().catch(() => undefined);
}

async function submitPwd() {
  if (!pwdForm.currentPassword || !pwdForm.username || !pwdForm.password || !pwdForm.confirmPassword) {
    Message.warning('请填写完整信息');
    return;
  }
  if (pwdForm.password !== pwdForm.confirmPassword) {
    Message.warning('两次输入的新密码不一致');
    return;
  }
  savingPwd.value = true;
  try {
    await auth.changeCredentials(pwdForm);
    Message.success('账号密码已更新');
    pwdForm.currentPassword = '';
    pwdForm.password = '';
    pwdForm.confirmPassword = '';
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    savingPwd.value = false;
  }
}
</script>

<style scoped>
.mb-3 {
  margin-bottom: 16px;
}
</style>
