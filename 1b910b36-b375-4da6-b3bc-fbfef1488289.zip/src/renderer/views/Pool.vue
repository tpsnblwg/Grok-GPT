<template>
  <div class="page">
    <a-row :gutter="16" class="mb-3">
      <a-col :span="6">
        <a-card><div class="metric-title">账号总量</div><div class="metric-value">{{ accounts.length }}</div></a-card>
      </a-col>
      <a-col :span="6">
        <a-card><div class="metric-title">含 SSO</div><div class="metric-value">{{ ssoCount }}</div></a-card>
      </a-col>
      <a-col :span="6">
        <a-card><div class="metric-title">验活存活</div><div class="metric-value">{{ ssoMap.size ? aliveCount : '--' }}</div></a-card>
      </a-col>
      <a-col :span="6">
        <a-card><div class="metric-title">最近时间</div><div class="metric-value metric-value-sm">{{ latest ? fmtBeijing(latest.createdAt, false) : '--' }}</div></a-card>
      </a-col>
    </a-row>

    <a-card class="mb-3">
      <a-space wrap>
        <a-checkbox :model-value="allChecked" @change="toggleAll">全选</a-checkbox>
        <a-button :loading="verifying" :disabled="accounts.length === 0" @click="verifyBatch">
          {{ selected.size > 0 ? `测活选中(${selected.size})` : '测活全部' }}
        </a-button>
        <a-button :disabled="selectedAccounts.length === 0" @click="exportSso(selectedAccounts)">选中·SSO</a-button>
        <a-button :disabled="selectedAccounts.length === 0" @click="exportAccounts(selectedAccounts)">选中·账号</a-button>
        <a-button @click="exportSso(accounts)">全部·SSO</a-button>
        <a-button @click="exportAccounts(accounts)">全部·账号</a-button>
        <a-button type="primary" :loading="uploading" :disabled="accounts.length === 0" @click="uploadToGrok2api">
          <template #icon><icon-upload /></template>{{ uploading ? '上传中…' : '上传到 grok2api' }}
        </a-button>
        <a-button :loading="loading" @click="reload">刷新</a-button>
      </a-space>
    </a-card>

    <a-empty v-if="accounts.length === 0" description="还没有账号记录。到「注册机」页跑一次任务。" />

    <a-row v-else :gutter="16">
      <a-col v-for="account in sortedAccounts" :key="account.id" :xs="24" :sm="12" :md="8" class="mb-3">
        <a-card size="small">
          <a-space direction="vertical" fill>
            <div class="account-head">
              <a-checkbox :model-value="selected.has(account.id)" @change="toggle(account.id)" />
              <span class="account-email">{{ account.email || '(无邮箱)' }}</span>
              <a-tag v-if="ssoMap.get(account.id)" :color="ssoMap.get(account.id)!.alive ? 'green' : 'red'">
                {{ ssoMap.get(account.id)!.alive ? '存活' : '失效' }}
              </a-tag>
            </div>

            <div class="account-meta">
              <a-tag :color="isUploaded(account) ? 'green' : 'orange'" size="small">
                {{ isUploaded(account) ? '已上传' : '待上传' }}
              </a-tag>
              <span class="account-time">注册 {{ fmtBeijing(account.createdAt) }}</span>
            </div>

            <div v-if="ssoMap.get(account.id)?.alive" class="sso-detail">
              <span>类型: {{ ssoMap.get(account.id)?.sessionTierId || '--' }}</span>
              <span v-if="ssoMap.get(account.id)?.quota">
                额度: {{ JSON.stringify(ssoMap.get(account.id)?.quota).slice(0, 80) }}
              </span>
            </div>

            <div class="cred-row">
              <span class="cred-label">密码</span>
              <span class="cred-value">{{ showPw.has(account.id) ? account.password || '(无)' : '••••••••' }}</span>
              <a-space>
                <a-button size="mini" @click="togglePw(account.id)">{{ showPw.has(account.id) ? '隐藏' : '显示' }}</a-button>
                <a-button size="mini" @click="copy(account.password, '密码')">复制</a-button>
              </a-space>
            </div>

            <div class="cred-row">
              <span class="cred-label">SSO</span>
              <span class="cred-value sso">
                {{ showSso.has(account.id) ? account.sso || '(无)' : account.sso ? account.sso.slice(0, 14) + '…' : '(无)' }}
              </span>
              <a-space>
                <a-button size="mini" @click="toggleSso(account.id)">{{ showSso.has(account.id) ? '收起' : '查看' }}</a-button>
                <a-button size="mini" @click="copy(account.sso, 'SSO')">复制</a-button>
              </a-space>
            </div>
          </a-space>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { useAccountsStore } from '@renderer/stores/accounts';
import { api } from '@renderer/api';
import { fmtBeijing } from '@renderer/lib/time';
import type { AccountRecord } from '@shared/runEvents';
import type { SsoCheckResult } from '@shared/ipc';

const accountsStore = useAccountsStore();
const accounts = computed(() => accountsStore.accounts);
const loading = computed(() => accountsStore.loading);
const sortedAccounts = computed(() =>
  [...accounts.value].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
);

const selected = ref<Set<string>>(new Set());
const ssoMap = ref<Map<string, SsoCheckResult>>(new Map());
const verifying = ref(false);
const uploading = ref(false);
const showPw = ref<Set<string>>(new Set());
const showSso = ref<Set<string>>(new Set());
const uploadedTokens = ref<Set<string>>(new Set());

function isUploaded(account: AccountRecord): boolean {
  return !!account.sso && uploadedTokens.value.has(account.sso.trim().replace(/^sso=/, ''));
}

const ssoCount = computed(() => accounts.value.filter((a) => a.sso).length);
const aliveCount = computed(() => [...ssoMap.value.values()].filter((r) => r.alive).length);
const latest = computed(() => accounts.value[0]);
const selectedAccounts = computed(() => accounts.value.filter((a) => selected.value.has(a.id)));
const allChecked = computed(
  () => accounts.value.length > 0 && selected.value.size === accounts.value.length
);

function toggle(id: string) {
  const next = new Set(selected.value);
  if (next.has(id)) next.delete(id);
  else next.add(id);
  selected.value = next;
}

function toggleAll(val: unknown) {
  selected.value = val ? new Set(accounts.value.map((a) => a.id)) : new Set();
}

function togglePw(id: string) {
  const next = new Set(showPw.value);
  if (next.has(id)) next.delete(id);
  else next.add(id);
  showPw.value = next;
}

function toggleSso(id: string) {
  const next = new Set(showSso.value);
  if (next.has(id)) next.delete(id);
  else next.add(id);
  showSso.value = next;
}

function download(filename: string, text: string) {
  const blob = new Blob([text + (text ? '\n' : '')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function stamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function exportSso(records: AccountRecord[]) {
  const lines = records.map((r) => r.sso).filter(Boolean);
  if (lines.length === 0) {
    Message.warning('没有可导出的 SSO');
    return;
  }
  download(`grok-sso-${stamp()}.txt`, lines.join('\n'));
  Message.success(`已导出 SSO ${lines.length} 条`);
}

function exportAccounts(records: AccountRecord[]) {
  if (records.length === 0) {
    Message.warning('没有可导出的账号');
    return;
  }
  const text = records.map((r) => `${r.email}----${r.password}----${r.sso}`).join('\n');
  download(`grok-accounts-${stamp()}.txt`, text);
  Message.success(`已导出账号 ${records.length} 条`);
}

async function copy(value: string, label: string) {
  if (!value) return;
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
    } else {
      // http://IP 等非安全上下文下 navigator.clipboard 不可用，用 execCommand 兜底
      const ta = document.createElement('textarea');
      ta.value = value;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    Message.success(`已复制${label}`);
  } catch {
    Message.error('复制失败');
  }
}

async function verifyBatch() {
  const targets = (selected.value.size > 0 ? accounts.value.filter((a) => selected.value.has(a.id)) : accounts.value).filter(
    (a) => a.sso
  );
  if (targets.length === 0) {
    Message.warning('没有可测活的账号');
    return;
  }
  verifying.value = true;
  try {
    const results = await api.checkSso(targets.map((a) => ({ id: a.id, sso: a.sso })));
    const next = new Map(ssoMap.value);
    for (const r of results) next.set(r.id, r);
    ssoMap.value = next;
    const alive = results.filter((r) => r.alive).length;
    Message.success(`测活完成，存活 ${alive} / ${results.length}`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    verifying.value = false;
  }
}

async function loadUploadedTokens() {
  try {
    const { tokens } = await api.getGrok2apiUploadedTokens();
    uploadedTokens.value = new Set(tokens.map((t) => t.trim().replace(/^sso=/, '')));
  } catch {
    /* ignore */
  }
}

async function reload() {
  try {
    await accountsStore.reload();
    await loadUploadedTokens();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function uploadToGrok2api() {
  const targets = selected.value.size > 0 ? selectedAccounts.value : accounts.value;
  if (targets.length === 0) {
    Message.warning('没有可上传的账号');
    return;
  }
  uploading.value = true;
  try {
    const result = await api.uploadToGrok2api({
      accountIds: selected.value.size > 0 ? targets.map((a) => a.id) : undefined
    });
    if (result.ok) {
      Message.success(`上传到 grok2api 成功：${result.message}`);
    } else {
      Message.error(`上传到 grok2api 失败：${result.message}`);
    }
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    uploading.value = false;
  }
}

onMounted(() => {
  void reload();
});
</script>

<style scoped>
.metric-title {
  font-size: 13px;
  color: var(--color-text-2);
}
.metric-value {
  margin-top: 8px;
  font-size: 26px;
  font-weight: 600;
}
.metric-value-sm {
  font-size: 14px;
  word-break: break-all;
}
.account-head {
  display: flex;
  align-items: center;
  gap: 8px;
}
.account-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}
.account-time {
  font-size: 12px;
  color: var(--color-text-3);
  font-family: monospace;
}
.sso-detail {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 12px;
  color: var(--color-text-2);
  font-family: monospace;
  word-break: break-all;
}
.account-email {
  font-family: monospace;
  font-weight: 600;
  word-break: break-all;
  flex: 1;
}
.cred-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}
.cred-label {
  width: 34px;
  color: var(--color-text-3);
  flex-shrink: 0;
}
.cred-value {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-family: monospace;
}
.cred-value.sso {
  font-size: 12px;
}
.mb-3 {
  margin-bottom: 16px;
}
</style>
