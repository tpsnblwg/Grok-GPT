<template>
  <div class="login-wrap">
    <div class="bg-decoration">
      <div class="orb orb-1"></div>
      <div class="orb orb-2"></div>
      <div class="orb orb-3"></div>
      <div class="grid-overlay"></div>
    </div>

    <a-card class="login-card" :bordered="false">
      <div class="login-header">
        <div class="logo">🤖</div>
        <a-typography-title :heading="4" style="margin: 10px 0 2px">grok-reg-tool</a-typography-title>
        <a-typography-text type="secondary">可自部署的 Grok / GPT 注册机 Web 控制台</a-typography-text>
      </div>

      <div class="machine-switch">
        <a-radio-group v-model="machine" type="button" style="width: 100%">
          <a-radio value="grok">Grok 注册机</a-radio>
          <a-radio value="gpt">GPT 注册机</a-radio>
        </a-radio-group>
      </div>

      <a-form :model="form" layout="vertical" style="margin-top: 18px" @submit="onSubmit">
        <a-form-item label="用户名" field="username" :rules="[{ required: true, message: '请输入用户名' }]">
          <a-input v-model="form.username" placeholder="用户名" allow-clear>
            <template #prefix><icon-user /></template>
          </a-input>
        </a-form-item>
        <a-form-item label="密码" field="password" :rules="[{ required: true, message: '请输入密码' }]">
          <a-input-password v-model="form.password" placeholder="密码" allow-clear>
            <template #prefix><icon-lock /></template>
          </a-input-password>
        </a-form-item>
        <a-button type="primary" html-type="submit" long :loading="loading">
          进入{{ machine === 'gpt' ? 'GPT' : 'Grok' }}注册机
        </a-button>
      </a-form>

      <div class="feature-row">
        <span v-if="machine === 'grok'">🤖 自动注册</span>
        <span v-if="machine === 'grok'">📧 邮箱接码</span>
        <span v-if="machine === 'grok'">🔑 SSO 验活</span>
        <span v-if="machine === 'gpt'">🤖 GPT 注册</span>
        <span v-if="machine === 'gpt'">✨ Plus 检测</span>
        <span v-if="machine === 'gpt'">💳 支付表单</span>
        <span>🌐 代理支持</span>
      </div>

      <div class="login-footer">
        <span>默认账号 admin/admin · 首次登录强制修改</span>
        <span class="version">v0.1.7 · MIT</span>
      </div>
    </a-card>
  </div>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { Message } from '@arco-design/web-vue';
import { useAuthStore } from '@renderer/stores/auth';
import type { MachineType } from '@shared/runEvents';

const router = useRouter();
const auth = useAuthStore();
const form = reactive({ username: 'admin', password: '' });
const loading = ref(false);

const machine = computed({
  get: () => auth.machine,
  set: (v: MachineType) => auth.setMachine(v)
});

async function onSubmit() {
  loading.value = true;
  try {
    await auth.login(form.username, form.password);
    router.push({ name: auth.machine === 'gpt' ? 'gpt' : 'register' });
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.login-wrap {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #0b1526 0%, #142a4a 50%, #0d1f38 100%);
  position: relative;
  overflow: hidden;
}

.bg-decoration {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.grid-overlay {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
  background-size: 44px 44px;
}
.orb {
  position: absolute;
  border-radius: 50%;
  filter: blur(60px);
  opacity: 0.5;
}
.orb-1 {
  width: 340px;
  height: 340px;
  background: #165dff;
  top: -80px;
  left: -60px;
}
.orb-2 {
  width: 280px;
  height: 280px;
  background: #00b42a;
  bottom: -60px;
  right: -40px;
  opacity: 0.35;
}
.orb-3 {
  width: 200px;
  height: 200px;
  background: #ff7d00;
  top: 55%;
  left: 60%;
  opacity: 0.25;
}

.login-card {
  width: 400px;
  max-width: 92vw;
  border-radius: 14px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.45);
  z-index: 1;
}

.login-header {
  text-align: center;
}
.machine-switch {
  margin-top: 16px;
}
.logo {
  font-size: 44px;
  line-height: 1;
}
.feature-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
  margin-top: 18px;
}
.feature-row span {
  font-size: 12px;
  color: var(--color-text-2);
  background: var(--color-fill-2);
  border-radius: 12px;
  padding: 4px 10px;
}
.login-footer {
  margin-top: 14px;
  text-align: center;
  font-size: 12px;
  color: var(--color-text-3);
}
.login-footer .version {
  display: block;
  margin-top: 4px;
}
</style>
