<template>
  <div class="page">
    <a-row :gutter="16" class="mb-3">
      <a-col :xs="24" :md="16">
        <a-card title="GPT 注册机运行台">
          <template #extra>
            <a-button v-if="registering" type="primary" status="danger" @click="stop">
              <template #icon><icon-poweroff /></template>停止
            </a-button>
            <a-button v-else type="primary" @click="start">
              <template #icon><icon-play-arrow /></template>开始注册
            </a-button>
          </template>

          <a-descriptions :column="2" size="small" bordered>
            <a-descriptions-item label="当前阶段">{{ phaseText }}</a-descriptions-item>
            <a-descriptions-item label="Plus 试用资格">
              <a-tag v-if="state.plusEligible === true" color="green">具备</a-tag>
              <a-tag v-else-if="state.plusEligible === false" color="orange">不具备</a-tag>
              <span v-else class="muted">未检测</span>
            </a-descriptions-item>
            <a-descriptions-item label="当前账号">{{ state.email || '—' }}</a-descriptions-item>
            <a-descriptions-item label="支付通道">{{ state.channel || '—' }}</a-descriptions-item>
          </a-descriptions>

          <a-form-item v-if="!registering" label="注册轮数（1-50）" style="margin-top: 12px">
            <a-slider v-model="runCount" :min="1" :max="50" style="max-width: 320px" />
          </a-form-item>
        </a-card>
      </a-col>

      <a-col :xs="24" :md="8">
        <a-card title="流程说明">
          <a-steps direction="vertical" :current="stepIndex" size="small">
            <a-step title="自动注册" description="邮箱 + OTP + about-you" />
            <a-step title="Plus 试用检测" description="检测是否具备试用资格" />
            <a-step title="提炼支付链接" description="pay.153.ink / 手动粘贴" />
            <a-step title="填写支付信息" description="识别表单并填表" />
            <a-step title="确认并提交" description="脱敏摘要确认后提交" />
          </a-steps>
        </a-card>
      </a-col>
    </a-row>

    <!-- 收信方式（与 Grok 一致） -->
    <a-card title="收信方式" size="small" class="mb-3">
      <a-space direction="vertical" fill>
        <a-radio-group v-model="mailMode" type="button" @change="onMailModeChange">
          <a-radio value="auto">自动</a-radio>
          <a-radio value="remail">Remail</a-radio>
          <a-radio value="cloudflare">Cloudflare</a-radio>
        </a-radio-group>
        <a-typography-text type="secondary" style="font-size: 12px">
          自动：优先从 Remail 手动队列取邮箱，队列为空时自动创建 Cloudflare 临时邮箱；
          Remail：仅从 Remail 手动队列取；Cloudflare：仅使用 Cloudflare 临时邮箱。
        </a-typography-text>

        <template v-if="mailMode === 'cloudflare'">
          <a-space>
            <a-select v-model="cfDomain" placeholder="选择邮箱后缀" style="width: 220px" allow-search>
              <a-option v-for="d in cfDomains" :key="d" :value="d">{{ d }}</a-option>
            </a-select>
            <a-button type="primary" :loading="cfGenerating" :disabled="!cfDomain" @click="generateCf">
              <template #icon><icon-sync /></template>随机生成邮箱
            </a-button>
            <a-button size="small" :loading="cfLoading" @click="loadCfInfo">刷新</a-button>
          </a-space>
          <a-space wrap>
            <a-tag v-if="cfLastAddress" color="green">已生成：{{ cfLastAddress }}</a-tag>
            <a-tag v-if="cfPoolCount > 0" color="arcoblue">邮箱池 {{ cfPoolCount }} 个待用</a-tag>
          </a-space>
          <a-alert v-if="!cfConfigOk" type="warning" style="font-size: 12px">
            尚未配置 Cloudflare 邮箱后端，请先在「配置 → 邮件后端」填写 apiBase / adminAuth / domain。
          </a-alert>
        </template>
      </a-space>
    </a-card>

    <!-- 支付链接 -->
    <a-card v-if="state.email" title="支付链接" size="small" class="mb-3">
      <a-space direction="vertical" fill>
        <a-space>
          <a-button type="primary" size="small" :loading="extracting" :disabled="!state.email" @click="extractLink">
            <template #icon><icon-link /></template>提炼支付链接
          </a-button>
          <a-typography-text type="secondary" style="font-size: 12px">
            {{ extractMode === 'manual' ? '将手动粘贴支付链接' : extractMode === 'browser' ? '将打开提链网页自动填表提链' : '将调用配置的提链服务（external_api / http）' }}
          </a-typography-text>
        </a-space>
        <a-space wrap>
          <a-tag v-if="state.link" color="green">链接已就绪</a-tag>
          <a-tag v-if="state.channel">{{ state.channel }}</a-tag>
        </a-space>
        <a-input-group>
          <a-input v-model="manualUrl" placeholder="若提炼方式为手动，请在此粘贴支付链接" allow-clear />
          <a-button :disabled="!manualUrl" @click="submitManualLink">粘贴链接</a-button>
        </a-input-group>
      </a-space>
    </a-card>

    <!-- 支付表单与确认 -->
    <a-card v-if="state.plusEligible === true" title="支付信息" size="small" class="mb-3">
      <template v-if="!fields.length && !summary">
        <a-empty description="请先提炼支付链接并识别表单">
          <a-button type="primary" :disabled="!state.link" :loading="inspecting" @click="inspect">
            <template #icon><icon-search /></template>打开支付页并识别表单
          </a-button>
        </a-empty>
      </template>

      <PaymentForm v-else-if="!summary" :fields="fields" :loading="filling" @submit="onFill" />

      <template v-else>
        <a-alert type="info" title="待提交信息（已脱敏）">
          <a-descriptions :column="2" size="small" bordered>
            <a-descriptions-item label="卡号">{{ summary.cardNumber }}</a-descriptions-item>
            <a-descriptions-item label="CVV">{{ summary.cvv }}</a-descriptions-item>
            <a-descriptions-item label="过期时间">{{ summary.expiry }}</a-descriptions-item>
            <a-descriptions-item label="国家/地区">{{ summary.country }}</a-descriptions-item>
            <a-descriptions-item label="持卡人">{{ summary.name }}</a-descriptions-item>
            <a-descriptions-item label="邮箱">{{ summary.email }}</a-descriptions-item>
          </a-descriptions>
          <template #extra>
            <a-tag color="arcoblue">目标页面已就绪，提交前请人工核对</a-tag>
          </template>
        </a-alert>
        <a-space style="margin-top: 12px">
          <a-button type="primary" status="danger" :loading="submitting" @click="submit">
            <template #icon><icon-check /></template>确认提交
          </a-button>
          <a-button @click="cancel">取消</a-button>
        </a-space>
      </template>
    </a-card>

    <!-- 提交结果 -->
    <a-card v-if="submitStatus" title="提交结果" size="small" class="mb-3">
      <a-result :status="submitStatus === 'success' ? 'success' : 'warning'">
        <template #title>{{ submitResultText }}</template>
        <template #subtitle>{{ submitMessage }}</template>
      </a-result>
    </a-card>

    <a-collapse class="mb-3">
      <a-collapse-item key="config" header="GPT 配置（注册与支付参数）">
        <a-form v-if="gptDraft" :model="gptDraft" layout="vertical">
          <a-alert v-if="gptDraft.payment.extractMode === 'browser'" type="info" style="margin-bottom: 12px">
            <b>浏览器驱动提链（pay.153.ink）需填写/选择：</b>
            入口代理池（必填，每行一个）、支付通道、国家/地区、币种、订阅类型、失败重试次数；
            Access Token 将自动使用已注册账号的 token。PayPal 模式的国家/币种会按代理池自动识别。
          </a-alert>
          <a-row :gutter="12">
            <a-col :xs="24" :md="8">
              <a-form-item label="注册轮数"><a-slider v-model="gptDraft.runCount" :min="1" :max="50" /></a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="固定注册密码（留空自动生成）">
                <a-input v-model="gptDraft.registerPassword" placeholder="留空自动生成强密码" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="显示名（about-you）">
                <a-input v-model="gptDraft.displayName" placeholder="留空随机" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="出生日期（YYYY-MM-DD）">
                <a-input v-model="gptDraft.birthDate" placeholder="留空随机成年人" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="12" :md="6">
              <a-form-item label="使用代理访问（chatgpt.com）">
                <a-switch v-model="gptDraft.useProxy" />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="18">
              <a-form-item label="注册代理地址">
                <a-input v-model="gptDraft.proxy" placeholder="http://user:pass@host:port 或 socks5://user:pass@host:port" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="支付链接提炼方式">
                <a-select v-model="gptDraft.payment.extractMode">
                  <a-option value="manual">手动粘贴</a-option>
                  <a-option value="external_api">CDK 提链服务</a-option>
                  <a-option value="http">HTTP 提链 API</a-option>
                  <a-option value="browser">浏览器驱动（打开网页填表）</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="提链类型">
                <a-select v-model="gptDraft.payment.linkType">
                  <a-option value="paypal">paypal</a-option>
                  <a-option value="pix">pix</a-option>
                  <a-option value="upi">upi</a-option>
                  <a-option value="kakao_pay">kakao_pay</a-option>
                  <a-option value="ideal">ideal</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="提链 CDK">
                <a-input-password v-model="gptDraft.payment.cdk" placeholder="external_api 模式必填" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="8">
              <a-form-item label="支付通道">
                <a-select v-model="gptDraft.payment.channel">
                  <a-option v-for="c in channelOptions" :key="c.value" :value="c.value">{{ c.label }}</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="12" :md="6">
              <a-form-item label="国家/地区">
                <a-select v-model="gptDraft.payment.country" allow-search>
                  <a-option v-for="c in countryOptions" :key="c.code" :value="c.code">{{ c.label }}</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="12" :md="6">
              <a-form-item label="币种">
                <a-select v-model="gptDraft.payment.currency">
                  <a-option v-for="c in currencyOptions" :key="c" :value="c">{{ c }}</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="12" :md="6">
              <a-form-item label="订阅类型">
                <a-select v-model="gptDraft.payment.plan">
                  <a-option v-for="p in planOptions" :key="p.value" :value="p.value">{{ p.label }}</a-option>
                </a-select>
              </a-form-item>
            </a-col>
            <a-col :xs="12" :md="6">
              <a-form-item label="Plus 试用检测">
                <a-switch v-model="gptDraft.payment.plusTrialCheck" />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链服务地址（external_api/http 模式）">
                <a-input v-model="gptDraft.payment.extractEndpoint" placeholder="https://..." allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链 API Token">
                <a-input-password v-model="gptDraft.payment.extractToken" placeholder="选填" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链网页地址（browser 模式）">
                <a-input v-model="gptDraft.payment.extractUrl" placeholder="https://pay.153.ink/" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链失败重试次数（browser）">
                <a-input-number v-model="gptDraft.payment.retryCount" :min="1" :max="50" style="width: 100%" />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="Plus 优惠 Campaign（选填）">
                <a-input v-model="gptDraft.payment.promoCampaign" placeholder="例如 plus-1-month-free" allow-clear />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链入口代理池（browser 必填，每行一个）">
                <a-textarea v-model="gptDraft.payment.entryProxy" placeholder="host:port:user:pass" :auto-size="{ minRows: 2, maxRows: 5 }" />
              </a-form-item>
            </a-col>
            <a-col :xs="24" :md="12">
              <a-form-item label="提链出口代理池（browser，可留空）">
                <a-textarea v-model="gptDraft.payment.exitProxy" placeholder="host:port:user:pass" :auto-size="{ minRows: 2, maxRows: 5 }" />
              </a-form-item>
            </a-col>
          </a-row>
          <a-button type="primary" :loading="savingConfig" @click="saveGptConfig">保存 GPT 配置</a-button>
        </a-form>
      </a-collapse-item>
    </a-collapse>

    <RemailInboxPanel />
    <LogPanel />
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { api, onRegisterEvent } from '@renderer/api';
import { useSettingsStore } from '@renderer/stores/settings';
import LogPanel from '@renderer/components/LogPanel.vue';
import PaymentForm from '@renderer/components/PaymentForm.vue';
import RemailInboxPanel from '@renderer/components/RemailInboxPanel.vue';
import type { GptSessionState } from '@shared/ipc';
import type { GptSettings } from '@shared/settings';
import type {
  PaymentField,
  PaymentMaskedSummary,
  PaymentPayload,
  PaymentSubmitStatus
} from '@shared/runEvents';

const settings = useSettingsStore();
const state = ref<GptSessionState>({ phase: 'idle', runId: null });
const runCount = ref(1);
const fields = ref<PaymentField[]>([]);
const summary = ref<PaymentMaskedSummary | null>(null);
const manualUrl = ref('');
const extracting = ref(false);
const inspecting = ref(false);
const filling = ref(false);
const submitting = ref(false);
const submitStatus = ref<PaymentSubmitStatus | null>(null);
const submitMessage = ref('');

const gptDraft = ref<GptSettings | null>(null);
const savingConfig = ref(false);

watch(
  () => settings.data?.gpt,
  (g) => {
    if (g && !gptDraft.value) {
      gptDraft.value = JSON.parse(JSON.stringify(g));
    }
  },
  { immediate: true }
);

async function saveGptConfig() {
  if (!gptDraft.value || !settings.data) return;
  savingConfig.value = true;
  try {
    settings.data.gpt = gptDraft.value;
    await api.saveSettings(settings.data);
    await settings.reload();
    Message.success('GPT 配置已保存');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    savingConfig.value = false;
  }
}

// ===== pay.153.ink 提链参数的可选项（与网页一致） =====
const planOptions = [
  { value: 'plus', label: 'Plus · 个人订阅' },
  { value: 'pro', label: 'Pro · 专业计划' },
  { value: 'team', label: 'Team · 工作空间' },
  { value: 'codex', label: 'Codex · 低价空间' }
];
const channelOptions = [
  { value: 'hosted', label: 'Hosted · 官方支付长链' },
  { value: 'ph_short', label: 'PH 菲律宾短链' },
  { value: 'paypal', label: 'PayPal · Approve 跳转' },
  { value: 'ideal', label: 'iDEAL · 荷兰银行支付' },
  { value: 'upi', label: 'UPI · 印度二维码' },
  { value: 'pix', label: 'PIX · 巴西即时支付' },
  { value: 'momo', label: 'MoMo · 越南电子钱包' },
  { value: 'gcash', label: 'GCash · 菲律宾电子钱包' },
  { value: 'kakao', label: 'Kakao Pay · 韩国' }
];
const countryOptions = [
  { code: 'US', label: 'US · 美国' },
  { code: 'DE', label: 'DE · 德国' },
  { code: 'FR', label: 'FR · 法国' },
  { code: 'NL', label: 'NL · 荷兰' },
  { code: 'IN', label: 'IN · 印度' },
  { code: 'BR', label: 'BR · 巴西' },
  { code: 'VN', label: 'VN · 越南' },
  { code: 'GB', label: 'GB · 英国' },
  { code: 'JP', label: 'JP · 日本' },
  { code: 'KR', label: 'KR · 韩国' },
  { code: 'PH', label: 'PH · 菲律宾' },
  { code: 'AU', label: 'AU · 澳大利亚' },
  { code: 'CA', label: 'CA · 加拿大' }
];
const currencyOptions = ['USD', 'EUR', 'INR', 'BRL', 'GBP', 'JPY', 'KRW', 'VND', 'PHP', 'AUD', 'CAD'];

// ===== 收信方式（与 Grok 一致） =====
const mailMode = ref<'auto' | 'remail' | 'cloudflare'>('auto');
const cfDomains = ref<string[]>([]);
const cfDomain = ref('');
const cfGenerating = ref(false);
const cfLoading = ref(false);
const cfLastAddress = ref('');
const cfPoolCount = ref(0);
const cfConfigOk = computed(() => !!settings.data?.mail?.apiBase && !!settings.data?.mail?.adminAuth);

watch(
  () => settings.data?.mail?.mode,
  (val) => {
    if (val === 'remail' || val === 'cloudflare' || val === 'auto') mailMode.value = val;
    else mailMode.value = 'auto';
  },
  { immediate: true }
);

async function onMailModeChange() {
  if (!settings.data) return;
  settings.data.mail.mode = mailMode.value;
  try {
    await api.saveSettings(settings.data);
    await settings.reload();
    Message.success(`已切换收信方式：${mailMode.value}`);
    if (mailMode.value === 'cloudflare') await loadCfInfo();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function loadCfInfo() {
  cfLoading.value = true;
  try {
    const [d, p] = await Promise.all([
      api.getCloudflareDomains(),
      api.getCloudflarePool().catch(() => ({ poolCount: 0, items: [] }))
    ]);
    cfDomains.value = d.suffixes ?? [];
    cfPoolCount.value = p.poolCount ?? 0;
    if (cfDomains.value.length && !cfDomain.value) cfDomain.value = cfDomains.value[0];
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    cfLoading.value = false;
  }
}

async function generateCf() {
  if (!cfDomain.value) {
    Message.warning('请先选择邮箱后缀');
    return;
  }
  cfGenerating.value = true;
  cfLastAddress.value = '';
  try {
    const r = await api.generateCloudflareMail(cfDomain.value);
    if (!r.ok) {
      Message.error(r.error || '生成失败');
      return;
    }
    cfLastAddress.value = r.address;
    cfPoolCount.value = r.poolCount;
    Message.success(`已生成邮箱并入池：${r.address}`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    cfGenerating.value = false;
  }
}

let offEvent: (() => void) | null = null;

const registering = computed(() => state.value.phase === 'registering');
const extractMode = computed(() => settings.data?.gpt?.payment?.extractMode ?? 'manual');

const phaseTextMap: Record<string, string> = {
  idle: '空闲',
  registering: '注册中',
  'plus-check': 'Plus 资格检测',
  'extracting-link': '提炼支付链接',
  'awaiting-payment': '等待支付信息',
  inspecting: '识别表单',
  'awaiting-confirm': '等待确认',
  submitting: '提交中',
  done: '完成',
  error: '出错'
};
const phaseText = computed(() => phaseTextMap[state.value.phase] ?? state.value.phase);

const stepIndex = computed(() => {
  switch (state.value.phase) {
    case 'registering':
      return 0;
    case 'extracting-link':
      return 1;
    case 'awaiting-payment':
      return fields.value.length ? 3 : 2;
    case 'inspecting':
      return 3;
    case 'awaiting-confirm':
      return 4;
    case 'done':
      return 5;
    default:
      return 0;
  }
});

const submitResultText = computed(() => {
  if (submitStatus.value === 'success') return '支付提交成功';
  if (submitStatus.value === 'needs_verification') return '需要额外验证';
  if (submitStatus.value === 'page_changed') return '页面结构变化';
  return '提交失败';
});

async function refreshState() {
  try {
    state.value = await api.getGptState();
    runCount.value = settings.data?.gpt?.runCount ?? 1;
  } catch {
    /* ignore */
  }
}

async function start() {
  try {
    summary.value = null;
    fields.value = [];
    submitStatus.value = null;
    await api.startGpt({ runCount: runCount.value });
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function stop() {
  try {
    await api.stopGpt();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function extractLink() {
  if (extractMode.value === 'browser' && !(settings.data?.gpt?.payment?.entryProxy?.trim())) {
    Message.warning('浏览器驱动提链需先填写入口代理池（必填）');
    return;
  }
  extracting.value = true;
  try {
    const r = await api.extractGptLink();
    if (r.needManual) {
      Message.info('请在下方粘贴支付链接');
    } else if (r.url) {
      Message.success('支付链接已提炼');
    }
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    extracting.value = false;
  }
}

async function submitManualLink() {
  try {
    await api.submitGptManualLink(manualUrl.value);
    manualUrl.value = '';
    Message.success('支付链接已接收');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function inspect() {
  inspecting.value = true;
  try {
    const r = await api.inspectGptPayment();
    fields.value = r.fields ?? [];
    Message.success(`识别到 ${fields.value.length} 个表单字段`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    inspecting.value = false;
  }
}

async function onFill(payload: PaymentPayload) {
  filling.value = true;
  try {
    const r = await api.fillGptPayment(payload);
    summary.value = r.summary;
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    filling.value = false;
  }
}

async function submit() {
  submitting.value = true;
  try {
    const r = await api.submitGptPayment();
    submitStatus.value = r.status;
    submitMessage.value = r.message;
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    submitting.value = false;
  }
}

async function cancel() {
  try {
    await api.cancelGptPayment();
  } catch {
    /* ignore */
  }
  summary.value = null;
  fields.value = [];
}

onMounted(() => {
  void settings.reload().catch(() => undefined);
  void refreshState();
  // 等 settings 加载完成后再加载 Cloudflare 后缀/邮箱池信息
  setTimeout(() => {
    if (settings.data?.mail?.mode === 'cloudflare') void loadCfInfo();
  }, 400);
  offEvent = onRegisterEvent((e) => {
    if (e.type === 'gpt-phase') state.value.phase = e.phase;
    else if (e.type === 'gpt-plus') state.value.plusEligible = e.eligible;
    else if (e.type === 'gpt-link') {
      state.value.link = e.url;
      state.value.channel = e.channel;
    } else if (e.type === 'gpt-payment-fields') {
      fields.value = e.fields;
    } else if (e.type === 'gpt-payment-result') {
      submitStatus.value = e.status;
      submitMessage.value = e.message;
    }
  });
});

onBeforeUnmount(() => {
  if (offEvent) offEvent();
});
</script>

<style scoped>
.mb-3 {
  margin-bottom: 16px;
}
.muted {
  color: var(--color-text-3);
  font-size: 12px;
}
</style>
