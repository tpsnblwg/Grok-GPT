<template>
  <div class="page">
    <a-card class="mb-3">
      <a-space direction="vertical" size="small" fill>
        <a-typography-title :heading="4" style="margin: 0">{{ greeting }}, {{ auth.username }}</a-typography-title>
        <a-typography-text type="secondary">{{ nowText }}（北京时间）</a-typography-text>
        <a-space>
          <a-tag>v{{ update?.current ?? '...' }}</a-tag>
          <a-button v-if="update?.hasUpdate" size="mini" type="primary" @click="loadUpdate">
            有新版本 {{ update.latest }}
          </a-button>
          <a-button v-else size="mini" :loading="updateLoading" @click="loadUpdate">
            {{ update?.error || '检查更新' }}
          </a-button>
          <a-tag v-if="update?.source === 'auth'" color="arcoblue">授权系统源</a-tag>
          <a-tag v-if="update?.forceUpdate" color="red">强制更新</a-tag>
          <a-button
            v-if="update?.hasUpdate && update?.package?.downloadUrl && !downloadResult?.ok"
            size="mini"
            type="primary"
            status="warning"
            :loading="downloading"
            @click="downloadUpdate"
          >
            下载更新包
          </a-button>
          <a-button
            v-if="downloadResult?.ok"
            size="mini"
            type="primary"
            status="success"
            @click="goUpdatePage"
          >
            前往更新页面
          </a-button>
        </a-space>
        <a-typography-text
          v-if="update?.source === 'auth' && update?.updateLog"
          type="secondary"
          style="display: block; white-space: pre-wrap; font-size: 12px; margin-top: 4px"
        >
          更新日志：{{ update.updateLog }}
        </a-typography-text>
        <a-typography-text
          v-if="downloadResult?.ok && downloadResult?.filePath"
          type="success"
          style="display: block; font-size: 12px; margin-top: 4px"
        >
          更新包已下载：{{ downloadResult.filePath }}（{{ (downloadResult.sizeBytes ?? 0) / 1024 / 1024 >= 1 ? ((downloadResult.sizeBytes ?? 0) / 1024 / 1024).toFixed(2) + ' MB' : ((downloadResult.sizeBytes ?? 0) / 1024).toFixed(2) + ' KB' }}）
        </a-typography-text>
        <a-typography-text v-if="downloadResult?.error" type="danger" style="display: block; font-size: 12px; margin-top: 4px">
          下载失败：{{ downloadResult.error }}
        </a-typography-text>
      </a-space>
    </a-card>

    <a-row :gutter="16" class="mb-3">
      <a-col :xs="24" :span="8">
        <a-card>
          <div class="metric-title">账号总量</div>
          <div class="metric-value">{{ accounts.accounts.length }}</div>
          <div class="sub">含 SSO {{ ssoCount }} 个</div>
        </a-card>
      </a-col>
      <a-col :xs="24" :span="8">
        <a-card>
          <div class="metric-title">当前任务</div>
          <div class="metric-value metric-value-text">{{ run.status.phase }}</div>
          <div class="sub">{{ run.status.runId ? 'run ' + run.status.runId.slice(0, 8) : '暂无运行任务' }}</div>
        </a-card>
      </a-col>
      <a-col :xs="24" :span="8">
        <a-card>
          <div class="metric-title">系统体检</div>
          <div class="metric-value metric-value-text">{{ health ? health.summary.ok + '/' + health.summary.total : '--' }}</div>
          <div class="sub">{{ health?.summary.error ? health.summary.error + ' 项需要处理' : '依赖与配置检查' }}</div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="16">
      <a-col :xs="24" :md="14">
        <a-card title="系统体检" :bordered="false">
          <template #extra>
            <a-button size="mini" :loading="healthLoading" @click="loadHealth">重新检查</a-button>
          </template>
          <a-list v-if="health" :data="health.checks" size="small">
            <template #item="{ item }">
              <a-list-item>
                <a-space>
                  <a-tag :color="checkColor(item.level)">{{ item.level }}</a-tag>
                  <b>{{ item.label }}</b>
                </a-space>
                <template #extra>
                  <span class="muted">{{ item.message }}</span>
                </template>
              </a-list-item>
            </template>
          </a-list>
          <a-empty v-else description="正在读取体检结果…" />
        </a-card>
      </a-col>
      <a-col :xs="24" :md="10">
        <a-card title="最近号池" :bordered="false">
          <a-descriptions :column="1" size="small" bordered>
            <a-descriptions-item label="邮箱后端">{{ settings.data?.mail.apiBase || '未配置' }}</a-descriptions-item>
            <a-descriptions-item label="代理配置">{{ settings.data?.proxy || '直接连接' }}</a-descriptions-item>
            <a-descriptions-item label="最近账号">{{ latest?.email || '暂无记录' }}</a-descriptions-item>
            <a-descriptions-item label="最近时间">{{ latest ? fmtBeijing(latest.createdAt) : '等待首次运行' }}</a-descriptions-item>
          </a-descriptions>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@renderer/stores/auth';
import { useAccountsStore } from '@renderer/stores/accounts';
import { useRunStore } from '@renderer/stores/run';
import { useSettingsStore } from '@renderer/stores/settings';
import { api } from '@renderer/api';
import { fmtBeijing, nowBeijing } from '@renderer/lib/time';
import type { SystemHealth, UpdateInfo } from '@shared/ipc';

const auth = useAuthStore();
const accounts = useAccountsStore();
const run = useRunStore();
const settings = useSettingsStore();
const router = useRouter();

const health = ref<SystemHealth | null>(null);
const healthLoading = ref(false);
const update = ref<UpdateInfo | null>(null);
const updateLoading = ref(false);
const downloading = ref(false);
const downloadResult = ref<{
  ok: boolean;
  versionName: string | null;
  versionCode: number | null;
  fileName: string | null;
  filePath: string | null;
  sizeBytes: number | null;
  sha256: string | null;
  error?: string;
} | null>(null);

const ssoCount = computed(() => accounts.accounts.filter((a) => a.sso).length);
const latest = computed(() => accounts.accounts[0]);
const greeting = computed(() => {
  const hour = new Date().getHours();
  if (hour < 6) return '夜深了，注意休息';
  if (hour < 11) return '早上好';
  if (hour < 14) return '中午好';
  if (hour < 18) return '下午好';
  return '晚上好';
});
const nowText = computed(() => nowBeijing());

function checkColor(level: string): string {
  if (level === 'ok') return 'green';
  if (level === 'warn') return 'orange';
  return 'red';
}

async function loadHealth() {
  healthLoading.value = true;
  try {
    health.value = await api.getSystemHealth();
  } finally {
    healthLoading.value = false;
  }
}

async function loadUpdate() {
  updateLoading.value = true;
  try {
    update.value = await api.checkUpdate();
  } finally {
    updateLoading.value = false;
  }
}

async function downloadUpdate() {
  downloading.value = true;
  downloadResult.value = null;
  try {
    downloadResult.value = await api.downloadUpdate(update.value?.latestVersionCode ?? undefined);
  } catch (err) {
    downloadResult.value = {
      ok: false,
      versionName: null,
      versionCode: null,
      fileName: null,
      filePath: null,
      sizeBytes: null,
      sha256: null,
      error: err instanceof Error ? err.message : String(err)
    };
  } finally {
    downloading.value = false;
  }
}

function goUpdatePage() {
  router.push({ name: 'update' });
}

onMounted(() => {
  void accounts.reload().catch(() => undefined);
  void loadHealth();
  void loadUpdate();
});
</script>

<style scoped>
.sub {
  margin-top: 8px;
  font-size: 12px;
  color: var(--color-text-3);
}
.metric-title {
  font-size: 13px;
  color: var(--color-text-2);
}
.metric-value {
  margin-top: 8px;
  font-size: 28px;
  font-weight: 600;
}
.metric-value-text {
  font-size: 20px;
  word-break: break-all;
}
.muted {
  color: var(--color-text-3);
  font-size: 12px;
}
.mb-3 {
  margin-bottom: 16px;
}
</style>
