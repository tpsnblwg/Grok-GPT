<template>
  <div class="page">
    <a-row :gutter="16" class="mb-3">
      <a-col :xs="24" :md="14">
        <a-card title="注册机运行台">
          <template #extra>
            <a-button
              v-if="running"
              type="primary"
              status="danger"
              @click="stop"
            >
              <template #icon><icon-poweroff /></template>停止运行
            </a-button>
            <a-button v-else type="primary" :disabled="!ready" @click="start">
              <template #icon><icon-play-arrow /></template>开始运行
            </a-button>
          </template>

          <StatusCard :status="run.status" />

          <div class="progress-wrap">
            <div class="progress-row">
              <span>成功 {{ run.status.success }} / 计划 {{ run.status.total || settings.data?.runCount || 0 }}</span>
              <b>{{ progress }}%</b>
            </div>
            <a-progress :percent="progress" />
          </div>

          <a-alert v-if="!ready" type="warning">
            注册前请在「配置」页配置 Remail 邮箱工具，或在「人工收件」面板提交邮箱和验证码到队列。
          </a-alert>
          <a-alert v-else type="info">
            Remail 已就绪：启动后请在「人工收件」面板把邮箱提交到「注册邮箱队列」、验证码提交到「取码队列」，注册脚本会自动取用。
          </a-alert>
        </a-card>
      </a-col>

      <a-col :xs="24" :md="10">
        <a-card title="运行参数">
          <a-form v-if="draft" :model="draft" layout="vertical">
            <a-form-item label="run count（1-50）">
              <a-slider v-model="draft.runCount" :min="1" :max="50" />
            </a-form-item>
            <a-form-item label="HTTP 代理配置 (可选)">
              <a-input v-model="draft.proxy" placeholder="例如 http://127.0.0.1:7890" />
            </a-form-item>
            <a-form-item label="Python 路径">
              <a-input v-model="draft.pythonPath" placeholder="python" />
            </a-form-item>
            <a-form-item label="注册脚本目录">
              <a-input v-model="draft.registerDir" placeholder="/app/register" />
            </a-form-item>
            <a-button type="primary" long :disabled="!dirty || saving" :loading="saving" @click="saveParams">
              保存运行参数
            </a-button>
          </a-form>
        </a-card>
      </a-col>
    </a-row>

    <a-card title="收信方式" size="small" class="mb-3">
      <a-space direction="vertical" fill>
        <a-radio-group v-model="mailMode" type="button" @change="onMailModeChange">
          <a-radio value="auto">自动</a-radio>
          <a-radio value="remail">Remail</a-radio>
          <a-radio value="cloudflare">Cloudflare</a-radio>
        </a-radio-group>
        <a-typography-text type="secondary" style="font-size: 12px">
          自动：优先从 Remail 手动队列取邮箱，队列为空时自动创建 Cloudflare 临时邮箱；
          Remail：仅从 Remail 手动队列取；Cloudflare：仅使用 Cloudflare 临时邮箱。
        </a-typography-text>

        <template v-if="mailMode === 'cloudflare'">
          <a-space>
            <a-select
              v-model="cfDomain"
              placeholder="选择邮箱后缀"
              style="width: 220px"
              allow-search
            >
              <a-option v-for="d in cfDomains" :key="d" :value="d">{{ d }}</a-option>
            </a-select>
            <a-button type="primary" :loading="cfGenerating" :disabled="!cfDomain" @click="generateCf">
              <template #icon><icon-sync /></template>随机生成邮箱
            </a-button>
            <a-button size="small" :loading="cfLoading" @click="loadCfInfo">刷新</a-button>
          </a-space>
          <a-space wrap>
            <a-tag v-if="cfLastAddress" color="green">已生成：{{ cfLastAddress }}</a-tag>
            <a-tag v-if="cfPoolCount > 0" color="arcoblue">邮箱池 {{ cfPoolCount }} 个待用</a-tag>
          </a-space>
          <a-alert v-if="!cfConfigOk" type="warning" style="font-size: 12px">
            尚未配置 Cloudflare 邮箱后端，请先在「配置 → 邮件后端」填写 apiBase / adminAuth / domain。
          </a-alert>
        </template>
      </a-space>
    </a-card>

    <ProxySelector />
    <RemailInboxPanel />
    <LogPanel />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { useRunStore } from '@renderer/stores/run';
import { useSettingsStore } from '@renderer/stores/settings';
import { api } from '@renderer/api';
import StatusCard from '@renderer/components/StatusCard.vue';
import LogPanel from '@renderer/components/LogPanel.vue';
import RemailInboxPanel from '@renderer/components/RemailInboxPanel.vue';
import ProxySelector from '@renderer/components/ProxySelector.vue';
import type { AppSettings } from '@shared/settings';

const run = useRunStore();
const settings = useSettingsStore();

const running = computed(() => run.status.phase === 'starting' || run.status.phase === 'running');
const progress = computed(() =>
  run.status.total > 0 ? Math.min(100, Math.round((run.status.success / run.status.total) * 100)) : 0
);

const remailReady = computed(
  () =>
    !!settings.data?.remail.apiBase &&
    !!settings.data?.remail.apiKey &&
    Number.isInteger(settings.data?.remail.projectId) &&
    !!settings.data?.remail.emailSuffix
);
const legacyMailReady = computed(
  () =>
    !!settings.data?.mail.apiBase &&
    !!settings.data?.mail.adminAuth &&
    !!settings.data?.mail.domain
);
const ready = computed(() => remailReady.value || legacyMailReady.value);

async function start() {
  try {
    await api.startRegister();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function stop() {
  try {
    await api.stopRegister();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

// 运行参数草稿
const draft = ref<AppSettings | null>(null);
watch(
  () => settings.data,
  (val) => {
    if (val && !draft.value) draft.value = val;
  },
  { immediate: true }
);

// ===== 收信方式 =====
const mailMode = ref<'auto' | 'remail' | 'cloudflare'>('auto');
const cfDomains = ref<string[]>([]);
const cfDomain = ref('');
const cfGenerating = ref(false);
const cfLoading = ref(false);
const cfLastAddress = ref('');
const cfPoolCount = ref(0);
const cfConfigOk = computed(
  () => !!draft.value?.mail.apiBase && !!draft.value?.mail.adminAuth
);

watch(
  () => settings.data?.mail?.mode,
  (val) => {
    if (val === 'remail' || val === 'cloudflare' || val === 'auto') {
      mailMode.value = val;
    } else {
      mailMode.value = 'auto';
    }
  },
  { immediate: true }
);

async function onMailModeChange() {
  if (!draft.value) return;
  draft.value.mail.mode = mailMode.value;
  try {
    await api.saveSettings(draft.value);
    await settings.reload();
    Message.success(`已切换收信方式：${mailMode.value}`);
    if (mailMode.value === 'cloudflare') {
      await loadCfInfo();
    }
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  }
}

async function loadCfInfo() {
  cfLoading.value = true;
  try {
    const [d, p] = await Promise.all([
      api.getCloudflareDomains(),
      api.getCloudflarePool().catch(() => ({ poolCount: 0, items: [] }))
    ]);
    cfDomains.value = d.suffixes ?? [];
    cfPoolCount.value = p.poolCount ?? 0;
    if (cfDomains.value.length && !cfDomain.value) {
      cfDomain.value = cfDomains.value[0];
    }
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    cfLoading.value = false;
  }
}

async function generateCf() {
  if (!cfDomain.value) {
    Message.warning('请先选择邮箱后缀');
    return;
  }
  cfGenerating.value = true;
  cfLastAddress.value = '';
  try {
    const r = await api.generateCloudflareMail(cfDomain.value);
    if (!r.ok) {
      Message.error(r.error || '生成失败');
      return;
    }
    cfLastAddress.value = r.address;
    cfPoolCount.value = r.poolCount;
    Message.success(`已生成邮箱并入池：${r.address}`);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    cfGenerating.value = false;
  }
}

onMounted(() => {
  // 等 settings 加载完成后再加载 Cloudflare 后缀/邮箱池信息
  setTimeout(() => {
    if (settings.data?.mail?.mode === 'cloudflare') {
      void loadCfInfo();
    }
  }, 400);
});

const dirty = computed(
  () => !!settings.data && JSON.stringify(settings.data) !== JSON.stringify(draft.value)
);
const saving = ref(false);

async function saveParams() {
  if (!draft.value) return;
  saving.value = true;
  try {
    await api.saveSettings(draft.value);
    await settings.reload();
    Message.success('运行参数已保存');
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    saving.value = false;
  }
}
</script>

<style scoped>
.progress-wrap {
  margin: 16px 0;
}
.progress-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  font-size: 13px;
  color: var(--color-text-2);
}
.mb-3 {
  margin-bottom: 16px;
}
</style>
