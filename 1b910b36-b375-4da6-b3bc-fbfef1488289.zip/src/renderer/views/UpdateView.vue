<template>
  <div class="page">
    <a-card class="mb-3">
      <a-space direction="vertical" size="small" fill>
        <a-typography-title :heading="4" style="margin: 0">在线更新</a-typography-title>
        <a-typography-text type="secondary">
          对接授权系统版本源：检查新版本、下载更新包、解压覆盖代码并重启服务。
        </a-typography-text>
        <a-space wrap>
          <a-tag>当前版本 v{{ update?.current ?? '...' }}</a-tag>
          <a-tag v-if="update?.latest" color="green">最新版本 v{{ update.latest }}</a-tag>
          <a-tag v-else color="arcoblue">已是最新版本</a-tag>
          <a-tag v-if="update?.forceUpdate" color="red">强制更新</a-tag>
          <a-tag v-if="update?.source === 'auth'" color="arcoblue">授权系统源</a-tag>
          <a-button size="mini" :loading="updateLoading" @click="loadAll">
            检查更新
          </a-button>
        </a-space>
        <a-alert v-if="update?.error" type="warning">{{ update.error }}</a-alert>

        <a-typography-text
          v-if="update?.updateLog"
          type="secondary"
          style="display: block; white-space: pre-wrap; font-size: 13px; margin-top: 4px"
        >
          更新日志：{{ update.updateLog }}
        </a-typography-text>

        <a-space wrap v-if="update?.hasUpdate">
          <a-button
            v-if="!hasPackage && update?.package?.downloadUrl"
            type="primary"
            :loading="downloading"
            :disabled="downloading"
            @click="doDownload"
          >
            下载更新包
          </a-button>
          <a-tag v-if="hasPackage" color="green">更新包已下载</a-tag>
          <a-button
            v-if="hasPackage && !applying"
            type="primary"
            status="danger"
            :disabled="applying"
            @click="confirmApply"
          >
            解压覆盖代码并执行更新
          </a-button>
          <a-tag v-if="applying" color="orange">更新执行中…</a-tag>
        </a-space>
      </a-space>
    </a-card>

    <a-card title="已下载更新包" size="small" class="mb-3">
      <a-alert type="info" class="mb-3" style="margin-bottom: 12px">
        <template #title>执行更新说明</template>
        「解压覆盖代码并执行更新」会把已下载的 zip 更新包解压并覆盖运行代码（保留 node_modules 与数据目录），随后服务会自动重启加载新版本。更新期间服务会短暂中断（约 10~30 秒），请勿手动重启容器。
      </a-alert>
      <a-list v-if="packages.length" :data="packages" size="small">
        <template #item="{ item }">
          <a-list-item>
            <a-space>
              <icon-file />
              <b>{{ item.fileName }}</b>
              <span class="muted">{{ formatSize(item.sizeBytes) }}</span>
              <span class="muted">{{ fmtTime(item.modifiedAt) }}</span>
            </a-space>
          </a-list-item>
        </template>
      </a-list>
      <a-empty v-else description="暂未下载更新包。发现新版本后请先点击「下载更新包」。" />
    </a-card>

    <a-modal
      v-model:visible="applyModalVisible"
      title="确认执行更新"
      :ok-text="'确认更新到 v' + (update?.latest || '')"
      cancel-text="取消"
      @ok="doApply"
    >
      <a-typography-paragraph>
        将更新到 <b>v{{ update?.latest }}</b>。此操作会：
      </a-typography-paragraph>
      <ul style="padding-left: 20px; margin: 8px 0">
        <li>解压更新包并覆盖运行代码</li>
        <li>自动备份当前版本到数据目录 backups/</li>
        <li>重启服务加载新代码（短暂中断）</li>
      </ul>
      <a-typography-text type="danger">确认执行后页面会自动刷新，请耐心等待服务恢复。</a-typography-text>
    </a-modal>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { Message, Modal } from '@arco-design/web-vue';
import { api } from '@renderer/api';
import { fmtBeijing } from '@renderer/lib/time';
import type { UpdateInfo } from '@shared/ipc';

const update = ref<UpdateInfo | null>(null);
const updateLoading = ref(false);
const downloading = ref(false);
const applying = ref(false);
const applyModalVisible = ref(false);
const packages = ref<{ fileName: string; sizeBytes: number; modifiedAt: string }[]>([]);

const hasPackage = computed(() => {
  const latest = update.value?.latest;
  return !!latest && packages.value.some((p) => p.fileName.startsWith(`${latest}.zip`));
});

function fmtTime(iso: string): string {
  return fmtBeijing(iso);
}

function formatSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
  return bytes + ' B';
}

async function loadAll() {
  updateLoading.value = true;
  try {
    const [u, p] = await Promise.all([
      api.checkUpdate(),
      api.listUpdatePackages().catch(() => ({ packages: [] as typeof packages.value }))
    ]);
    update.value = u;
    packages.value = p.packages ?? [];
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    updateLoading.value = false;
  }
}

async function doDownload() {
  downloading.value = true;
  try {
    const r = await api.downloadUpdate(update.value?.latestVersionCode ?? undefined);
    if (!r.ok) {
      Message.error(r.error || '下载失败');
      return;
    }
    Message.success(`更新包已下载：${r.fileName}`);
    await loadAll();
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
  } finally {
    downloading.value = false;
  }
}

function confirmApply() {
  applyModalVisible.value = true;
}

async function doApply() {
  applyModalVisible.value = false;
  applying.value = true;
  try {
    const r = await api.applyUpdate(update.value?.latestVersionCode ?? undefined);
    if (!r.ok) {
      Message.error(r.error || '应用更新失败');
      applying.value = false;
      return;
    }
    Message.success('更新已应用，服务正在重启…');
    // 等待重启后自动刷新
    let attempts = 0;
    const timer = setInterval(async () => {
      attempts++;
      try {
        const res = await fetch('/api/system/version', { cache: 'no-store' });
        if (res.ok) {
          clearInterval(timer);
          applying.value = false;
          Message.success('服务已恢复，已加载新版本');
          await loadAll();
        }
      } catch {
        /* 服务重启中 */
      }
      if (attempts >= 30) {
        clearInterval(timer);
        applying.value = false;
        Message.warning('等待超时，请手动刷新页面确认更新结果');
      }
    }, 3000);
  } catch (err) {
    Message.error(err instanceof Error ? err.message : String(err));
    applying.value = false;
  }
}

onMounted(() => {
  void loadAll();
});
</script>

<style scoped>
.mb-3 {
  margin-bottom: 16px;
}
.muted {
  color: var(--color-text-3);
  font-size: 12px;
}
</style>
