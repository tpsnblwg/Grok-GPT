import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@renderer/stores/auth';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: () => import('@renderer/views/Login.vue'),
      meta: { public: true }
    },
    {
      path: '/',
      component: () => import('@renderer/components/AppLayout.vue'),
      children: [
        { path: '', redirect: '/dashboard' },
        {
          path: 'dashboard',
          name: 'dashboard',
          component: () => import('@renderer/views/Dashboard.vue')
        },
        {
          path: 'register',
          name: 'register',
          component: () => import('@renderer/views/Register.vue')
        },
        {
          path: 'gpt',
          name: 'gpt',
          component: () => import('@renderer/views/GptRegister.vue')
        },
        {
          path: 'pool',
          name: 'pool',
          component: () => import('@renderer/views/Pool.vue')
        },
        {
          path: 'update',
          name: 'update',
          component: () => import('@renderer/views/UpdateView.vue')
        },
        {
          path: 'settings',
          name: 'settings',
          component: () => import('@renderer/views/Settings.vue')
        }
      ]
    },
    { path: '/:pathMatch(.*)*', redirect: '/dashboard' }
  ]
});

router.beforeEach(async (to) => {
  const auth = useAuthStore();
  if (!auth.authenticated && !to.meta.public) {
    await auth.load();
  }
  if (!to.meta.public && !auth.authenticated) {
    return { name: 'login' };
  }
  if (to.name === 'login' && auth.authenticated) {
    return { name: 'dashboard' };
  }
  return true;
});

export default router;
