import { defineStore } from 'pinia';
import { ref } from 'vue';
import { EMPTY_STATUS, type LogLevel, type RunEvent, type RunStatus } from '@shared/runEvents';

const MAX_LOG = 500;

export interface LogLine {
  id: number;
  level: LogLevel | 'stderr';
  text: string;
  ts: number;
}

let logCounter = 0;

export const useRunStore = defineStore('run', () => {
  const status = ref<RunStatus>({ ...EMPTY_STATUS });
  const logs = ref<LogLine[]>([]);

  function setStatus(s: RunStatus) {
    status.value = { ...s };
  }

  function clearLogs() {
    logs.value = [];
  }

  function append(line: LogLine) {
    const arr = logs.value;
    if (arr.length >= MAX_LOG) {
      arr.splice(0, arr.length - MAX_LOG + 1);
    }
    arr.push(line);
    logs.value = [...arr];
  }

  function applyEvent(e: RunEvent) {
    switch (e.type) {
      case 'started':
        status.value = {
          ...EMPTY_STATUS,
          phase: 'running',
          runId: e.runId,
          pid: e.pid,
          startedAt: Date.now(),
          total: e.total,
          machine: e.machine
        };
        logs.value = [];
        break;
      case 'stdout':
        append({ id: ++logCounter, level: e.level, text: e.text, ts: e.ts });
        break;
      case 'stderr':
        append({ id: ++logCounter, level: 'stderr', text: e.text, ts: e.ts });
        break;
      case 'progress':
        status.value = { ...status.value, current: e.current, total: e.total };
        break;
      case 'success':
        status.value = { ...status.value, success: e.success, total: e.total };
        break;
      case 'exit':
        status.value = {
          ...status.value,
          phase: e.killed ? 'killed' : e.code === 0 ? 'done' : 'error',
          exitCode: e.code,
          finishedAt: Date.now(),
          errorMessage: e.code !== 0 && !e.killed ? `进程退出码 ${e.code}` : null
        };
        break;
      case 'sso':
        // 静默
        break;
      case 'account':
        // 账号由 accountsStore 负责追加
        break;
      // ===== GPT 事件：转成日志行展示 =====
      case 'gpt-phase':
        append({ id: ++logCounter, level: 'info', text: `[阶段] ${e.message}`, ts: Date.now() });
        break;
      case 'gpt-plus':
        append({
          id: ++logCounter,
          level: e.eligible ? 'info' : 'warn',
          text: `[Plus 资格] ${e.message}`,
          ts: Date.now()
        });
        break;
      case 'gpt-link':
        append({ id: ++logCounter, level: 'info', text: `[支付链接] 通道=${e.channel}`, ts: Date.now() });
        break;
      case 'gpt-payment-result':
        append({
          id: ++logCounter,
          level: e.status === 'success' ? 'info' : 'warn',
          text: `[支付结果] ${e.message}`,
          ts: Date.now()
        });
        break;
      case 'gpt-payment-fields':
        append({
          id: ++logCounter,
          level: 'info',
          text: `[表单识别] 识别到 ${e.fields.length} 个字段`,
          ts: Date.now()
        });
        break;
    }
  }

  return { status, logs, setStatus, clearLogs, applyEvent };
});
