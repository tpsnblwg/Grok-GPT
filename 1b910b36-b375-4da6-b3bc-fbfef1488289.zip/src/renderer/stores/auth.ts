import { defineStore } from 'pinia';
import { ref } from 'vue';
import { api } from '@renderer/api';
import type { AuthState, ChangeCredentialsInput } from '@shared/ipc';
import type { MachineType } from '@shared/runEvents';

const MACHINE_KEY = 'grok_reg_machine';

export const useAuthStore = defineStore('auth', () => {
  const authenticated = ref(false);
  const username = ref<string | null>(null);
  const mustChangePassword = ref(false);
  const loading = ref(true);
  const machine = ref<MachineType>(
    (localStorage.getItem(MACHINE_KEY) as MachineType) === 'gpt' ? 'gpt' : 'grok'
  );

  function setMachine(m: MachineType) {
    machine.value = m;
    localStorage.setItem(MACHINE_KEY, m);
  }

  function apply(state: AuthState) {
    authenticated.value = state.authenticated;
    username.value = state.username;
    mustChangePassword.value = state.mustChangePassword;
  }

  function reset() {
    authenticated.value = false;
    username.value = null;
    mustChangePassword.value = false;
  }

  async function load() {
    loading.value = true;
    try {
      apply(await api.getAuthState());
    } catch {
      reset();
    } finally {
      loading.value = false;
    }
  }

  async function login(user: string, pass: string) {
    const state = await api.login(user, pass);
    apply(state);
    return state;
  }

  async function logout() {
    try {
      await api.logout();
    } catch {
      /* ignore */
    }
    reset();
  }

  async function changeCredentials(input: ChangeCredentialsInput) {
    const state = await api.changeCredentials(input);
    apply(state);
    return state;
  }

  return {
    authenticated,
    username,
    mustChangePassword,
    loading,
    machine,
    setMachine,
    load,
    login,
    logout,
    changeCredentials,
    reset
  };
});
