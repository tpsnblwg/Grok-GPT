import { defineStore } from 'pinia';
import { ref } from 'vue';
import { api } from '@renderer/api';
import type { AccountRecord } from '@shared/runEvents';

export const useAccountsStore = defineStore('accounts', () => {
  const accounts = ref<AccountRecord[]>([]);
  const loading = ref(false);

  async function reload() {
    loading.value = true;
    try {
      accounts.value = await api.listAccounts();
    } finally {
      loading.value = false;
    }
  }

  function applyAccount(record: AccountRecord) {
    if (!accounts.value.some((a) => a.id === record.id)) {
      accounts.value = [record, ...accounts.value];
    }
  }

  return { accounts, loading, reload, applyAccount };
});
