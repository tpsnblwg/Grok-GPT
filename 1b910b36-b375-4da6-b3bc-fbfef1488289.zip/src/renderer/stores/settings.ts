import { defineStore } from 'pinia';
import { ref } from 'vue';
import { api } from '@renderer/api';
import type { AppSettings } from '@shared/settings';

export const useSettingsStore = defineStore('settings', () => {
  const data = ref<AppSettings | null>(null);
  const loading = ref(false);

  async function reload() {
    loading.value = true;
    try {
      data.value = await api.getSettings();
    } finally {
      loading.value = false;
    }
  }

  async function save(s: AppSettings) {
    await api.saveSettings(s);
    data.value = s;
  }

  return { data, loading, reload, save };
});
