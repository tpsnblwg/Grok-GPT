/**
 * 应用配置（GUI 设置页所有字段的真源）
 * 这些字段会持久化到服务端数据目录，并在每次"开始注册"前同步到内置 register/config.json。
 */
export interface MailSettings {
  /** 邮件后端 API 根地址，例如 https://mail.example.com */
  apiBase: string;
  /** 邮件后端管理密码（vmail 的 X-Admin-Auth 头） */
  adminAuth: string;
  /** 邮件域名后缀，例如 example.com */
  domain: string;
  /** Cloudflare 可用邮箱后缀列表（逗号分隔或数组）；为空时回退用 domain */
  domains: string[];
  /** 收信方式：remail=只用 Remail 手动队列；cloudflare=只用 Cloudflare 临时邮箱；auto=自动（默认） */
  mode: 'remail' | 'cloudflare' | 'auto';
}

export type ThemeMode = 'system' | 'light' | 'dark';

/** 注册机类型：grok=现有 Grok 注册机；gpt=新增 GPT 注册机 */
export type MachineType = 'grok' | 'gpt';

export type PaymentChannel =
  | 'hosted'
  | 'ph_short'
  | 'paypal'
  | 'ideal'
  | 'upi'
  | 'pix'
  | 'momo'
  | 'gcash'
  | 'kakao'
  | 'custom';

export type GptPlan = 'plus' | 'pro' | 'team' | 'codex';

/** GPT 注册机支付环节配置（提炼方式与支付参数均可替换） */
export interface GptPaymentSettings {
  /**
   * 支付链接提炼方式：
   * - manual：用户手动粘贴支付链接（默认，最稳）
   * - external_api：CDK 提链服务（真实契约，见 extract_link_service）：/api/cdk + /api/extract + /api/jobs/{id}/events SSE
   * - http：通用单次 POST 提链 API（自定义契约）
   * - browser：浏览器驱动（实验，页面结构可能变化）
   */
  extractMode: 'manual' | 'external_api' | 'http' | 'browser';
  /** 提链服务地址（external_api/http 模式必填） */
  extractEndpoint: string;
  /** 提链 API 鉴权 token（http 模式用） */
  extractToken: string;
  /** 提链 CDK（external_api 模式用，创建任务与监听事件都需） */
  cdk: string;
  /** 提链类型：pix / upi / kakao_pay / ideal / paypal（external_api 模式） */
  linkType: string;
  /** 提链网页地址（browser 模式，默认 https://pay.153.ink/） */
  extractUrl: string;
  /** 提链入口代理池（browser 模式必填，每行一个代理） */
  entryProxy: string;
  /** 提链出口代理池（browser 模式，每行一个代理，可留空复用入口） */
  exitProxy: string;
  /** 失败重试次数（browser 模式） */
  retryCount: number;
  /** Plus 优惠 Campaign（选填，例如 plus-1-month-free） */
  promoCampaign: string;
  /** 支付通道 */
  channel: PaymentChannel;
  /** 国家/地区代码，例如 US */
  country: string;
  /** 币种，例如 USD */
  currency: string;
  /** 订阅/空间类型 */
  plan: GptPlan;
  /** 注册成功后是否检测 Plus 试用资格 */
  plusTrialCheck: boolean;
  /** 是否尝试优惠活动（pay.153.ink 的 usePromo） */
  tryPromo: boolean;
  /** 是否同时生成主/附加令牌（pay.153.ink 的 SEN + SO，useSentinel） */
  useSentinel: boolean;
  /** 支付链接提炼超时（秒） */
  extractTimeout: number;
}

export interface GptSettings {
  /** 一次"开始注册"要跑的轮数，1..50 */
  runCount: number;
  /** 固定注册密码，留空则自动生成强密码 */
  registerPassword: string;
  /** 显示名 / 姓名 */
  displayName: string;
  /** 出生日期（about-you 表单用，YYYY-MM-DD），留空自动随机成年人 */
  birthDate: string;
  /** 是否使用代理访问 chatgpt.com（注册浏览器） */
  useProxy: boolean;
  /** 注册浏览器代理地址（http/https/socks5，例如 http://user:pass@host:port） */
  proxy: string;
  /** 支付环节配置 */
  payment: GptPaymentSettings;
}

export interface RemailSettings {
  apiBase: string;
  apiKey: string;
  projectId: number;
  emailSuffix: string;
  serviceMode: 'code' | 'purchase';
}

export type Grok2apiProvider = 'web' | 'build' | 'console';

export interface Grok2apiSettings {
  /** grok2api 管理 API 根地址，例如 http://host.docker.internal:8000 */
  apiBase: string;
  /** grok2api 管理用户名 */
  username: string;
  /** grok2api 管理密码 */
  password: string;
  /** 导入账号类型：web=grok.com SSO 账号（默认） */
  provider: Grok2apiProvider;
}

export interface AuthUpdateSettings {
  /** 是否启用授权系统在线更新 */
  enabled: boolean;
  /** 授权系统服务器地址，例如 https://power.1tim.com */
  server: string;
  /** Open API 鉴权密钥（xzak_ 开头） */
  apiKey: string;
  /** 应用 ID（授权系统中的应用） */
  applicationId: number;
  /** 本地版本 code（用于与授权系统比较，格式：主版本*100+次版本*10+修订） */
  versionCode: number;
}

export type ProxyProtocol = 'http' | 'https' | 'socks4' | 'socks5';

export interface ManualProxy {
  name: string;
  type: ProxyProtocol;
  server: string;
  port: number;
  username?: string;
  password?: string;
}

export interface SubscriptionConfig {
  name: string;
  url: string;
  type: 'clash' | 'v2ray';
  nodeCount?: number;
}

export interface ProxyNodeBrief {
  name: string;
  type: string;
  server: string;
  port: number;
  source: 'manual' | 'subscription';
  username?: string;
  password?: string;
  nodeLatency?: number | null;
  grokLatency?: number | null;
}

export interface ProxyConfig {
  manualProxies: ManualProxy[];
  subscriptions: SubscriptionConfig[];
  parsedNodes: ProxyNodeBrief[];
  selectedSource: 'manual' | 'subscription' | 'none';
  selectedName: string;
  selectionMode: 'none' | 'fixed' | 'random' | 'round-robin';
  applyTo: 'register' | 'sso' | 'both';
  roundRobinIndex?: number;
}

export interface AppSettings {
  /** 当前选中的注册机类型 */
  machine: MachineType;
  /** 用户机器上的 Python 解释器绝对路径 */
  pythonPath: string;
  /** 注册机目录（可留空；服务端会自动使用项目内置 register/） */
  registerDir: string;
  /** 一次"开始注册"要跑的轮数，1..50 */
  runCount: number;
  mail: MailSettings;
  remail: RemailSettings;
  /** GPT 注册机专用配置 */
  gpt: GptSettings;
  /** grok2api 管理 API 配置（用于一键上传号池账号） */
  grok2api: Grok2apiSettings;
  /** 代理配置（手动代理 + 订阅代理 + 选中项） */
  proxyConfig: ProxyConfig;
  /** Python 进程使用的 HTTP 代理 */
  proxy: string;
  /** DrissionPage 浏览器使用的代理；空表示跟随上面的 proxy */
  browserProxy: string;
  /** 账号测活使用的代理；空表示跟随 proxy */
  ssoProxy: string;
  /** Chromium / Chrome / Edge 可执行文件路径；空表示让 DrissionPage 自动探测系统浏览器 */
  browserPath: string;
  /** 主题模式 */
  theme: ThemeMode;
  /** 授权系统在线更新源 */
  authUpdate: AuthUpdateSettings;
}

export const DEFAULT_SETTINGS: AppSettings = {
  machine: 'grok',
  pythonPath: '',
  registerDir: '',
  runCount: 10,
  mail: {
    apiBase: '',
    adminAuth: '',
    domain: '',
    domains: [],
    mode: 'auto'
  },
  remail: {
    apiBase: 'https://remail.aishop6.com',
    apiKey: '',
    projectId: 2,
    emailSuffix: 'asia',
    serviceMode: 'code'
  },
  gpt: {
    runCount: 1,
    registerPassword: '',
    displayName: '',
    birthDate: '',
    useProxy: false,
    proxy: '',
    payment: {
      extractMode: 'manual',
      extractEndpoint: '',
      extractToken: '',
      cdk: '',
      linkType: 'paypal',
      extractUrl: 'https://pay.153.ink/',
      entryProxy: '',
      exitProxy: '',
      retryCount: 10,
      promoCampaign: '',
      channel: 'hosted',
      country: 'US',
      currency: 'USD',
      plan: 'plus',
      plusTrialCheck: true,
      tryPromo: false,
      useSentinel: true,
      extractTimeout: 120
    }
  },
  grok2api: {
    apiBase: '',
    username: '',
    password: '',
    provider: 'web'
  },
proxyConfig: {
  manualProxies: [],
  subscriptions: [],
  parsedNodes: [],
  selectedSource: 'none',
  selectedName: '',
  selectionMode: 'none',
  applyTo: 'both'
},
  proxy: '',
  ssoProxy: '',
  browserProxy: '',
  browserPath: '',
  theme: 'system',
  authUpdate: {
    enabled: true,
    server: 'https://power.1tim.com',
    apiKey: 'xzak_1d0e60f117cd9f3087a55ddeffa215b5bb3e30e0ed2670b6',
    applicationId: 2,
    versionCode: 18
  }
};

export function validateSettings(s: AppSettings): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!Number.isInteger(s.runCount) || s.runCount < 1 || s.runCount > 50)
    errors.runCount = '数量必须在 1 到 50 之间';
  if (!s.mail.apiBase.trim()) errors['mail.apiBase'] = '请填写邮件后端地址';
  if (!s.mail.adminAuth.trim()) errors['mail.adminAuth'] = '请填写邮件后端管理密码';
  if (!s.mail.domain.trim()) errors['mail.domain'] = '请填写邮件域名';
  return errors;
}
