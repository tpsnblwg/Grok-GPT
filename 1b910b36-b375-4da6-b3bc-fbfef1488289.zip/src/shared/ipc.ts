import type { AppSettings, MailSettings, RemailSettings, ThemeMode } from './settings';
import type {
  AccountRecord,
  MachineType,
  PaymentField,
  PaymentMaskedSummary,
  PaymentPayload,
  PaymentSubmitStatus,
  RunEvent,
  RunStatus,
  TestResult
} from './runEvents';

/** 渲染→主：register:start 的可选覆盖项（保存设置之外的临时调整） */
export type RegisterStartArgs = Partial<Pick<AppSettings, 'runCount'>> & { machine?: MachineType };

/** GPT：支付链接提炼结果 */
export interface GptLinkResult {
  ok: boolean;
  /** 最终支付链接/付款码 */
  url: string | null;
  channel: string;
  /** 有效期提示 */
  expiresHint?: string;
  error?: string;
}

/** GPT：支付页面字段识别结果 */
export interface GptInspectResult {
  ok: boolean;
  targetUrl: string;
  pageTitle: string;
  fields: PaymentField[];
  error?: string;
}

/** GPT：填表（不提交）后返回的脱敏摘要 */
export interface GptFillResult {
  ok: boolean;
  summary: PaymentMaskedSummary;
  error?: string;
}

/** GPT：最终提交结果 */
export interface GptSubmitResult {
  ok: boolean;
  status: PaymentSubmitStatus;
  message: string;
  /** 不含敏感数据的诊断信息 */
  diagnostic?: string;
}

/** GPT：当前会话状态快照 */
export interface GptSessionState {
  phase: import('./runEvents').GptPhase;
  runId: string | null;
  /** 当前账号邮箱（脱敏后展示） */
  email?: string;
  /** Plus 试用资格 */
  plusEligible?: boolean;
  /** 已提炼的支付链接 */
  link?: string | null;
  /** 支付通道 */
  channel?: string;
  /** 待确认的脱敏摘要 */
  summary?: PaymentMaskedSummary | null;
  /** 提交结果状态 */
  submitStatus?: PaymentSubmitStatus | null;
  message?: string;
}

export interface ThemeState {
  mode: ThemeMode;
  /** 应用到 DOM 上的实际主题：'light' | 'dark' */
  effective: 'light' | 'dark';
}

/** 授权系统版本包信息 */
export interface AuthUpdatePackageInfo {
  /** 下载地址 */
  downloadUrl: string;
  /** SHA256 校验值 */
  sha256: string;
  /** 包大小（字节） */
  sizeBytes?: number;
  /** 下载地址过期时间，可能为 null */
  urlExpiresAt?: string | null;
}

/** 检查更新结果 */
export interface UpdateInfo {
  /** 本地版本号（来自 package.json） */
  current: string;
  /** GitHub 最新 release 的 tag，无发布时为 null */
  latest: string | null;
  /** 是否有新版本 */
  hasUpdate: boolean;
  /** release 页面 URL */
  htmlUrl: string | null;
  /** 发布时间 ISO，可能为 null */
  publishedAt: string | null;
  /** 检查失败时的错误说明 */
  error?: string;
  /** 更新源类型：github=GitHub，auth=授权系统 */
  source?: 'github' | 'auth';
  /** 授权系统最新版本名，例如 1.2.0 */
  latestVersionName?: string | null;
  /** 授权系统最新版本 code，例如 120 */
  latestVersionCode?: number | null;
  /** 授权系统是否强制更新 */
  forceUpdate?: boolean;
  /** 更新日志（富文本/HTML） */
  updateLog?: string | null;
  /** 完整安装包信息 */
  package?: AuthUpdatePackageInfo | null;
  /** 增量更新包信息 */
  updatePackage?: AuthUpdatePackageInfo | null;
}

/** 邮箱最新验证码查询结果 */
export interface MailCodeResult {
  code: string | null;
  subject: string | null;
  /** 收件时间 ISO */
  receivedAt: string | null;
  /** 该地址是否有任何邮件 */
  hasMail: boolean;
  error?: string;
}

export interface RemailOrderInput {
  projectId: number;
  emailSuffix: string;
  serviceMode: 'code' | 'purchase';
}

export interface RemailPickupInput {
  email: string;
  token: string;
}

export interface RemailMessageInput extends RemailPickupInput {
  messageId: number;
}

/** SSO 验活请求项 */
export interface SsoCheckItem {
  id: string;
  sso: string;
}

/** SSO 验活结果 */
export interface SsoCheckResult {
  id: string;
  /** 是否存活（grok get-user 返回 200） */
  alive: boolean;
  /** HTTP 状态码，0 表示请求异常 */
  status: number;
  email?: string;
  givenName?: string;
  familyName?: string;
  emailConfirmed?: boolean;
  /** grok 账户层级 */
  sessionTierId?: string;
  /** grok 账户创建时间 ISO */
  createTime?: string;
  /** 验活时获取的账号额度信息（尽力解析） */
  quota?: Record<string, unknown> | null;
  /** 验活时间 ISO */
  checkedAt: string;
  error?: string;
}

export interface AuthState {
  authenticated: boolean;
  username: string | null;
  mustChangePassword: boolean;
}

export interface ChangeCredentialsInput {
  currentPassword: string;
  username: string;
  password: string;
  confirmPassword: string;
}

export type SystemHealthLevel = 'ok' | 'warn' | 'error';

export interface SystemHealthCheck {
  id: string;
  label: string;
  level: SystemHealthLevel;
  message: string;
  detail?: string;
}

export interface SystemHealth {
  checkedAt: string;
  summary: {
    ok: number;
    warn: number;
    error: number;
    total: number;
  };
  checks: SystemHealthCheck[];
}

/** grok2api 上传结果 */
export interface Grok2apiUploadResult {
  ok: boolean;
  message: string;
  detail?: {
    created?: number;
    updated?: number;
    skipped?: number;
    synced?: number;
    syncFailed?: number;
  };
}

/** preload 暴露给 renderer 的 typed surface（与 src/preload/index.ts 保持一致） */
export interface RendererApi {
  // auth
  getAuthState(): Promise<AuthState>;
  login(username: string, password: string): Promise<AuthState>;
  logout(): Promise<{ ok: true }>;
  changeCredentials(input: ChangeCredentialsInput): Promise<AuthState>;

  // settings
  getSettings(): Promise<AppSettings>;
  saveSettings(s: AppSettings): Promise<{ ok: true }>;

  // register
  startRegister(args?: RegisterStartArgs): Promise<{ runId: string }>;
  stopRegister(runId: string): Promise<{ ok: boolean }>;
  getStatus(): Promise<RunStatus>;
  onRegisterEvent(cb: (e: RunEvent) => void): () => void;

  // accounts
  listAccounts(): Promise<AccountRecord[]>;

  // mail & sso
  getMailCode(address: string): Promise<MailCodeResult>;
  checkSso(items: SsoCheckItem[]): Promise<SsoCheckResult[]>;

  // theme
  getTheme(): Promise<ThemeState>;
  setTheme(mode: ThemeMode): Promise<ThemeState>;
  onThemeChanged(cb: (e: ThemeState) => void): () => void;

  // tests
  testMail(block: MailSettings): Promise<TestResult>;
  testRemail(): Promise<TestResult>;
  listRemailProjects(): Promise<unknown>;
  listRemailResources(): Promise<unknown>;
  listRemailOrders(): Promise<unknown>;
  getRemailOrder(orderNo: string): Promise<unknown>;
  createRemailOrder(input: RemailOrderInput): Promise<unknown>;
  pickupRemail(input: RemailPickupInput): Promise<unknown>;
  getRemailMessage(input: RemailMessageInput): Promise<unknown>;

  // manual code
  submitManualCode(code: string): Promise<{ ok: true; queueLength: number }>;
  getManualCodeStatus(): Promise<{ queueLength: number }>;

  // manual email
  submitManualEmail(email: string): Promise<{ ok: true; queueLength: number }>;
  getManualEmailStatus(): Promise<{ queueLength: number }>;

  // grok2api
  testGrok2api(settings?: import('@shared/settings').Grok2apiSettings): Promise<TestResult>;
  uploadToGrok2api(input: {
    accountIds?: string[];
    provider?: string;
  }): Promise<Grok2apiUploadResult>;

  // system
  getSystemHealth(): Promise<SystemHealth>;
  checkUpdate(): Promise<UpdateInfo>;
}

declare global {
  interface Window {
    api: RendererApi;
  }
}
