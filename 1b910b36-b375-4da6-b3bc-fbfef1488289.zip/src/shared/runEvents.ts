/**
 * Python 子进程往渲染进程流式推送的事件。
 * stdout 行已经按前缀分级，渲染端只关心 level + text。
 */
import type { MachineType } from './settings';
export type { MachineType };

export type LogLevel = 'info' | 'warn' | 'error' | 'tip' | 'plain';

/** GPT 交互式流程阶段 */
export type GptPhase =
  | 'idle'
  | 'registering'
  | 'plus-check'
  | 'extracting-link'
  | 'awaiting-payment'
  | 'inspecting'
  | 'awaiting-confirm'
  | 'submitting'
  | 'done'
  | 'error';

/** 支付提交结果状态 */
export type PaymentSubmitStatus =
  | 'success'
  | 'failed'
  | 'needs_verification'
  | 'page_changed';

export type RunPhase =
  | 'idle'
  | 'starting'
  | 'running'
  | 'done'
  | 'error'
  | 'killed';

export interface RunStatus {
  phase: RunPhase;
  runId: string | null;
  pid: number | null;
  startedAt: number | null;
  finishedAt: number | null;
  exitCode: number | null;
  /** 当前轮次 */
  current: number;
  /** 计划总轮次 */
  total: number;
  /** 注册成功数 */
  success: number;
  /** 注册失败数 */
  failed: number;
  /** 错误摘要，仅 phase==='error' 时有值 */
  errorMessage: string | null;
  /** 当前注册机类型 */
  machine: MachineType;
}

/** 一条完整账号记录：邮箱 + 密码 + token，由 registerBot / gptBot 从 Python stdout 关联生成 */
export interface AccountRecord {
  id: string;
  runId: string;
  email: string;
  password: string;
  /** grok=SSO token；gpt=ChatGPT access token */
  sso: string;
  /** 注册机类型 */
  machine: MachineType;
  /** gpt 附加信息：是否具备 Plus 试用资格、支付状态等 */
  extra?: Record<string, unknown>;
  /** ISO 字符串 */
  createdAt: string;
}

export type RunEvent =
  | { type: 'started'; runId: string; pid: number; total: number; machine: MachineType }
  | { type: 'stdout'; runId: string; level: LogLevel; text: string; ts: number }
  | { type: 'stderr'; runId: string; text: string; ts: number }
  | { type: 'progress'; runId: string; current: number; total: number }
  | { type: 'success'; runId: string; success: number; total: number }
  | { type: 'sso'; runId: string; token: string }
  | { type: 'account'; runId: string; record: AccountRecord }
  | {
      type: 'exit';
      runId: string;
      code: number | null;
      signal: string | null;
      killed: boolean;
    }
  // ===== GPT 交互式流程事件 =====
  | { type: 'gpt-phase'; runId: string; phase: GptPhase; message: string }
  | { type: 'gpt-plus'; runId: string; eligible: boolean; message: string }
  | { type: 'gpt-link'; runId: string; url: string; channel: string; expiresHint?: string }
  | {
      type: 'gpt-payment-fields';
      runId: string;
      targetUrl: string;
      pageTitle: string;
      fields: PaymentField[];
    }
  | {
      type: 'gpt-payment-result';
      runId: string;
      status: PaymentSubmitStatus;
      message: string;
    };

/** 支付页面识别出的表单字段（用于前端渲染输入框与后续填表） */
export interface PaymentField {
  /** 字段标识（页面内唯一，用于回填） */
  key: string;
  /** 字段类型 */
  type: PaymentFieldType;
  /** 页面 label / placeholder / autocomplete 提示 */
  label: string;
  /** 是否必填 */
  required: boolean;
  /** 用于下拉框的候选值 */
  options?: string[];
}

export type PaymentFieldType =
  | 'card_number'
  | 'cvv'
  | 'expiry'
  | 'country'
  | 'name'
  | 'email'
  | 'address'
  | 'zip'
  | 'phone'
  | 'unknown';

/** 用户提交的支付信息（敏感，仅内存传递，不落盘、不写日志） */
export interface PaymentPayload {
  cardNumber: string;
  cvv: string;
  expiry: string;
  country: string;
  name: string;
  email: string;
  address: string;
  zip: string;
  phone: string;
  /** 额外账单字段（键为字段 key，值为用户输入） */
  extra: Record<string, string>;
}

/** 脱敏后的支付信息摘要（仅用于展示确认，不含完整敏感数据） */
export interface PaymentMaskedSummary {
  cardNumber: string;
  expiry: string;
  country: string;
  name: string;
  email: string;
  [key: string]: string;
}

/** 测试连接的统一返回 */
export interface TestResult {
  ok: boolean;
  message: string;
  /** 调用耗时（ms） */
  ms?: number;
  /** 服务端返回的额外信息（例如 token 总数、Python 版本） */
  detail?: Record<string, unknown>;
}

export const EMPTY_STATUS: RunStatus = {
  phase: 'idle',
  runId: null,
  pid: null,
  startedAt: null,
  finishedAt: null,
  exitCode: null,
  current: 0,
  total: 0,
  success: 0,
  failed: 0,
  errorMessage: null,
  machine: 'grok'
};
