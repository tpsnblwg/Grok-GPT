#!/usr/bin/env bash
# grok-reg-tool 在线更新应用脚本（宿主机执行）
#
# 用法：
#   ./apply-update.sh <版本号>
#   例如：./apply-update.sh 0.1.3
#
# 说明：
#   1. 从 /root/grok-reg-tool/docker/data/updates/<版本号>.zip 读取已下载的更新包
#      （更新包由 Web 控制台「首页 → 下载更新包」下载到持久数据目录）
#   2. 解压到临时目录
#   3. 同步到项目目录（保留 docker/data 数据卷与 docker/.env 环境配置）
#   4. 重新构建并重建 Docker 容器
#
# 风险：应用更新会短暂中断服务（约 1~3 分钟）。执行前请确认无正在运行的注册任务。

set -euo pipefail

VERSION="${1:-}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOCKER_DATA_DIR="${PROJECT_DIR}/docker/data"
UPDATES_DIR="${DOCKER_DATA_DIR}/updates"
PACKAGE="${UPDATES_DIR}/${VERSION}.zip"

if [[ -z "${VERSION}" ]]; then
  echo "用法: $0 <版本号>"
  echo "例如: $0 0.1.3"
  echo
  echo "已下载的更新包："
  ls -1 "${UPDATES_DIR}" 2>/dev/null || true
  exit 1
fi

if [[ ! -f "${PACKAGE}" ]]; then
  echo "错误：更新包不存在：${PACKAGE}"
  echo "请先在 Web 控制台首页点击「下载更新包」。"
  exit 1
fi

echo "==> 校验更新包：${PACKAGE}"
TMP_DIR="$(mktemp -d /tmp/grok-update.XXXXXX)"
trap 'rm -rf "${TMP_DIR}"' EXIT

# 解压
echo "==> 解压更新包..."
unzip -q "${PACKAGE}" -d "${TMP_DIR}"

# 同步到项目目录（排除数据卷与环境配置）
echo "==> 同步项目文件（保留 docker/data 与 docker/.env）..."
rsync -a --delete \
  --exclude='docker/data/' \
  --exclude='docker/.env' \
  --exclude='.env' \
  --exclude='node_modules/' \
  "${TMP_DIR}/" "${PROJECT_DIR}/"

# 重新构建容器
echo "==> 重建 Docker 容器..."
cd "${PROJECT_DIR}/docker"
docker compose up -d --build

echo
echo "==> 更新完成：v${VERSION}"
echo "==> 服务地址：http://<服务器IP>:${WEB_PORT:-6657}"
