# grok-reg-tool v0.1.3 完整安装配置教程

> 适用版本：`grok-reg-tool 0.1.3`（含在线更新功能）
> 在线更新对接：夏稚Auth / 新云Auth Studio 授权系统

---

## 目录
1. [环境要求](#一环境要求)
2. [获取安装包](#二获取安装包)
3. [全新部署（Docker）](#三全新部署docker)
4. [初始访问与登录](#四初始访问与登录)
5. [Web 控制台配置](#五web-控制台配置)
6. [在线更新配置（对接授权系统）](#六在线更新配置对接授权系统)
7. [发布新版本更新包](#七发布新版本更新包)
8. [宿主机更新脚本](#八宿主机更新脚本)
9. [目录结构](#九目录结构)
10. [常见问题排查](#十常见问题排查)

---

## 一、环境要求

| 项目 | 要求 |
| --- | --- |
| 操作系统 | Linux（推荐 Ubuntu 22.04+ / Debian 12+） |
| 服务器配置 | 2 核 2GB 以上，磁盘 20GB 以上 |
| Docker | 20.10+ |
| Docker Compose | v2 版本 |
| 域名（可选） | 已解析到服务器 IP，用于反向代理 HTTPS |

**依赖组件（Docker 构建时自动安装，无需手动安装）**
- Node.js 20（运行时）
- Python 3.13（内置注册机）
- Chromium + Xvfb（注册自动化）
- DrissionPage / curl_cffi（Python 依赖）

---

## 二、获取安装包

安装包为完整项目源码（不含 node_modules，构建时自动安装）：

```bash
# 安装包路径（本机已存在时）
/root/grok-reg-tool/packages/grok-reg-tool-0.1.3.zip
```

**SHA256 校验**：
```
6a925af4c63f41cb4f81bbcb32a006ca3fd97cd1654e8bfa69c08704b768b5b2
```

将安装包上传到服务器后先校验：

```bash
echo '6a925af4c63f41cb4f81bbcb32a006ca3fd97cd1654e8bfa69c08704b768b5b2  grok-reg-tool-0.1.3.zip' | sha256sum -c -
# 输出：grok-reg-tool-0.1.3.zip: OK
```

---

## 三、全新部署（Docker）

### 3.1 解压到项目目录

```bash
# 推荐放到 /root/grok-reg-tool
mkdir -p /root/grok-reg-tool
unzip grok-reg-tool-0.1.3.zip -d /root/grok-reg-tool
cd /root/grok-reg-tool
```

### 3.2 配置 Docker 环境变量

```bash
cd /root/grok-reg-tool/docker
cp .env.example .env
nano .env
```

`.env` 配置项说明：

```ini
# Web UI 暴露端口（对外访问端口）
WEB_PORT=6657

# 注册轮数（一次"开始注册"跑多少轮）
RUN_COUNT=10

# ===== 邮件后端（对接 cloudflare_temp_email，可选）=====
# MAIL_API_BASE：cloudflare_temp_email 后端 Worker/API 根地址
MAIL_API_BASE=
# MAIL_ADMIN_AUTH：cloudflare_temp_email 网站 admin 密码
MAIL_ADMIN_AUTH=
# MAIL_DOMAIN：已配置并可收信的域名
MAIL_DOMAIN=

# ===== 可选代理 =====
HTTP_PROXY=
BROWSER_PROXY=

# 使用 HTTPS 反向代理访问时设为 1；直接 http://IP:6657 请留空
COOKIE_SECURE=
```

### 3.3 构建并启动

```bash
docker compose up -d --build
```

首次构建会安装 Node/Python/Chromium 依赖，约需 5-15 分钟。启动后确认：

```bash
docker ps --filter name=grok-reg-tool
docker logs --tail 10 grok-reg-tool
```

### 3.4 访问服务

```text
http://你的服务器IP:6657
```

**端口说明**：`WEB_PORT` 默认 6657。若本机该端口被占用，可修改 `.env` 中的 `WEB_PORT` 后 `docker compose up -d --build` 重建。

---

## 四、初始访问与登录

1. 查看初始账号密码：

```bash
docker logs grok-reg-tool
# 会打印：default account: admin / default password: admin
```

2. 浏览器打开 `http://服务器IP:6657`，使用 `admin/admin` 登录。
3. 首次登录会**强制修改用户名和密码**，请立即设置强密码。

> ⚠️ 公网部署请务必修改默认密码，并建议配置 HTTPS 反向代理（见 5.5）。

---

## 五、Web 控制台配置

登录后进入「配置」页面，按需配置以下模块：

### 5.1 邮件后端（读取验证码）

| 配置项 | 填写内容 |
| --- | --- |
| mail api base | cloudflare_temp_email 后端 Worker/API 根地址 |
| mail domain | 已配置并可收信的邮箱域名 |
| admin auth | cloudflare_temp_email 网站 admin 密码 |

点击「测试连接」验证。本项目会请求 `MAIL_API_BASE + /admin/new_address` 创建邮箱，再用返回的 `jwt` 轮询邮件提取验证码。

### 5.2 Remail 人工邮箱工具

| 配置项 | 说明 |
| --- | --- |
| Remail API 地址 | 默认 `https://remail.aishop6.com` |
| Remail API Key | `rk-` 开头的密钥 |
| 项目 ID | Grok 项目通常为 3 |
| 邮箱后缀 | 从项目资源中选择或输入 |
| 服务模式 | `code` 短时取码 / `purchase` 长效购买 |

### 5.3 grok2api 账号上传

| 配置项 | 说明 |
| --- | --- |
| grok2api API 地址 | 例如 `http://host.docker.internal:8000` |
| 管理用户名/密码 | grok2api 管理后台账号 |
| 上传账号类型 | `web`（grok.com SSO 账号，默认推荐） |

### 5.4 代理配置

- **手动代理**：HTTP/HTTPS/SOCKS4/SOCKS5
- **订阅代理**：Clash / v2ray 订阅链接自动解析
- 选中后可配置应用到「注册 / 验活 / 全部」

### 5.5 HTTPS 反向代理（推荐）

在宝塔面板为域名（如 `grok.example.com`）创建反向代理站点，目标地址填：

```text
http://127.0.0.1:6657
```

配置 SSL 证书后，在 `.env` 中设置：

```ini
COOKIE_SECURE=1
```

然后 `docker compose up -d --build` 重建。

---

## 六、在线更新配置（对接授权系统）

### 6.1 授权系统后台准备

1. **创建应用**：登录授权系统后台 → 应用管理 → 创建应用（如「Grok-GPT注册机」），记录 `application_id`。
2. **生成 Open API 密钥**：系统设置 → Open API → 生成密钥（`xzak_` 开头）。
3. **发布版本**：应用 → 版本 → 创建版本并上传更新包 zip：
   - `version_name`：如 `0.1.3`
   - `version_code`：数字，规则 **主×100 + 次×10 + 修订**，如 `0.1.3 → 13`、`1.2.0 → 120`
   - 上传完整安装包（kind = `package`）

### 6.2 配置更新源

打开 Web 控制台 →「配置」→「授权系统在线更新」：

| 配置项 | 说明 |
| --- | --- |
| 启用开关 | 开启后首页「检查更新」优先走授权系统 |
| 授权系统地址 | 例如 `https://power.1tim.com` |
| Open API Key | `xzak_` 开头的密钥 |
| 应用 ID | 授权系统中创建的应用 ID |
| 本地版本 code | 本地版本对应的数字 code（`0.1.3 → 13`） |

点击「保存配置」。

### 6.3 检查与下载更新

1. 打开「更新」页面（侧边栏）。
2. 点击「检查更新」，若有新版本会显示版本号、更新日志、强制更新标识。
3. 点击「下载更新包」，下载到持久目录 `docker/data/updates/` 并自动校验 SHA256。
4. 确认无误后点击「解压覆盖代码并执行更新」，服务自动重启加载新版本。

> 更新过程中服务会短暂中断（约 10~30 秒），页面会自动刷新确认恢复。

---

## 七、发布新版本更新包

每次改完代码、构建成功后，在宿主机执行一键发布脚本：

```bash
cd /root/grok-reg-tool
AUTH_PASS='授权系统管理密码' ./release-update.sh 0.1.4 14 '【新增】
1. 新功能说明
【修复】
1. 修复说明'
```

脚本自动完成：打包 → 登录授权系统 → 创建/替换版本 → 上传更新包 → 填写更新日志 → 发布。

可选环境变量：
- `AUTH_SERVER`：授权系统地址（默认 `https://power.1tim.com`）
- `AUTH_USER`：管理员账号（默认 `admin`）
- `APP_ID`：应用 ID（默认 `1`）

---

## 八、宿主机更新脚本

### 8.1 apply-update.sh（应用已下载更新包）

```bash
cd /root/grok-reg-tool
./apply-update.sh 0.1.4
```

从 `docker/data/updates/0.1.4.zip` 读取更新包 → 解压 → 同步项目文件（保留 `docker/data` 与 `docker/.env`）→ 重建容器。

### 8.2 release-update.sh（开发者发布更新包）

见第七节，用于把本地构建产物打包上传到授权系统。

---

## 九、目录结构

```text
/root/grok-reg-tool/
├── docker/
│   ├── .env                  # Docker 部署配置
│   ├── docker-compose.yml    # Compose 编排
│   ├── Dockerfile            # 镜像构建
│   ├── entrypoint.sh         # 容器启动入口
│   └── data/                 # 数据持久化目录（容器 /data）
│       ├── config.json       # Web 控制台配置
│       ├── accounts.json     # 号池账号
│       ├── auth.json         # 登录凭证
│       ├── sso/              # SSO 输出
│       └── updates/          # 已下载更新包
├── server/                   # Node.js 后端源码
├── src/renderer/             # Vue3 前端源码
├── register/                 # Python 注册脚本
├── packages/                 # 已整理安装包
├── apply-update.sh           # 应用更新脚本
└── release-update.sh         # 发布更新包脚本
```

---

## 十、常见问题排查

### 1. 服务启动失败 / 容器反复重启
```bash
docker logs --tail 50 grok-reg-tool
```
- 检查 `.env` 配置是否有误
- 检查端口 6657 是否被占用
- 检查 Docker 内存是否充足

### 2. 检查更新提示「授权系统返回错误」
- 确认「授权系统在线更新」已启用且配置正确
- 确认 Open API Key 正确（`xzak_` 开头）
- 确认应用 ID 正确
- 在授权系统后台确认已发布版本

### 3. 下载更新包失败
- 确认授权系统地址可从本机访问
- 更新包下载票据有效期约 5 分钟，超时请重试
- 检查磁盘空间（`df -h /root`）

### 4. 应用更新后服务异常
- 更新前会自动备份到 `/data/backups/`
- 可用 `apply-update.sh` 重新应用，或从备份目录恢复
- 若为 Docker 镜像层问题，可重新 `docker compose up -d --build` 从源码构建

### 5. 邮件验证码读取失败
- 在「配置」页点击「测试连接」检查邮件后端
- 确认 `MAIL_DOMAIN` 域名可正常收信
- 检查代理是否影响邮件 API 请求

---

© grok-reg-tool v0.1.3 安装配置教程
