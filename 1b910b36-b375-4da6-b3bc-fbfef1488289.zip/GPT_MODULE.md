# GPT 注册机模块说明

本文档说明在 `grok-reg-tool` 中新增的 **GPT 注册机** 模块的设计、配置、启动、操作与测试方法。

## 1. 概述

在原 Grok 注册机基础上，新增可切换的 GPT（ChatGPT/OpenAI）注册机，包含：

- 登录页注册机切换（GPT / Grok）
- GPT 自动注册（邮箱 → 密码 → 邮箱 OTP → about-you → 读取 accessToken）
- Plus 试用资格检测
- 支付链接提炼（可替换适配层：manual / http）
- 支付页面表单识别、填表（不提交）、脱敏摘要确认、提交
- 与 Grok 一致的任务状态、日志、错误处理、重试、配置管理与结果输出

> 合规提示：本项目与 OpenAI / ChatGPT 无官方关联，自动化注册与支付操作可能违反目标平台条款，请仅在合法合规、获得授权的研究/学习/自托管环境使用。

## 2. 文件清单

### 新增文件

| 文件 | 用途 |
| --- | --- |
| `register/gpt_register.py` | GPT 自动化注册脚本（DrissionPage），复用 `email_register.py` 的 Cloudflare 临时邮箱取码；输出 accessToken、检测 Plus 资格 |
| `register/payment_agent.py` | 支付表单长驻 agent：`inspect`（识别字段）/`fill`（填表不提交）/`submit`（提交），JSONL stdin/stdout 协议，敏感数据不落盘 |
| `register/extract_pay153.py` | 浏览器驱动提链脚本：打开 pay.153.ink → 填表 → 点「开始提炼」→ 读回 `#resultValue` 结果链接（无 API 调用） |
| `server/src/gpt/paymentAdapter.ts` | 支付适配层：支付信息校验、脱敏、支付链接提炼适配器（manual / http） |
| `server/src/gpt/gptBot.ts` | GPT 会话状态机：注册→Plus 检测→链接提炼→表单识别→填表→确认→提交，事件推送与账号落盘 |
| `src/renderer/views/GptRegister.vue` | GPT 控制台（任务台、Plus 结果、链接、支付表单、脱敏确认、结果、配置、日志） |
| `src/renderer/components/PaymentForm.vue` | 支付信息输入表单（卡号/CVV/过期时间/国家/账单信息），客户端基础校验 |
| `GPT_MODULE.md` | 本文档 |

### 修改文件

| 文件 | 修改内容 |
| --- | --- |
| `src/shared/settings.ts` | 新增 `MachineType`、`GptSettings`、`GptPaymentSettings` 等类型与默认值 |
| `src/shared/runEvents.ts` | 新增 `GptPhase`、`PaymentSubmitStatus`、`PaymentField`、`PaymentPayload`、`PaymentMaskedSummary`，扩展 `AccountRecord.machine/extra`、`RunStatus.machine`、GPT 事件类型 |
| `src/shared/ipc.ts` | 新增 `GptSessionState`、`GptLinkResult`、`GptInspectResult`、`GptFillResult`、`GptSubmitResult` 等类型 |
| `server/src/settingsStore.ts` | 合并 `gpt` 配置 |
| `server/src/bot/registerRuntime.ts` | 写入 `config.gpt`（供 Python 脚本读取） |
| `server/src/bot/registerBot.ts` | 账号/事件标记 `machine='grok'` |
| `server/src/index.ts` | 新增 `/api/gpt/*` 路由与 GPT 事件广播 |
| `src/renderer/api/index.ts` | 新增 GPT API 方法 |
| `src/renderer/stores/auth.ts` | 新增 `machine` 状态（localStorage 持久化） |
| `src/renderer/stores/run.ts` | 处理 `started.machine` 与 GPT 事件 |
| `src/renderer/router/index.ts` | 新增 `/gpt` 路由 |
| `src/renderer/views/Login.vue` | 新增注册机切换与登录后跳转 |
| `src/renderer/components/AppLayout.vue` | 新增「GPT 注册机」菜单与标题 |

## 3. 配置方法

GPT 配置存储在服务端数据目录 `/data/config.json`（本地开发为项目根 `out/../` 对应 `DATA_DIR`）的 `gpt` 键下：

```json
{
  "gpt": {
    "runCount": 1,
    "registerPassword": "",
    "displayName": "",
    "birthDate": "",
    "payment": {
      "extractMode": "manual",
      "extractEndpoint": "",
      "extractToken": "",
      "cdk": "",
      "linkType": "paypal",
      "extractUrl": "https://pay.153.ink/",
      "entryProxy": "",
      "exitProxy": "",
      "retryCount": 10,
      "promoCampaign": "",
      "channel": "hosted",
      "country": "US",
      "currency": "USD",
      "plan": "plus",
      "plusTrialCheck": true,
      "tryPromo": false,
      "extractTimeout": 120
    }
  }
}
```

也可直接在 Web 控制台「GPT 注册机 → GPT 配置」折叠面板中修改并保存（热生效，无需重启）。

字段说明：

| 字段 | 说明 |
| --- | --- |
| `runCount` | 一次注册轮数（1-50） |
| `registerPassword` | 固定注册密码；留空自动生成强密码 |
| `displayName` / `birthDate` | about-you 表单的姓名/生日；留空随机 |
| `payment.extractMode` | `manual`（手动粘贴，默认最稳）/ `external_api`（CDK 提链服务，真实契约）/ `http`（通用单次 POST）/ `browser`（实验） |
| `payment.linkType` | 提链类型：paypal / pix / upi / kakao_pay / ideal |
| `payment.cdk` | CDK（external_api 模式必填） |
| `payment.channel` | 支付通道：hosted / paypal / ideal / upi / pix / custom 等 |
| `payment.country` / `currency` | 国家/币种，如 `US` / `USD` |
| `payment.plan` | plus / pro / team / codex |
| `payment.plusTrialCheck` | 是否检测 Plus 试用资格 |
| `payment.extractEndpoint` / `extractToken` | external_api/http 模式的提链服务地址与（http 模式）鉴权 Token |
| `payment.extractUrl` | browser 模式的提链网页地址（默认 `https://pay.153.ink/`） |
| `payment.entryProxy` / `exitProxy` | browser 模式的入口/出口代理池（每行一个代理，入口必填） |
| `payment.retryCount` | browser 模式的失败重试次数（1-50） |
| `payment.promoCampaign` | Plus 优惠 Campaign（选填） |

### 支付链接提炼适配层（与现成实现对齐）

参考 `turb-gpt-free-register` 的 `core/extract_link_service.py`，提炼能力抽象为可替换适配层：

- **manual**：用户把在 `pay.153.ink` 或其他渠道提炼出的「最终链接/付款码」粘贴进控制台。
- **external_api（CDK 提链服务，真实契约）**：
  - `POST {extractEndpoint}/api/extract`，body `{ link_type, cdk, token }` → `{ job_id }`
  - `GET {extractEndpoint}/api/jobs/{job_id}/events?cdk={cdk}`（SSE 流）→ `log` / `result` / `error` / `done`
  - 从 `result` 事件的 `data.result` 提取最终链接（`long_url` / `copy_paste` / `final_paypal_link` …）
- **http**：通用单次 POST 提链 API（自定义契约）。
- **browser（浏览器驱动，无 API 调用）**：打开 `extractUrl`（默认 `https://pay.153.ink/`），用 DrissionPage 自动填写 `#token`、订阅、支付路径、国家/币种、入口/出口代理池等，点击「开始提炼」，轮询读回 `#resultValue`（最终链接/付款码）。需配置 `entryProxy`（必填）等代理池。

> 说明：现成实现还包含 `pp_oaics`（本地 PP/OAICS 协议池 `oaics_paypal_link.py`，直接用 access_token 提炼 PayPal BA 链）以及 `PP协议付GPT/paypal/flow.py`（PayPal 协议授权）。分享包中这两处的本地代理/凭据与协议池已被移除，无法直接照搬；如需使用需自行补齐协议池与代理，本项目已通过 `extractMode` 预留可替换入口。

## 4. 依赖安装

无需新增依赖。GPT 脚本复用现有 `register/requirements.txt`：

```
DrissionPage==4.1.0.9
curl_cffi>=0.7.0
requests>=2.32.0
pyvirtualdisplay>=3.0
```

Docker 镜像已内置 Chromium + Xvfb，无需额外安装。本地开发需确保系统有 Chromium/Chrome。

## 5. 启动步骤

### Docker（推荐）

```bash
cd /root/grok-reg-tool/docker
docker compose up -d --build
docker logs -f grok-reg-tool
```

首次启动日志会打印默认账号 `admin/admin`。访问 `http://服务器IP:6657`，在登录页选择「GPT 注册机」后登录。

### 本地开发

```bash
npm install
npm run server:build          # 构建前端 + 编译后端
npm run server:start          # 启动服务（默认 6657）
```

单独跑 GPT 注册脚本（调试）：

```bash
cd register
python -m pip install -r requirements.txt
python gpt_register.py --count 1 --output /tmp/gpt_tokens.txt
```

## 6. 操作流程

1. 登录页选择「GPT 注册机」→ 登录 → 进入 GPT 控制台。
2. 在「GPT 配置」中设置注册轮数、支付通道、国家/币种、提炼方式等并保存。
3. 点击「开始注册」→ 实时查看进度与日志。
4. 注册成功后自动检测 Plus 试用资格（绿色「具备」/ 橙色「不具备」）。
5. 具备资格时：点击「提炼支付链接」；若为 manual 模式则在输入框粘贴链接。
6. 点击「打开支付页并识别表单」→ 系统识别支付表单字段。
7. 在「支付信息」表单中填写虚拟卡卡号、CVV、过期时间、国家/地区及账单信息。
8. 点击「校验并生成填表预览」→ 展示**脱敏摘要**（卡号仅保留前后 4 位、CVV 显示 `***`）。
9. 人工核对后点击「确认提交」→ 返回明确结果（成功 / 失败 / 需要额外验证 / 页面结构变化）。
10. 账号与结果写入「号池」，结果在「提交结果」卡片展示。

## 7. 测试方法

### 7.1 类型检查与构建

```bash
npm run typecheck              # 前端 + shared 类型检查
npm run server:build           # 前端构建 + 后端 tsc 编译
```

### 7.2 后端接口冒烟

登录后（带 Cookie）：

```bash
curl -s http://127.0.0.1:6657/api/gpt/state
curl -s -X POST http://127.0.0.1:6657/api/gpt/start -H 'Content-Type: application/json' -d '{"runCount":1}'
```

### 7.3 支付 agent 单独测试

```bash
cd register
python payment_agent.py <<'EOF'
{"id":1,"cmd":"inspect","url":"https://example.com/checkout"}
EOF
```

### 7.4 脱敏与校验单测要点

- `validatePayment`：卡号 13-19 位、CVV 3-4 位、`MM/YY`、国家必填。
- `buildMaskedSummary`：确认返回中不包含完整卡号与 CVV。
- 检查服务端日志与 `accounts.json` 中**不出现**完整卡号/CVV（支付信息仅内存传递）。

## 8. 异常场景处理

| 场景 | 处理方式 |
| --- | --- |
| 注册失败（邮箱未取到/OTP 超时/页面结构变化） | `✘ 第 N 轮失败 \| reason` 记录，支持多轮重试，不中断后续轮次 |
| Plus 资格检测失败（权益接口不可用） | 输出 `[PLUS] not-eligible <诊断原因>`，不阻塞主流程，前端显示「不具备/未检测」 |
| 支付链接提炼失败（http 超时/返回无 url） | 抛出明确错误；manual 模式兜底粘贴 |
| 网页识别失败（无输入框/iframe 无法进入） | `inspect` 返回空字段，前端提示「识别到 0 个字段」，可重试 |
| 字段匹配失败（未匹配到卡号/CVV 等） | `fill` 返回 `unmatched` 字段 key，前端不提交并提示人工核对 |
| 验证拦截（3DS/OTP/人机验证） | 提交返回 `needs_verification`，提示用户人工完成验证 |
| 提交失败/被拒 | 返回 `failed` 及不含敏感数据的诊断信息 |
| 页面结构变化 | 返回 `page_changed`，提示人工核对支付结果 |

## 9. 安全说明

- 支付数据（卡号/CVV/有效期）仅经 Node 后端 → Python agent 的 stdin 内存通道传递，**不落盘、不写日志、不入库**。
- 前端仅展示脱敏摘要；`buildMaskedSummary` 保证 CVV 恒为 `***`、卡号仅保留前后 4 位。
- 提链 API Token 属于配置凭据，存储在 `/data/config.json`（与原项目其他凭据一致），请勿提交到版本库。
- 请勿在公网暴露控制台；部署到公网时设置强密码并限制来源 IP。
