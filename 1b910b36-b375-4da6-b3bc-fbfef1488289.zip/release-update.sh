#!/usr/bin/env bash
# grok-reg-tool 更新包发布脚本（打包并上传到授权服务器，填写更新日志）
#
# 用法：
#   AUTH_PASS='<授权系统管理密码>' ./release-update.sh 0.1.4 14 '<更新日志>'
#
# 可选环境变量：
#   AUTH_SERVER   授权系统地址，默认 https://power.1tim.com
#   AUTH_USER     授权系统管理员账号，默认 admin
#   APP_ID        授权系统中的应用 ID，默认 1
#   ZIP_NAME      打包输出文件名，默认 <版本名>.zip
#
# 流程：打包 -> 登录授权系统 -> 创建/替换版本 -> 上传更新包 -> 填写更新日志 -> 发布
set -euo pipefail

VERSION="${1:-}"
VERSION_CODE="${2:-}"
LOG_TEXT="${3:-}"

AUTH_SERVER="${AUTH_SERVER:-https://power.1tim.com}"
AUTH_USER="${AUTH_USER:-admin}"
AUTH_PASS="${AUTH_PASS:-}"
APP_ID="${APP_ID:-1}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "${VERSION}" || -z "${VERSION_CODE}" || -z "${LOG_TEXT}" ]]; then
  echo "用法: AUTH_PASS=xxx ./release-update.sh <版本名> <版本code> '<更新日志>'"
  echo "例如: AUTH_PASS=xxx ./release-update.sh 0.1.4 14 '新增xxx\n修复xxx'"
  exit 1
fi
if [[ -z "${AUTH_PASS}" ]]; then
  echo "错误：请设置环境变量 AUTH_PASS（授权系统管理员密码）"
  exit 1
fi

echo "==> 1/5 打包更新包 ${VERSION} ..."
ZIP_FILE="/tmp/grok-reg-tool-${VERSION}.zip"
rm -f "${ZIP_FILE}"
cd "${PROJECT_DIR}"
zip -r -q "${ZIP_FILE}" . \
  -x 'node_modules/*' '.git/*' 'docker/data/*' '.vite/*' 'docker/.env'
ZIP_SHA="$(sha256sum "${ZIP_FILE}" | awk '{print $1}')"
echo "    包大小: $(stat -c%s "${ZIP_FILE}") bytes, sha256: ${ZIP_SHA:0:16}..."

echo "==> 2/5 登录授权系统 ..."
LOGIN_BODY=$(mktemp)
printf '{"login":"%s","password":"%s","device_name":"release-update","captcha":null}' "${AUTH_USER}" "${AUTH_PASS}" > "${LOGIN_BODY}"
TOKEN=$(curl -k -sS -X POST -H 'Content-Type: application/json' --data @"${LOGIN_BODY}" "${AUTH_SERVER}/api/v1/auth/admin/login" | node -e 'let s="";process.stdin.on("data",d=>s+=d);process.stdin.on("end",()=>{try{const j=JSON.parse(s);if(!j.data?.tokens?.access_token){console.error("登录失败:",j.message||s);process.exit(1)}console.log(j.data.tokens.access_token)}catch(e){console.error("登录失败:",s.slice(0,200));process.exit(1)}})')
rm -f "${LOGIN_BODY}"
AUTH="Authorization: Bearer ${TOKEN}"

echo "==> 3/5 查找或创建版本 ..."
VERSION_ID=""
VERSION_LIST=$(curl -k -sS -H "${AUTH}" "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions?page=1&size=100")
VERSION_ID=$(printf '%s' "${VERSION_LIST}" | node -e 'let s="";process.stdin.on("data",d=>s+=d);process.stdin.on("end",()=>{try{const j=JSON.parse(s);const v=(j.data?.items||[]).find(x=>String(x.version_code)===process.argv[1]||x.version_name===process.argv[1]);console.log(v?String(v.id):"")}catch(e){console.error("解析版本列表失败:",s.slice(0,200));process.exit(1)}})' "${VERSION_CODE}")

if [[ -n "${VERSION_ID}" ]]; then
  echo "    版本已存在 (id=${VERSION_ID})，先禁用后替换..."
  curl -k -sS -X POST -H "${AUTH}" -o /dev/null "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions/${VERSION_ID}/disable"
  curl -k -sS -X DELETE -H "${AUTH}" -o /dev/null "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions/${VERSION_ID}/files/package" || true
else
  echo "    创建新版本..."
  CREATE_BODY=$(mktemp)
  printf '{"version_name":"%s","version_code":%s,"force_update":false,"update_log":"临时"}' "${VERSION}" "${VERSION_CODE}" > "${CREATE_BODY}"
  VERSION_ID=$(curl -k -sS -X POST -H "${AUTH}" -H 'Content-Type: application/json' --data @"${CREATE_BODY}" "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions" | node -e 'let s="";process.stdin.on("data",d=>s+=d);process.stdin.on("end",()=>{try{console.log(String(JSON.parse(s).data.id))}catch(e){console.error("创建版本失败:",s.slice(0,200));process.exit(1)}})')
  rm -f "${CREATE_BODY}"
fi

echo "==> 4/5 上传更新包并填写更新日志 ..."
curl -k -sS -X POST -H "${AUTH}" -F "file=@${ZIP_FILE};filename=${VERSION}.zip" -o /dev/null \
  "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions/${VERSION_ID}/files/package"

UPDATE_BODY=$(mktemp)
# 用 node 构造 JSON，正确处理 \n 换行转义
node -e '
const fs=require("fs");
const version=process.argv[1], code=process.argv[2], log=process.argv[3], out=process.argv[4];
const body={version_name:version,version_code:Number(code),force_update:false,update_log:log.replace(/\\n/g,"\n")};
fs.writeFileSync(out, JSON.stringify(body));
' "${VERSION}" "${VERSION_CODE}" "${LOG_TEXT}" "${UPDATE_BODY}"
curl -k -sS -X PUT -H "${AUTH}" -H 'Content-Type: application/json' --data @"${UPDATE_BODY}" -o /dev/null \
  "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions/${VERSION_ID}"
rm -f "${UPDATE_BODY}"

echo "==> 5/5 发布版本 ..."
curl -k -sS -X POST -H "${AUTH}" -o /dev/null "${AUTH_SERVER}/api/v1/admin/applications/${APP_ID}/versions/${VERSION_ID}/publish"

echo
echo "==> 完成：v${VERSION} (code ${VERSION_CODE}) 已发布到 ${AUTH_SERVER}"
echo "==> 更新包: ${ZIP_FILE} (sha256 ${ZIP_SHA})"
