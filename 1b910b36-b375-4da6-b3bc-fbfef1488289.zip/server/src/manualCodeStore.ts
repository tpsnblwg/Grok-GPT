/**
 * 手动验证码 FIFO 队列。
 * 前端通过 WebUI 手动提交验证码入队；Python 注册脚本通过 HTTP 长轮询取码。
 * 使用 token 保护取码接口（Python 从 config.json 读取同一 token）。
 */
import { randomBytes } from 'node:crypto';
import { promises as fsp, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const DATA_DIR = resolve(process.env.DATA_DIR || '/data');
const TOKEN_PATH = join(DATA_DIR, 'manual_code_token');

interface Waiter {
  resolve: (code: string) => void;
  timer: NodeJS.Timeout;
}

class ManualCodeStore {
  private queue: string[] = [];
  private waiters: Waiter[] = [];

  /** 入队一个验证码，并唤醒最早一个等待者 */
  async enqueue(code: string): Promise<void> {
    const normalized = String(code || '').trim();
    if (!normalized) return;
    this.queue.push(normalized);
    this.drain();
  }

  private drain(): void {
    while (this.queue.length > 0 && this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      if (!waiter) break;
      clearTimeout(waiter.timer);
      const code = this.queue.shift();
      if (code === undefined) break;
      waiter.resolve(code);
    }
  }

  /** 出队取一个验证码；队列为空且 timeoutMs>0 时阻塞等待，超时返回 null */
  dequeue(timeoutMs = 0): Promise<string | null> {
    if (this.queue.length > 0) {
      return Promise.resolve(this.queue.shift() ?? null);
    }
    if (timeoutMs <= 0) {
      return Promise.resolve(null);
    }
    return new Promise<string | null>((resolve) => {
      let settled = false;
      const finish = (value: string | null) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      const onCode = (code: string) => {
        clearTimeout(timer);
        finish(code);
      };
      const timer = setTimeout(() => {
        const idx = this.waiters.findIndex((w) => w.resolve === onCode);
        if (idx >= 0) this.waiters.splice(idx, 1);
        finish(null);
      }, timeoutMs);
      this.waiters.push({ resolve: onCode, timer });
    });
  }

  count(): number {
    return this.queue.length;
  }

  /** 取码接口的共享 token：环境变量优先，否则从 DATA_DIR 读取/生成并持久化 */
  async getToken(): Promise<string> {
    if (process.env.MANUAL_CODE_TOKEN) return process.env.MANUAL_CODE_TOKEN;
    try {
      await fsp.mkdir(DATA_DIR, { recursive: true });
      if (existsSync(TOKEN_PATH)) {
        const token = (await fsp.readFile(TOKEN_PATH, 'utf-8')).trim();
        if (token) return token;
      }
      const token = randomBytes(24).toString('hex');
      await fsp.writeFile(TOKEN_PATH, token, 'utf-8');
      return token;
    } catch {
      return randomBytes(24).toString('hex');
    }
  }

  async verifyToken(token?: string): Promise<boolean> {
    if (!token) return false;
    const expected = await this.getToken();
    return token === expected;
  }
}

export const manualCodeStore = new ManualCodeStore();
