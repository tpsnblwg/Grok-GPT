/**
 * Cloudflare 临时邮箱池（FIFO）。
 * 前端在注册页选择 Cloudflare 收信并生成邮箱后入池；
 * Python 注册脚本通过 HTTP 长轮询 /api/manual-email/cloudflare/next 取用（含 jwt）。
 * 池内容持久化到 DATA_DIR/cloudflare-mail-pool.json，容器重启不丢失。
 */
import { promises as fsp, existsSync } from 'node:fs';
import { join } from 'node:path';
import { dataDir } from './settingsStore.js';

export interface CloudflareMailItem {
  address: string;
  jwt: string;
  domain: string;
  createdAt: string;
}

interface Waiter {
  resolve: (item: CloudflareMailItem | null) => void;
  timer: NodeJS.Timeout;
}

const POOL_FILE = () => join(dataDir(), 'cloudflare-mail-pool.json');

class CloudflareMailStore {
  private pool: CloudflareMailItem[] = [];
  private waiters: Waiter[] = [];
  private loaded = false;

  private async ensureLoaded(): Promise<void> {
    if (this.loaded) return;
    this.loaded = true;
    try {
      const file = POOL_FILE();
      if (existsSync(file)) {
        const raw = await fsp.readFile(file, 'utf-8');
        const arr = JSON.parse(raw) as CloudflareMailItem[];
        if (Array.isArray(arr)) this.pool = arr.filter((x) => x && x.address && x.jwt);
      }
    } catch {
      this.pool = [];
    }
  }

  private async persist(): Promise<void> {
    try {
      await fsp.mkdir(dataDir(), { recursive: true });
      await fsp.writeFile(POOL_FILE(), JSON.stringify(this.pool, null, 2), 'utf-8');
    } catch {
      /* 持久化失败不阻断流程 */
    }
  }

  /** 入池一个 Cloudflare 邮箱 */
  async enqueue(item: CloudflareMailItem): Promise<void> {
    const address = String(item?.address || '').trim().toLowerCase();
    const jwt = String(item?.jwt || '').trim();
    if (!address || !jwt) return;
    await this.ensureLoaded();
    // 避免重复地址
    this.pool = this.pool.filter((x) => x.address !== address);
    this.pool.push({ ...item, address, jwt });
    await this.persist();
    this.drain();
  }

  private drain(): void {
    while (this.pool.length > 0 && this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      if (!waiter) break;
      clearTimeout(waiter.timer);
      const item = this.pool.shift();
      if (!item) break;
      waiter.resolve(item);
    }
  }

  /** 出池取一个邮箱；池空且 timeoutMs>0 时阻塞等待，超时返回 null */
  async dequeue(timeoutMs = 0): Promise<CloudflareMailItem | null> {
    await this.ensureLoaded();
    if (this.pool.length > 0) {
      const item = this.pool.shift() ?? null;
      await this.persist();
      return item;
    }
    if (timeoutMs <= 0) return null;
    return new Promise<CloudflareMailItem | null>((resolve) => {
      let settled = false;
      const finish = (value: CloudflareMailItem | null) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      const onItem = (item: CloudflareMailItem | null) => {
        clearTimeout(timer);
        void this.persist();
        finish(item);
      };
      const timer = setTimeout(() => {
        const idx = this.waiters.findIndex((w) => w.resolve === onItem);
        if (idx >= 0) this.waiters.splice(idx, 1);
        finish(null);
      }, timeoutMs);
      this.waiters.push({ resolve: onItem, timer });
    });
  }

  count(): number {
    return this.pool.length;
  }

  list(): CloudflareMailItem[] {
    return this.pool.slice();
  }
}

export const cloudflareMailStore = new CloudflareMailStore();
