/**
 * GPT 注册机 - 支付环节适配层
 *
 * 职责：
 * 1. 支付信息基础格式校验（仅内存，绝不落盘/写日志）
 * 2. 敏感数据脱敏（用于前端确认摘要）
 * 3. 支付链接提炼适配器（可替换：manual / http）
 *
 * 说明：pay.153.ink 是客户端 SPA，后台提链 API 契约未公开。
 * 因此提炼能力抽象为接口，默认 manual（用户粘贴），并支持 http（自建/第三方 API）。
 * 浏览器驱动方式（browser）由 Python payment_agent.py 承担，不在本文件实现网络调用。
 */
import type { GptPaymentSettings } from '@shared/settings';
import type { PaymentPayload, PaymentMaskedSummary } from '@shared/runEvents';

/** 支付链接提炼适配器接口 */
export interface PaymentLinkExtractor {
  /** 返回提炼出的支付链接；manual 模式返回 null 表示等待用户粘贴 */
  extract(sessionToken: string, cfg: GptPaymentSettings): Promise<{ url: string | null; note?: string }>;
}

/** 脱敏卡号：保留前 4 后 4，其余用 * 隐藏 */
export function maskCardNumber(cardNumber: string): string {
  const digits = String(cardNumber || '').replace(/\D/g, '');
  if (digits.length < 8) return '****';
  const head = digits.slice(0, 4);
  const tail = digits.slice(-4);
  const mid = '*'.repeat(digits.length - 8);
  return `${head} ${mid} ${tail}`;
}

/** 脱敏 CVV：完全隐藏 */
export function maskCvv(_cvv: string): string {
  return '***';
}

/** 脱敏有效期：只保留 MM/YY 结构，值用 * 隐藏 */
export function maskExpiry(expiry: string): string {
  const m = String(expiry || '').match(/(\d{2})\D?(\d{2})/);
  if (!m) return '**/**';
  return `${m[1]}/**`;
}

/** 邮箱脱敏：保留首字符与域名 */
export function maskEmail(email: string): string {
  const e = String(email || '').trim();
  const at = e.indexOf('@');
  if (at <= 1) return e ? `${e[0]}***` : '';
  return `${e.slice(0, 1)}***${e.slice(at)}`;
}

/** 生成脱敏摘要（用于提交前展示） */
export function buildMaskedSummary(p: PaymentPayload): PaymentMaskedSummary {
  return {
    cardNumber: maskCardNumber(p.cardNumber),
    cvv: maskCvv(p.cvv),
    expiry: maskExpiry(p.expiry),
    country: p.country || '—',
    name: p.name || '—',
    email: maskEmail(p.email),
    address: p.address ? '已填写' : '—',
    zip: p.zip ? '已填写' : '—',
    phone: p.phone ? '已填写' : '—'
  };
}

export interface PaymentValidationError {
  field: string;
  message: string;
}

/** 支付信息基础格式校验（不涉及真实扣款，仅格式） */
export function validatePayment(p: PaymentPayload): PaymentValidationError[] {
  const errors: PaymentValidationError[] = [];
  const digits = (s: string) => String(s || '').replace(/\D/g, '');

  if (digits(p.cardNumber).length < 13 || digits(p.cardNumber).length > 19) {
    errors.push({ field: 'cardNumber', message: '卡号长度应在 13-19 位数字之间' });
  }
  if (!/^\d{3,4}$/.test(digits(p.cvv))) {
    errors.push({ field: 'cvv', message: 'CVV 应为 3-4 位数字' });
  }
  if (!/^(0[1-9]|1[0-2])\D?(\d{2})$/.test(String(p.expiry || '').trim())) {
    errors.push({ field: 'expiry', message: '过期时间格式应为 MM/YY' });
  }
  if (!String(p.country || '').trim()) {
    errors.push({ field: 'country', message: '请选择国家或地区' });
  }
  return errors;
}

/**
 * 通用 HTTP 提链适配器。
 *
 * 期望的第三方/自建 API 契约（可自行适配）：
 *   POST {endpoint}
 *   body: { token, plan, channel, country, currency, tryPromo }
 *   resp: { url } | { link } | { finalUrl } | { data: { url } }
 */
export class HttpLinkExtractor implements PaymentLinkExtractor {
  async extract(sessionToken: string, cfg: GptPaymentSettings) {
    const endpoint = String(cfg.extractEndpoint || '').trim();
    if (!endpoint) {
      throw new Error('未配置提链服务地址（extractEndpoint）');
    }
    const controller = new AbortController();
    const timeout = Math.max(10, Number(cfg.extractTimeout) || 120) * 1000;
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(cfg.extractToken ? { Authorization: `Bearer ${cfg.extractToken}` } : {})
        },
        body: JSON.stringify({
          token: sessionToken,
          plan: cfg.plan,
          channel: cfg.channel,
          country: cfg.country,
          currency: cfg.currency,
          tryPromo: !!cfg.tryPromo
        }),
        signal: controller.signal
      });
      if (!res.ok) {
        throw new Error(`提链服务返回 HTTP ${res.status}`);
      }
      const data = (await res.json()) as Record<string, unknown>;
      const raw = data.url ?? data.link ?? data.finalUrl ?? data.data;
      const extracted =
        typeof raw === 'string'
          ? raw
          : raw && typeof raw === 'object'
            ? String((raw as { url?: string }).url || '')
            : '';
      if (!extracted) {
        throw new Error('提链服务返回结果中未找到支付链接字段');
      }
      return { url: extracted };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(`支付链接提炼失败: ${msg}`);
    } finally {
      clearTimeout(timer);
    }
  }
}

/** manual 模式：不自动提炼，返回 null 等待前端用户粘贴 */
export class ManualLinkExtractor implements PaymentLinkExtractor {
  async extract(): Promise<{ url: string | null; note?: string }> {
    return { url: null, note: 'manual' };
  }
}

/** 从提链服务 result 对象中尽力提取最终支付链接 */
function extractLinkFromResult(result: unknown): string {
  if (typeof result === 'string') return result;
  if (!result || typeof result !== 'object') return '';
  const r = result as Record<string, unknown>;
  const value =
    r.long_url ?? r.copy_paste ?? r.final_paypal_link ?? r.payment_link ?? r.url ?? r.link;
  return typeof value === 'string' ? value : '';
}

/** 从提链服务 error 对象提取用户可读原因 */
function extractError(data: unknown): string {
  if (data == null) return '';
  if (typeof data === 'string') return data;
  if (typeof data !== 'object') return String(data);
  const d = data as Record<string, unknown>;
  const err = d.error;
  if (err && typeof err === 'object') {
    const e = err as Record<string, unknown>;
    for (const k of ['message', 'detail', 'reason', 'error', 'msg', 'description']) {
      if (e[k]) return String(e[k]);
    }
    return JSON.stringify(e).slice(0, 300);
  }
  if (err) return String(err);
  for (const k of ['message', 'detail', 'reason', 'msg', 'description', 'raw']) {
    if (d[k]) return String(d[k]);
  }
  return JSON.stringify(d).slice(0, 300);
}

/**
 * CDK 提链服务适配器（与 core/extract_link_service.py 的 external_api 后端一致）。
 *
 * 契约：
 *   1) POST {base}/api/extract   body: { link_type, cdk, token }  → { job_id }
 *   2) GET  {base}/api/jobs/{job_id}/events?cdk={cdk}  (SSE)
 *      事件：log / result / error / done
 *      result 事件的 data.result 含最终链接（long_url / copy_paste / final_paypal_link ...）
 */
export class ExternalApiLinkExtractor implements PaymentLinkExtractor {
  async extract(sessionToken: string, cfg: GptPaymentSettings) {
    const base = String(cfg.extractEndpoint || '').trim().replace(/\/+$/, '');
    if (!base) throw new Error('未配置提链服务地址（extractEndpoint）');
    const cdk = String(cfg.cdk || '').trim();
    if (!cdk) throw new Error('未配置提链 CDK');
    const linkType = String(cfg.linkType || 'paypal').trim().toLowerCase();
    const timeout = Math.max(10, Number(cfg.extractTimeout) || 120) * 1000;

    const jobId = await this.createJob(base, linkType, cdk, sessionToken, timeout);
    return await this.listenEvents(base, jobId, cdk, timeout);
  }

  private async createJob(
    base: string,
    linkType: string,
    cdk: string,
    token: string,
    timeout: number
  ): Promise<string> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(`${base}/api/extract`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ link_type: linkType, cdk, token }),
        signal: controller.signal
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        throw new Error(`提链服务创建任务失败 HTTP ${res.status}: ${body.slice(0, 200)}`);
      }
      const data = (await res.json()) as Record<string, unknown>;
      const jobId = data.job_id;
      if (!jobId) throw new Error(`提链服务未返回 job_id: ${JSON.stringify(data).slice(0, 200)}`);
      return String(jobId);
    } finally {
      clearTimeout(timer);
    }
  }

  private async listenEvents(base: string, jobId: string, cdk: string, timeout: number) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const url = `${base}/api/jobs/${encodeURIComponent(jobId)}/events?cdk=${encodeURIComponent(cdk)}`;
      const res = await fetch(url, {
        headers: { Accept: 'text/event-stream' },
        signal: controller.signal
      });
      if (!res.ok || !res.body) {
        const body = await res.text().catch(() => '');
        throw new Error(`监听提链事件失败 HTTP ${res.status}: ${body.slice(0, 200)}`);
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split(/\r?\n\r?\n/);
        buffer = events.pop() ?? '';
        for (const block of events) {
          const { event, data } = this.parseSseBlock(block);
          if (event === 'result') {
            const result = (data as Record<string, unknown> | null)?.result;
            const link = extractLinkFromResult(result);
            if (!link) throw new Error('提链服务 result 事件未包含支付链接');
            return { url: link };
          }
          if (event === 'error') {
            throw new Error(extractError(data) || '提链任务失败');
          }
        }
      }
      throw new Error('提链事件流结束但未返回 result');
    } finally {
      clearTimeout(timer);
    }
  }

  private parseSseBlock(block: string): { event: string; data: unknown } {
    let event = 'message';
    const dataLines: string[] = [];
    for (const raw of block.split(/\r?\n/)) {
      if (raw.startsWith(':')) continue;
      if (raw.startsWith('event:')) event = raw.slice(6).trim() || 'message';
      else if (raw.startsWith('data:')) dataLines.push(raw.slice(5).trimStart());
    }
    const text = dataLines.join('\n');
    let data: unknown = text;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { raw: text };
      }
    }
    return { event, data };
  }
}

export function resolveLinkExtractor(
  mode: GptPaymentSettings['extractMode']
): PaymentLinkExtractor {
  if (mode === 'http') return new HttpLinkExtractor();
  if (mode === 'external_api') return new ExternalApiLinkExtractor();
  return new ManualLinkExtractor();
}
