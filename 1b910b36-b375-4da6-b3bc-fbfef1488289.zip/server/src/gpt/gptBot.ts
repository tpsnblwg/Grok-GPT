/**
 * GPT 注册机 - 会话状态机
 *
 * 职责：
 * 1. 触发 GPT 自动注册（Python gpt_register.py）并解析进度/结果/Plus 资格
 * 2. 支付链接提炼调度（复用 paymentAdapter 的可替换适配器）
 * 3. 支付页面字段识别 → 填表（不提交）→ 用户确认 → 提交
 * 4. 敏感支付数据仅经 stdin 传给 Python agent，不落盘、不写日志
 *
 * 与 Grok 的 registerBot 保持一致的：任务状态、事件推送、账号落盘、日志。
 */
import { EventEmitter } from 'events';
import { randomUUID } from 'crypto';
import { spawn, ChildProcess } from 'child_process';
import { existsSync } from 'node:fs';
import fs from 'fs';
import path from 'path';
import { loadSettings } from '../settingsStore.js';
import { appendAccount } from '../accountStore.js';
import {
  buildRegisterDirCandidates,
  writeConfigForPython
} from '../bot/registerRuntime.js';
import { buildMaskedSummary, resolveLinkExtractor, validatePayment } from './paymentAdapter.js';
import type {
  AccountRecord,
  GptPhase,
  LogLevel,
  PaymentField,
  PaymentPayload,
  RunEvent
} from '@shared/runEvents';
import type { GptSessionState } from '@shared/ipc';

interface StartOptions {
  runCountOverride?: number;
}

interface PaymentAgentRequest {
  resolve: (v: any) => void;
  reject: (e: Error) => void;
}

/** 长驻 Python 支付 agent：通过 stdin/stdout 以 JSONL 协议交互 */
class PaymentAgent {
  private child: ChildProcess;
  private pending = new Map<number, PaymentAgentRequest>();
  private nextId = 1;
  private buffer = '';

  constructor(scriptPath: string, pythonPath: string, cwd: string) {
    this.child = spawn(pythonPath, ['-u', scriptPath], {
      cwd,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' },
      stdio: ['pipe', 'pipe', 'pipe']
    });
    this.child.stdout?.on('data', (d: Buffer) => this.onData(d.toString('utf-8')));
    this.child.stderr?.on('data', () => {
      /* stderr 不解析，忽略（避免敏感信息进入日志） */
    });
  }

  private onData(chunk: string) {
    this.buffer += chunk;
    let idx: number;
    while ((idx = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, idx).trim();
      this.buffer = this.buffer.slice(idx + 1);
      if (!line) continue;
      let parsed: any;
      try {
        parsed = JSON.parse(line);
      } catch {
        continue;
      }
      const req = this.pending.get(Number(parsed.id));
      if (!req) continue;
      this.pending.delete(Number(parsed.id));
      if (parsed.ok) req.resolve(parsed);
      else req.reject(new Error(parsed.error || '支付 agent 执行失败'));
    }
  }

  request(cmd: Record<string, unknown>, timeoutMs = 180000): Promise<any> {
    const id = this.nextId++;
    return new Promise<any>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error('支付 agent 请求超时'));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        }
      });
      this.child.stdin?.write(JSON.stringify({ id, ...cmd }) + '\n');
    });
  }

  quit() {
    try {
      this.child.stdin?.write(JSON.stringify({ id: 0, cmd: 'quit' }) + '\n');
    } catch {
      /* ignore */
    }
    setTimeout(() => {
      try {
        this.child.kill('SIGTERM');
      } catch {
        /* ignore */
      }
    }, 1500);
  }
}

export class GptBot extends EventEmitter {
  private state: GptSessionState = { phase: 'idle', runId: null };
  private shouldStop = false;
  private childProcess: ChildProcess | null = null;
  private replayBuffer: RunEvent[] = [];
  private static readonly REPLAY_LIMIT = 1000;
  private paymentAgent: PaymentAgent | null = null;
  private currentRunId: string | null = null;
  private pendingAccount: { email?: string; password?: string; token?: string; plusEligible?: boolean } = {};
  private currentTokenFile: string | null = null;
  private lastLink: string | null = null;
  private lastLinkChannel = '';
  private lastToken: string | null = null;

  getState(): GptSessionState {
    return { ...this.state };
  }

  getReplay(): RunEvent[] {
    return this.replayBuffer.slice();
  }

  private push(ev: RunEvent) {
    this.replayBuffer.push(ev);
    if (this.replayBuffer.length > GptBot.REPLAY_LIMIT) {
      this.replayBuffer.splice(0, this.replayBuffer.length - GptBot.REPLAY_LIMIT);
    }
    this.emit('event', ev);
  }

  private log(text: string, level: LogLevel = 'info') {
    const runId = this.currentRunId ?? '';
    // 同步打印到容器日志，便于 docker logs 排查注册过程
    if (level === 'error') console.error(`[gpt-reg] ${text}`);
    else console.log(`[gpt-reg] ${text}`);
    this.push({ type: 'stdout', runId, level, text, ts: Date.now() });
  }

  private setPhase(phase: GptPhase, message: string) {
    this.state.phase = phase;
    this.state.message = message;
    this.push({ type: 'gpt-phase', runId: this.currentRunId ?? '', phase, message });
  }

  private resolveRegisterDir(): string | null {
    for (const dir of buildRegisterDirCandidates(undefined)) {
      if (existsSync(path.join(dir, 'gpt_register.py'))) return dir;
    }
    return null;
  }

  private resolvePython(): string {
    return process.env.PYTHON_PATH || '/usr/local/bin/python3';
  }

  async start(opts: StartOptions = {}): Promise<{ runId: string }> {
    if (this.state.phase === 'registering') {
      throw new Error('已有一个 GPT 注册任务在进行，请先停止');
    }
    const settings = await loadSettings();
    const runCount = opts.runCountOverride ?? settings.gpt.runCount;

    const registerDir = this.resolveRegisterDir();
    if (!registerDir) {
      throw new Error('未找到内置 GPT 注册脚本 register/gpt_register.py，请检查项目完整性。');
    }

    const runId = randomUUID();
    this.currentRunId = runId;
    this.shouldStop = false;
    this.replayBuffer = [];
    this.pendingAccount = {};
    this.lastLink = null;
    this.lastLinkChannel = '';
    this.lastToken = null;
    this.state = { phase: 'registering', runId, message: '正在准备注册任务' };

    this.push({ type: 'started', runId, pid: process.pid, total: runCount, machine: 'gpt' });

    // 写入 config.json（含邮件后端、代理、手动队列），GPT 脚本复用
    await writeConfigForPython(registerDir, settings, runCount);

    // 输出 token 文件
    const tokenFile = path.join(registerDir, 'sso', `gpt_tokens_${runId.slice(0, 8)}.txt`);
    fs.mkdirSync(path.dirname(tokenFile), { recursive: true });
    this.currentTokenFile = tokenFile;

    const scriptPath = path.join(registerDir, 'gpt_register.py');
    const pythonPath = this.resolvePython();
    this.setPhase('registering', '正在启动 GPT 注册脚本');
    this.log(`GPT 注册脚本: ${scriptPath}`);

    this.runPython(runId, runCount, scriptPath, pythonPath, registerDir, tokenFile).catch((e) => {
      this.log(`Runner error: ${e.message}`, 'error');
      this.finalizeRun(runId, false);
    });

    return { runId };
  }

  async stop(): Promise<void> {
    this.shouldStop = true;
    if (this.childProcess) {
      try {
        this.childProcess.kill('SIGTERM');
      } catch {
        /* ignore */
      }
    }
    // 立即重置状态，允许再次启动；close 事件里 finalizeRun 会因 currentRunId 不匹配而跳过
    this.currentRunId = null;
    this.childProcess = null;
    this.setPhase('done', '注册已停止');
  }

  /** 用户手动粘贴支付链接（extractMode=manual 时） */
  setManualLink(url: string): { ok: boolean } {
    const clean = String(url || '').trim();
    if (!clean) return { ok: false };
    this.lastLink = clean;
    this.lastLinkChannel = 'manual';
    this.state.link = clean;
    this.setPhase('awaiting-payment', '已接收手动支付链接');
    this.push({ type: 'gpt-link', runId: this.currentRunId ?? '', url: clean, channel: 'manual' });
    return { ok: true };
  }

  /** 提炼支付链接（依据 settings.gpt.payment.extractMode 选择适配器） */
  async extractLink(): Promise<{ url: string | null; needManual: boolean; note?: string }> {
    const settings = await loadSettings();
    const cfg = settings.gpt.payment;
    if (!this.lastToken) {
      throw new Error('尚未获取已注册账号的会话 token，无法提炼支付链接');
    }
    this.setPhase('extracting-link', '正在提炼支付链接');

    let url: string | null = null;
    let note: string | undefined;

    if (cfg.extractMode === 'browser') {
      // 浏览器驱动：打开 pay.153.ink → 填表 → 提交 → 读回结果
      this.log('浏览器驱动提链：打开 ' + (cfg.extractUrl || 'https://pay.153.ink/'));
      url = await this.extractLinkViaBrowser(this.lastToken);
    } else {
      const extractor = resolveLinkExtractor(cfg.extractMode);
      const r = await extractor.extract(this.lastToken, cfg);
      url = r.url;
      note = r.note;
    }

    if (url) {
      this.lastLink = url;
      this.lastLinkChannel = cfg.channel;
      this.state.link = url;
      this.state.channel = cfg.channel;
      this.push({ type: 'gpt-link', runId: this.currentRunId ?? '', url, channel: cfg.channel });
      this.setPhase('awaiting-payment', '支付链接已就绪');
      return { url, needManual: false };
    }
    // manual → 等待用户粘贴
    this.setPhase('awaiting-payment', '请手动粘贴支付链接');
    return { url: null, needManual: true, note: note || 'manual' };
  }

  /** 浏览器驱动提链：调用 register/extract_pay153.py，token 经 stdin 传入 */
  private async extractLinkViaBrowser(token: string): Promise<string | null> {
    const registerDir = this.resolveRegisterDir();
    if (!registerDir) throw new Error('未找到内置提链脚本 extract_pay153.py');
    const scriptPath = path.join(registerDir, 'extract_pay153.py');
    const pythonPath = this.resolvePython();

    return await new Promise<string | null>((resolve, reject) => {
      const child = spawn(pythonPath, ['-u', scriptPath], {
        cwd: registerDir,
        env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' },
        stdio: ['pipe', 'pipe', 'pipe']
      });
      let buffer = '';
      let resultUrl: string | null = null;
      let errorMsg = '';

      child.stdin.write(JSON.stringify({ token }) + '\n');
      child.stdin.end();

      child.stdout?.on('data', (d: Buffer) => {
        buffer += d.toString('utf-8');
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const raw of lines) {
          const line = raw.trim();
          if (!line) continue;
          if (line.startsWith('[RESULT] ')) resultUrl = line.slice(9).trim();
          else if (line.startsWith('[ERROR] ')) errorMsg = line.slice(8).trim();
          else if (line.startsWith('[META] ')) this.log(line.slice(7).trim());
          else this.log(line);
        }
      });
      child.stderr?.on('data', (d: Buffer) => {
        const text = d.toString('utf-8').trim();
        if (text) this.log(text, 'error');
      });
      child.on('error', (err) => reject(new Error(`提链脚本启动失败: ${err.message}`)));
      child.on('close', (code) => {
        if (resultUrl) resolve(resultUrl);
        else reject(new Error(errorMsg || `浏览器提链未返回结果（退出码 ${code}）`));
      });
    });
  }

  /** 开始支付流程：打开支付页并识别表单字段 */
  async startPayment(): Promise<{ fields: PaymentField[]; targetUrl: string; pageTitle: string }> {
    const url = this.lastLink;
    if (!url) throw new Error('尚未获取支付链接，请先提炼或手动粘贴');
    const registerDir = this.resolveRegisterDir();
    if (!registerDir) throw new Error('未找到内置支付 agent 脚本');
    const scriptPath = path.join(registerDir, 'payment_agent.py');

    this.setPhase('inspecting', '正在打开支付页面并识别表单字段');
    this.paymentAgent = new PaymentAgent(scriptPath, this.resolvePython(), registerDir);

    const res = await this.paymentAgent.request({ cmd: 'inspect', url }, 120000);
    const fields = (res.fields || []) as PaymentField[];
    this.setPhase('awaiting-payment', `识别到 ${fields.length} 个表单字段`);
    this.push({
      type: 'gpt-payment-fields',
      runId: this.currentRunId ?? '',
      targetUrl: res.targetUrl || url,
      pageTitle: res.pageTitle || '',
      fields
    });
    return { fields, targetUrl: res.targetUrl || url, pageTitle: res.pageTitle || '' };
  }

  /** 填表（不提交），返回脱敏摘要供前端确认 */
  async fillPayment(payload: PaymentPayload) {
    const errors = validatePayment(payload);
    if (errors.length > 0) {
      throw new Error(errors.map((e) => e.message).join('；'));
    }
    if (!this.paymentAgent) throw new Error('支付流程尚未开始，请先打开支付页面');

    this.setPhase('awaiting-confirm', '正在填表（尚未提交）');
    await this.paymentAgent.request({ cmd: 'fill', payload }, 120000);
    const summary = buildMaskedSummary(payload);
    this.state.summary = summary;
    return { summary };
  }

  /** 用户确认后执行提交 */
  async confirmSubmit() {
    if (!this.paymentAgent) throw new Error('支付流程尚未开始');
    this.setPhase('submitting', '正在提交支付信息');
    const res = await this.paymentAgent.request({ cmd: 'submit' }, 180000);
    const status = (res.status as any) || 'failed';
    const message = String(res.message || '');
    this.state.submitStatus = status;
    this.setPhase(status === 'success' ? 'done' : 'error', message);
    this.push({
      type: 'gpt-payment-result',
      runId: this.currentRunId ?? '',
      status,
      message
    });
    this.cleanupAgent();
    return { status, message };
  }

  /** 取消支付流程 */
  cancel() {
    this.cleanupAgent();
    this.setPhase('done', '支付流程已取消');
  }

  private cleanupAgent() {
    if (this.paymentAgent) {
      this.paymentAgent.quit();
      this.paymentAgent = null;
    }
  }

  private finalizeRun(runId: string, success: boolean) {
    if (this.currentRunId !== runId) return;
    this.push({
      type: 'exit',
      runId,
      code: success ? 0 : 1,
      signal: this.shouldStop ? 'SIGTERM' : null,
      killed: this.shouldStop
    });
    this.setPhase(success ? 'done' : 'error', success ? '注册任务结束' : '注册脚本异常退出');
    this.currentRunId = null;
  }

  private async runPython(
    runId: string,
    count: number,
    scriptPath: string,
    pythonPath: string,
    registerDir: string,
    tokenFile: string
  ) {
    const args = ['-u', scriptPath, '--count', String(count), '--output', tokenFile];
    await new Promise<void>((resolve) => {
      const child = spawn(pythonPath, args, {
        cwd: registerDir,
        env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' },
        stdio: ['pipe', 'pipe', 'pipe']
      });
      this.childProcess = child;

      child.stdout?.on('data', (data: Buffer) => {
        for (const line of data.toString('utf-8').split('\n')) {
          const trimmed = line.trim();
          if (trimmed) this.parseStdout(runId, trimmed, count);
        }
      });
      child.stderr?.on('data', (data: Buffer) => {
        for (const line of data.toString('utf-8').split('\n')) {
          const trimmed = line.trim();
          if (trimmed) this.log(trimmed, 'error');
        }
      });
      child.on('close', (code) => {
        this.childProcess = null;
        this.finalizeRun(runId, code === 0);
        resolve();
      });
      child.on('error', (err) => {
        this.childProcess = null;
        this.log(`Python 进程启动失败: ${err.message}`, 'error');
        this.finalizeRun(runId, false);
        resolve();
      });
    });
  }

  private parseStdout(runId: string, line: string, total: number) {
    // 去掉时间戳前缀
    let msg = line.replace(/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s*\|\s*/, '');
    if (/^[═─]+$/.test(msg.trim())) return;

    // 轮次进度
    const roundMatch = msg.match(/第\s*(\d+)/);
    if (roundMatch && msg.includes('轮') && !msg.includes('成功') && !msg.includes('失败')) {
      this.pendingAccount = {};
      this.push({ type: 'progress', runId, current: parseInt(roundMatch[1], 10), total });
    }

    // 账号邮箱/密码
    const emailMatch = msg.match(/注册完成，邮箱:\s*(\S+)/);
    if (emailMatch) this.pendingAccount.email = emailMatch[1];
    const pwdMatch = msg.match(/\[ACCOUNT\]\s*password=(\S+)/);
    if (pwdMatch) this.pendingAccount.password = pwdMatch[1];

    // Plus 资格
    if (msg.includes('[PLUS] eligible')) {
      this.pendingAccount.plusEligible = true;
      this.push({ type: 'gpt-plus', runId, eligible: true, message: '具备 Plus 试用资格' });
    } else if (msg.includes('[PLUS] not-eligible')) {
      this.pendingAccount.plusEligible = false;
      this.push({ type: 'gpt-plus', runId, eligible: false, message: msg });
    }

    // 成功
    if (msg.startsWith('✔') && msg.includes('轮成功')) {
      this.recordAccount(runId);
    }
    // 失败
    if (msg.startsWith('✘') && msg.includes('轮失败')) {
      this.pendingAccount = {};
    }

    if (msg.startsWith('✘') || msg.includes('[Error]') || msg.includes('失败')) {
      this.log(msg, 'error');
    } else {
      this.log(msg);
    }
  }

  private recordAccount(runId: string) {
    const { email, password, plusEligible } = this.pendingAccount;
    this.pendingAccount = {};
    if (!email && !password) return;

    let token = '';
    try {
      if (this.currentTokenFile && fs.existsSync(this.currentTokenFile)) {
        const lines = fs
          .readFileSync(this.currentTokenFile, 'utf-8')
          .split(/\r?\n/)
          .map((l) => l.trim())
          .filter((l) => l.length > 0);
        if (lines.length > 0) token = lines[lines.length - 1];
      }
    } catch {
      /* ignore */
    }

    const record: AccountRecord = {
      id: randomUUID(),
      runId,
      email: email ?? '',
      password: password ?? '',
      sso: token,
      machine: 'gpt',
      extra: { plusEligible: plusEligible ?? null },
      createdAt: new Date().toISOString()
    };
    if (token) this.lastToken = token;
    if (email) this.state.email = email;
    if (plusEligible !== undefined) this.state.plusEligible = plusEligible;
    this.push({ type: 'account', runId, record });
    void appendAccount(record).catch(() => undefined);
  }
}

export const gptBot = new GptBot();
