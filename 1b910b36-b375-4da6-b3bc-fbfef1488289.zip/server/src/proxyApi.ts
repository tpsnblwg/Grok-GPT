/**
 * 代理管理：订阅拉取/解析（Clash YAML / V2Ray Base64）+ 两级延迟测试。
 * 延迟测试逻辑：
 *   1) 服务器本机 → 代理节点：TCP 连接到 node:port 的握手耗时；
 *   2) 代理节点 → grok：通过该代理建立到 grok.com:443 的隧道（HTTP CONNECT / SOCKS5 握手）耗时。
 */
import { connect } from 'node:net';
import { parse as parseYaml } from 'yaml';

const GROK_HOST = 'grok.com';
const GROK_PORT = 443;

export interface ProxyNode {
  name: string;
  type: string;
  server: string;
  port: number;
  source: 'manual' | 'subscription';
  nodeLatency?: number | null;
  grokLatency?: number | null;
}

function testTcpLatency(host: string, port: number, timeoutMs = 5000): Promise<number | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    const finish = (v: number | null) => {
      if (done) return;
      done = true;
      socket.destroy();
      clearTimeout(timer);
      resolve(v);
    };
    const socket = connect({ host, port });
    const timer = setTimeout(() => finish(null), timeoutMs);
    socket.once('connect', () => finish(Date.now() - start));
    socket.once('error', () => finish(null));
  });
}

function testHttpProxyToGrok(host: string, port: number, timeoutMs = 8000): Promise<number | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    let buf = '';
    const finish = (v: number | null) => {
      if (done) return;
      done = true;
      socket.destroy();
      clearTimeout(timer);
      resolve(v);
    };
    const socket = connect({ host, port });
    const timer = setTimeout(() => finish(null), timeoutMs);
    socket.once('connect', () => {
      socket.write(`CONNECT ${GROK_HOST}:${GROK_PORT} HTTP/1.1\r\nHost: ${GROK_HOST}:${GROK_PORT}\r\n\r\n`);
    });
    socket.on('data', (d) => {
      buf += d.toString();
      if (buf.includes('\r\n\r\n')) finish(Date.now() - start);
    });
    socket.once('error', () => finish(null));
  });
}

function testSocks5ToGrok(host: string, port: number, timeoutMs = 8000): Promise<number | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    let done = false;
    let step = 0;
    const finish = (v: number | null) => {
      if (done) return;
      done = true;
      socket.destroy();
      clearTimeout(timer);
      resolve(v);
    };
    const socket = connect({ host, port });
    const timer = setTimeout(() => finish(null), timeoutMs);
    socket.once('connect', () => {
      socket.write(Buffer.from([0x05, 0x01, 0x00])); // greeting
    });
    socket.on('data', (d) => {
      if (step === 0 && d[0] === 0x05 && d[1] === 0x00) {
        step = 1;
        const hostBuf = Buffer.from(GROK_HOST);
        socket.write(
          Buffer.concat([
            Buffer.from([0x05, 0x01, 0x00, 0x03, hostBuf.length]),
            hostBuf,
            Buffer.from([0x01, GROK_PORT >> 8, GROK_PORT & 0xff])
          ])
        );
      } else if (step === 1 && d[0] === 0x05 && d[1] === 0x00) {
        finish(Date.now() - start);
      }
    });
    socket.once('error', () => finish(null));
  });
}

/** 两级延迟：nodeLatency=本机→代理节点，grokLatency=代理节点→grok */
export async function testNodeLatency(
  node: ProxyNode
): Promise<{ nodeLatency: number | null; grokLatency: number | null }> {
  const nodeLatency = await testTcpLatency(node.server, node.port);
  const grokLatency =
    node.type === 'socks5' || node.type === 'socks'
      ? await testSocks5ToGrok(node.server, node.port)
      : await testHttpProxyToGrok(node.server, node.port);
  return { nodeLatency, grokLatency };
}

/** 解析 Clash 订阅（YAML） */
export function parseClashSub(text: string): ProxyNode[] {
  try {
    const doc = parseYaml(text) as { proxies?: any[] };
    const proxies = doc?.proxies || [];
    return proxies
      .map((p: any) => ({
        name: String(p?.name || ''),
        type: String(p?.type || 'http').toLowerCase(),
        server: String(p?.server || ''),
        port: Number(p?.port) || 0,
        source: 'subscription' as const
      }))
      .filter((p) => p.name && p.server && p.port);
  } catch {
    return [];
  }
}

/** 安全的 URL 解码（节点名称常用 URL 编码，如 %E5%89%A9...） */
function safeDecode(v: string): string {
  try {
    return decodeURIComponent(String(v || '').replace(/\+/g, ' '));
  } catch {
    return String(v || '');
  }
}

/** 解析 V2Ray 订阅（Base64） */
export function parseV2raySub(text: string): ProxyNode[] {
  const nodes: ProxyNode[] = [];
  let decoded = '';
  try {
    decoded = Buffer.from(String(text || '').trim(), 'base64').toString('utf-8');
  } catch {
    decoded = text;
  }
  try {
    const trimmed = decoded.trim();
    if (trimmed.startsWith('[')) {
      const arr = JSON.parse(trimmed) as any[];
      for (const p of arr) {
        nodes.push({
          name: safeDecode(String(p?.ps || p?.name || '')),
          type: String(p?.net || p?.type || 'vmess').toLowerCase(),
          server: String(p?.add || p?.host || ''),
          port: Number(p?.port) || 0,
          source: 'subscription'
        });
      }
    }
  } catch {
    /* fallthrough to uri parsing */
  }
  if (nodes.length === 0) {
    for (const line of decoded.split('\n')) {
      const l = line.trim();
      if (!l) continue;
      try {
        if (l.startsWith('vmess://')) {
          const inner = Buffer.from(l.slice(8), 'base64').toString('utf-8');
          const p = JSON.parse(inner);
          nodes.push({ name: safeDecode(String(p?.ps || '')), type: 'vmess', server: String(p?.add || ''), port: Number(p?.port) || 0, source: 'subscription' });
        } else if (/^(vless|trojan|ss|vmess):\/\//.test(l)) {
          const u = new URL(l);
          nodes.push({ name: safeDecode(u.hash ? u.hash.slice(1) : l.split(':')[0]), type: l.split(':')[0], server: u.hostname, port: Number(u.port) || 0, source: 'subscription' });
        }
      } catch {
        /* ignore */
      }
    }
  }
  return nodes.filter((p) => p.server && p.port);
}

/** 拉取并解析订阅 */
export async function fetchSubscription(
  url: string,
  type: string
): Promise<{ name: string; url: string; type: string; nodes: ProxyNode[] }> {
  const res = await fetch(String(url || '').trim(), {
    signal: AbortSignal.timeout(30000),
    headers: {
      'User-Agent':
        type === 'v2ray'
          ? 'v2rayN/6.0 (Windows NT 10.0; Win64; x64)'
          : 'clash-verge/v1.5.0 (Windows NT 10.0; Win64; x64)',
      Accept: '*/*'
    }
  });
  if (!res.ok) throw new Error(`订阅拉取失败: HTTP ${res.status}`);
  const text = await res.text();
  const nodes = type === 'v2ray' ? parseV2raySub(text) : parseClashSub(text);
  return { name: String(url).split('/').pop() || url, url, type, nodes };
}
