import { randomUUID } from 'node:crypto';
import { proxiedRequest } from './httpClient.js';

export interface RemailSettings {
  apiBase: string;
  apiKey: string;
  projectId: number;
  emailSuffix: string;
  serviceMode: 'code' | 'purchase';
}

function baseUrl(value: string) {
  return value.trim().replace(/\/+$/, '');
}

function auth(settings: RemailSettings) {
  return { Authorization: `Bearer ${settings.apiKey}` };
}

function validate(settings: RemailSettings) {
  if (!settings.apiBase.trim()) throw new Error('缺少 Remail API 地址');
  if (!settings.apiKey.trim()) throw new Error('缺少 Remail API Key');
}

async function request(settings: RemailSettings, path: string, options: Parameters<typeof proxiedRequest>[1] = {}) {
  validate(settings);
  const response = await proxiedRequest(`${baseUrl(settings.apiBase)}${path}`, {
    ...options,
    timeoutMs: options.timeoutMs ?? 15000,
    headers: { ...auth(settings), ...(options.headers || {}) }
  });
  if (response.status < 200 || response.status >= 300) {
    const detail = typeof response.data === 'object' ? JSON.stringify(response.data) : String(response.data || '');
    throw new Error(`Remail HTTP ${response.status}${detail ? `: ${detail.slice(0, 300)}` : ''}`);
  }
  return response.data;
}

export function maskApiKey(value: string) {
  const key = value.trim();
  return key.length > 8 ? `${key.slice(0, 4)}...${key.slice(-4)}` : key ? '已配置' : '未配置';
}

export async function listRemailProjects(settings: RemailSettings) {
  return request(settings, '/v1/open/projects?limit=100');
}

export async function listRemailResources(settings: RemailSettings) {
  return request(settings, '/v1/open/resources?type=domain&scope=owned&limit=100');
}

export async function listRemailOrders(settings: RemailSettings) {
  return request(settings, '/v1/open/orders?limit=50');
}

export async function getRemailOrder(settings: RemailSettings, orderNo: string) {
  return request(settings, `/v1/open/orders/${encodeURIComponent(orderNo)}`);
}

export async function createRemailOrder(settings: RemailSettings) {
  if (!Number.isInteger(settings.projectId) || settings.projectId < 1) throw new Error('Remail projectId 无效');
  if (!settings.emailSuffix.trim()) throw new Error('缺少邮箱后缀');
  return request(settings, `/v1/open/orders?serviceMode=${encodeURIComponent(settings.serviceMode)}&supply=public_only`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Idempotency-Key': randomUUID() },
    body: { projectId: settings.projectId, emailSuffix: settings.emailSuffix.trim() }
  });
}

export async function pickupRemail(settings: RemailSettings, email: string, token: string) {
  validate(settings);
  if (!email.trim() || !token.trim()) throw new Error('需要邮箱和服务凭证');
  const response = await proxiedRequest(`${baseUrl(settings.apiBase)}/v1/pickup?email=${encodeURIComponent(email)}&token=${encodeURIComponent(token)}`, { timeoutMs: 15000 });
  if (response.status < 200 || response.status >= 300) throw new Error(`Remail 取件 HTTP ${response.status}`);
  return response.data;
}

export async function getRemailMessage(settings: RemailSettings, messageId: number, email: string, token: string) {
  validate(settings);
  const response = await proxiedRequest(`${baseUrl(settings.apiBase)}/v1/pickup/messages/${messageId}?email=${encodeURIComponent(email)}&token=${encodeURIComponent(token)}`, { timeoutMs: 15000 });
  if (response.status < 200 || response.status >= 300) throw new Error(`Remail 邮件详情 HTTP ${response.status}`);
  return response.data;
}

export async function testRemail(settings: RemailSettings) {
  const started = Date.now();
  const data = await listRemailProjects(settings) as { items?: unknown[]; total?: number };
  return { ok: true, message: 'Remail API 连接成功', ms: Date.now() - started, detail: { projects: data.total ?? data.items?.length ?? 0 } };
}

/** Remail 钱包/余额信息 */
export interface RemailWallet {
  userId?: number;
  consumerBalance?: string;
  supplierAvailable?: string;
  supplierFrozen?: string;
  totalRecharged?: string;
  historicalSpend?: string;
  orderCount?: number;
  updatedAt?: string;
}

/** 项目内某个产品的单价 */
export interface RemailProductPrice {
  type: string;
  codePrice: number;
  purchasePrice: number;
  suffixes: string[];
}

export async function getRemailWallet(settings: RemailSettings): Promise<RemailWallet> {
  return request(settings, '/v1/open/wallet') as Promise<RemailWallet>;
}

export async function listRemailProductPrices(settings: RemailSettings): Promise<RemailProductPrice[]> {
  const data = (await listRemailProjects(settings)) as { items?: any[] };
  const project = (data?.items || []).find((p) => Number(p.id) === Number(settings.projectId));
  const prices: RemailProductPrice[] = (project?.products || []).map((p: any) => ({
    type: String(p?.type || ''),
    codePrice: Number(p?.codePrice) || 0,
    purchasePrice: Number(p?.purchasePrice) || 0,
    suffixes: (p?.suffixes || []).map((s: any) => String(s?.suffix || ''))
  }));
  // icloud 产品的 suffixes 后端返回为空，但实际有 icloud.com 后缀，手动补上
  for (const price of prices) {
    if (price.type === 'icloud' && price.suffixes.length === 0) {
      price.suffixes = ['icloud.com'];
    }
  }
  return prices;
}

/** 根据 emailSuffix 匹配产品类型，返回对应模式的单价；找不到返回 0 */
export function resolveRemailUnitPrice(settings: RemailSettings, prices: RemailProductPrice[]): number {
  const suffix = settings.emailSuffix.trim().toLowerCase();
  const product = prices.find((p) => p.suffixes.some((s) => s.toLowerCase() === suffix));
  if (!product) return 0;
  return settings.serviceMode === 'purchase' ? product.purchasePrice : product.codePrice;
}

/** 批量下单（逐笔调用，避免服务端幂等冲突），返回订单数组 */
export async function createRemailOrders(settings: RemailSettings, count: number): Promise<unknown[]> {
  const results: unknown[] = [];
  for (let i = 0; i < count; i++) {
    results.push(await createRemailOrder(settings));
  }
  return results;
}
