import express, { type Request, type Response } from 'express';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { existsSync, promises as fsp } from 'node:fs';
import { WebSocket, WebSocketServer } from 'ws';

import type { RegisterStartArgs, SystemHealth, SystemHealthCheck } from '@shared/ipc';
import type { AppSettings, Grok2apiSettings } from '@shared/settings';
import type { RunEvent, PaymentPayload } from '@shared/runEvents';
import { loadSettings, saveSettings, dataDir } from './settingsStore.js';
import { registerBot } from './bot/registerBot.js';
import { gptBot } from './gpt/gptBot.js';
import { listAccounts } from './accountStore.js';
import { checkForUpdate, currentVersion } from './updateCheck.js';
import {
  checkAuthUpdate,
  getAuthUpdateDetail,
  downloadAuthUpdatePackage,
  listDownloadedUpdatePackages,
  applyAuthUpdatePackage
} from './authUpdate.js';
import { fetchEmails, extractVerificationCode, fetchLatestCodeByAddress, createTempEmail } from './api/emailApi.js';
import { cloudflareMailStore } from './cloudflareMailStore.js';
import {
  createRemailOrder,
  createRemailOrders,
  getRemailMessage,
  getRemailOrder,
  getRemailWallet,
  listRemailOrders,
  listRemailProductPrices,
  listRemailProjects,
  listRemailResources,
  maskApiKey,
  pickupRemail,
  resolveRemailUnitPrice,
  testRemail
} from './remailApi.js';
import { checkSso } from './ssoCheck.js';
import { manualCodeStore } from './manualCodeStore.js';
import { manualEmailStore } from './manualEmailStore.js';
import { fetchGrok2apiSsoTokens, testGrok2api, uploadSsoTokensToGrok2api } from './grok2apiApi.js';
import { fetchSubscription, testNodeLatency, type ProxyNode } from './proxyApi.js';
import {
  authBootstrapInfo,
  changeCredentials,
  getAuthState,
  getAuthStateFromCookie,
  login,
  logout
} from './authStore.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 6657);
const HOST = process.env.BIND_HOST || '0.0.0.0';
const STATIC_ROOT = resolve(
  process.env.STATIC_ROOT || join(__dirname, '..', '..', '..', '..', 'out', 'renderer')
);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

app.use((_req, res, next) => {
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

async function requireApiAuth(req: Request, res: Response, next: () => void) {
  const state = await getAuthState(req);
  if (state.authenticated) {
    next();
    return;
  }
  res.status(401).json({ error: 'unauthorized' });
}

app.get('/api/auth/me', async (req, res) => {
  res.json(await getAuthState(req));
});

app.post('/api/auth/login', async (req, res) => {
  const state = await login(req, res);
  if (!state) {
    res.status(401).json({ error: '用户名或密码不正确' });
    return;
  }
  res.json(state);
});

app.post('/api/auth/logout', async (req, res) => {
  await logout(req, res);
  res.json({ ok: true });
});

app.post('/api/auth/change', async (req, res) => {
  try {
    res.json(await changeCredentials(req, req.body));
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(message === 'unauthorized' ? 401 : 400).json({ error: message });
  }
});

// 手动验证码取码接口（供 Python 注册脚本免登录访问，使用 token 校验）
app.get('/api/manual-code/next', async (req, res) => {
  try {
    const token = String(req.query.token || '');
    if (!(await manualCodeStore.verifyToken(token))) {
      res.status(401).json({ error: 'invalid token' });
      return;
    }
    const seconds = Math.min(Math.max(Number(req.query.timeout) || 30, 1), 120);
    const code = await manualCodeStore.dequeue(seconds * 1000);
    res.json({ code });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 手动邮箱取件接口（供 Python 注册脚本免登录访问，使用 token 校验，复用同一 token）
app.get('/api/manual-email/next', async (req, res) => {
  try {
    const token = String(req.query.token || '');
    if (!(await manualEmailStore.verifyToken(token))) {
      res.status(401).json({ error: 'invalid token' });
      return;
    }
    const seconds = Math.min(Math.max(Number(req.query.timeout) || 30, 1), 120);
    const email = await manualEmailStore.dequeue(seconds * 1000);
    res.json({ email });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// Cloudflare 邮箱池取件接口（供 Python 注册脚本免登录访问，使用 token 校验）
app.get('/api/manual-email/cloudflare/next', async (req, res) => {
  try {
    const token = String(req.query.token || '');
    if (!(await manualEmailStore.verifyToken(token))) {
      res.status(401).json({ error: 'invalid token' });
      return;
    }
    const seconds = Math.min(Math.max(Number(req.query.timeout) || 30, 1), 120);
    const item = await cloudflareMailStore.dequeue(seconds * 1000);
    if (item) {
      res.json({ address: item.address, jwt: item.jwt, domain: item.domain });
    } else {
      res.json({ address: null, jwt: null, domain: null });
    }
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

app.use('/api', requireApiAuth);

// 手动验证码提交与状态（需登录）
app.post('/api/manual-code', async (req, res) => {
  const code = String(req.body?.code || '').trim();
  if (!code) {
    res.status(400).json({ error: '缺少验证码' });
    return;
  }
  await manualCodeStore.enqueue(code);
  res.json({ ok: true, queueLength: manualCodeStore.count() });
});

app.get('/api/manual-code/status', async (_req, res) => {
  res.json({ queueLength: manualCodeStore.count() });
});

// 手动邮箱：提交与状态（需登录）
app.post('/api/manual-email', async (req, res) => {
  const email = String(req.body?.email || '').trim();
  if (!email) {
    res.status(400).json({ error: '缺少邮箱地址' });
    return;
  }
  await manualEmailStore.enqueue(email);
  res.json({ ok: true, queueLength: manualEmailStore.count() });
});

app.get('/api/manual-email/status', async (_req, res) => {
  res.json({ queueLength: manualEmailStore.count() });
});

// Cloudflare 可用邮箱后缀列表（需登录）
app.get('/api/mail/cloudflare/domains', async (_req, res) => {
  try {
    const settings = await loadSettings();
    const mail = settings.mail;
    let domains: string[] = [];
    if (Array.isArray(mail.domains) && mail.domains.length > 0) {
      domains = mail.domains
        .map((d) => String(d || '').trim())
        .filter((d) => !!d && !d.includes('@'));
    }
    // 兼容旧配置：domain 支持逗号分隔
    if (domains.length === 0 && mail.domain) {
      domains = String(mail.domain)
        .split(/[,，\s]+/)
        .map((d) => d.trim())
        .filter((d) => !!d && !d.includes('@'));
    }
    res.json({ suffixes: domains });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// Cloudflare 生成临时邮箱并入池（需登录）
app.post('/api/mail/cloudflare/generate', async (req: Request, res: Response) => {
  try {
    const settings = await loadSettings();
    const mail = settings.mail;
    const domain = String((req.body as { domain?: string } | undefined)?.domain || '').trim() || mail.domain;
    if (!mail.apiBase || !mail.adminAuth) {
      res.status(400).json({ ok: false, error: '未配置 Cloudflare 邮箱后端（apiBase / adminAuth）' });
      return;
    }
    if (!domain) {
      res.status(400).json({ ok: false, error: '缺少邮箱后缀' });
      return;
    }
    const created = await createTempEmail({ apiBase: mail.apiBase, adminAuth: mail.adminAuth, domain });
    if (!created.address || !created.jwt) {
      res.status(400).json({ ok: false, error: 'Cloudflare 邮箱后端返回不完整' });
      return;
    }
    await cloudflareMailStore.enqueue({
      address: created.address,
      jwt: created.jwt,
      domain,
      createdAt: new Date().toISOString()
    });
    res.json({ ok: true, address: created.address, domain, poolCount: cloudflareMailStore.count() });
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

// Cloudflare 邮箱池状态（需登录）
app.get('/api/mail/cloudflare/pool', async (_req, res) => {
  const items = cloudflareMailStore.list();
  res.json({
    poolCount: cloudflareMailStore.count(),
    items: items.map((x) => ({ address: x.address, domain: x.domain, createdAt: x.createdAt }))
  });
});

// grok2api：测试连接（可带配置覆盖）
app.post('/api/grok2api/test', async (req, res) => {
  try {
    const settings = await loadSettings();
    const override = (req.body ?? {}) as Partial<Grok2apiSettings>;
    res.json(await testGrok2api({ ...settings.grok2api, ...override }));
  } catch (err) {
    res.status(400).json({ ok: false, message: err instanceof Error ? err.message : String(err) });
  }
});

// grok2api：已上传的 sso 集合（供号池页标记 已上传/待上传）
app.get('/api/grok2api/uploaded-tokens', async (_req, res) => {
  try {
    const settings = await loadSettings();
    const tokens = await fetchGrok2apiSsoTokens(settings.grok2api);
    res.json({ tokens });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 代理管理：拉取订阅解析
app.post('/api/proxy/subscription/parse', async (req, res) => {
  try {
    const { url, type, name } = req.body ?? {};
    const result = await fetchSubscription(String(url || ''), String(type || 'clash'));
    const settings = await loadSettings();
    const pc = settings.proxyConfig;
    const subs = pc.subscriptions.filter((s) => s.url !== String(url));
    subs.push({
      name: String(name || result.name),
      url: String(url),
      type: type === 'v2ray' ? 'v2ray' : 'clash',
      nodeCount: result.nodes.length
    });
    const oldNodes = pc.parsedNodes.filter((n) => n.source !== 'subscription');
    const newNodes = result.nodes.map((n) => ({ ...n, source: 'subscription' as const }));
    pc.subscriptions = subs;
    pc.parsedNodes = [...oldNodes, ...newNodes];
    await saveSettings(settings);
    res.json({ ok: true, nodeCount: newNodes.length, nodeList: newNodes });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 代理管理：两级延迟测试（本机→节点、节点→grok）
app.post('/api/proxy/test-latency', async (req, res) => {
  try {
    const node = req.body as ProxyNode;
    const { nodeLatency, grokLatency } = await testNodeLatency(node);
    res.json({ nodeLatency, grokLatency });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 代理管理：保存手动代理 / 解析节点
app.post('/api/proxy/save-manual', async (req, res) => {
  try {
    const body = req.body ?? {};
    const settings = await loadSettings();
    if (Array.isArray(body.manualProxies)) settings.proxyConfig.manualProxies = body.manualProxies;
    if (Array.isArray(body.parsedNodes)) settings.proxyConfig.parsedNodes = body.parsedNodes;
    await saveSettings(settings);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 代理管理：保存选中代理（写回 proxy，供注册脚本使用）
app.post('/api/proxy/save-selection', async (req, res) => {
  try {
    const { source, name, mode, applyTo } = req.body ?? {};
    const settings = await loadSettings();
    settings.proxyConfig.selectedSource =
      source === 'manual' ? 'manual' : source === 'subscription' ? 'subscription' : 'none';
    settings.proxyConfig.selectedName = String(name || '');
    settings.proxyConfig.selectionMode =
      mode === 'random' ? 'random' : mode === 'round-robin' ? 'round-robin' : mode === 'none' ? 'none' : 'fixed';
    settings.proxyConfig.applyTo =
      applyTo === 'register' ? 'register' : applyTo === 'sso' ? 'sso' : 'both';
    // 选择“不使用代理”时必须清空所有已写回的代理，避免残留旧代理
    if (settings.proxyConfig.selectedSource === 'none') {
      settings.proxy = '';
      settings.browserProxy = '';
      settings.ssoProxy = '';
    }
    // 固定模式：按作用范围写回 proxy / ssoProxy
    if (settings.proxyConfig.selectionMode === 'fixed') {
      const node = settings.proxyConfig.parsedNodes.find(
        (n) => n.name === settings.proxyConfig.selectedName
      );
      if (node) {
        const auth =
          node.username && node.password
            ? `${encodeURIComponent(node.username)}:${encodeURIComponent(node.password)}@`
            : '';
        const proxyUrl = `${node.type}://${auth}${node.server}:${node.port}`;
        if (settings.proxyConfig.applyTo !== 'sso') {
          settings.proxy = proxyUrl;
          settings.browserProxy = proxyUrl;
        }
        if (settings.proxyConfig.applyTo !== 'register') {
          settings.ssoProxy = proxyUrl;
        }
      }
    }
    await saveSettings(settings);
    res.json({
      ok: true,
      selectedSource: settings.proxyConfig.selectedSource,
      selectedName: settings.proxyConfig.selectedName,
      selectionMode: settings.proxyConfig.selectionMode,
      applyTo: settings.proxyConfig.applyTo,
      proxy: settings.proxy
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// grok2api：一键上传号池账号（accountIds 为空=全部）
app.post('/api/grok2api/upload', async (req, res) => {
  try {
    const body = (req.body ?? {}) as { accountIds?: string[]; provider?: string };
    const settings = await loadSettings();
    const accounts = await listAccounts();
    const ids = Array.isArray(body.accountIds) ? new Set(body.accountIds) : null;
    const selected = ids ? accounts.filter((a) => ids.has(a.id)) : accounts;
    const ssoTokens = selected.map((a) => a.sso).filter((t): t is string => !!t);
    const grokSettings: Grok2apiSettings = {
      ...settings.grok2api,
      provider: (body.provider as Grok2apiSettings['provider']) || settings.grok2api.provider
    };
    res.json(await uploadSsoTokensToGrok2api(grokSettings, ssoTokens));
  } catch (err) {
    res.status(400).json({ ok: false, message: err instanceof Error ? err.message : String(err) });
  }
});

app.get('/api/settings', async (_req, res) => {
  res.json(await loadSettings());
});

app.put('/api/settings', async (req: Request, res: Response) => {
  const body = req.body as AppSettings;
  await saveSettings(body);
  res.json({ ok: true });
});

app.get('/api/system/health', async (_req, res) => {
  res.json(await buildSystemHealth());
});

app.get('/api/system/version', (_req, res) => {
  res.json({ current: currentVersion() });
});

// 更新检查：优先走授权系统源；未启用/未配置时回退 GitHub
app.get('/api/system/update-check', async (_req, res) => {
  const settings = await loadSettings();
  const cfg = settings.authUpdate;
  const authConfigured = cfg?.enabled && cfg.server?.trim() && cfg.apiKey?.trim();
  if (authConfigured) {
    res.json(await checkAuthUpdate());
    return;
  }
  res.json(await checkForUpdate());
});

// 授权系统：获取指定版本详情（含下载链接）
app.post('/api/system/update/detail', async (req: Request, res: Response) => {
  const versionCode = Number((req.body as { versionCode?: number } | undefined)?.versionCode || 0);
  res.json(await getAuthUpdateDetail(versionCode));
});

// 授权系统：下载完整更新包到 /data/updates/
app.post('/api/system/update/download', async (req: Request, res: Response) => {
  try {
    const versionCode = Number((req.body as { versionCode?: number } | undefined)?.versionCode || 0);
    res.json(await downloadAuthUpdatePackage({ versionCode }));
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

// 授权系统：列出已下载的更新包
app.get('/api/system/update/packages', async (_req, res) => {
  try {
    res.json(await listDownloadedUpdatePackages());
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

// 授权系统：应用更新（解压覆盖代码 → 重启服务）
app.post('/api/system/update/apply', async (req: Request, res: Response) => {
  try {
    const versionCode = Number((req.body as { versionCode?: number } | undefined)?.versionCode || 0);
    const result = await applyAuthUpdatePackage({ versionCode });
    if (!result.ok) {
      res.status(400).json(result);
      return;
    }
    res.json({ ...result, restarting: true });
    // 稍后触发进程退出；容器 restart 策略会自动重启并加载新代码
    setTimeout(() => {
      console.log(`[grok-reg-tool] update applied (${result.versionName}), restarting...`);
      void shutdown('UPDATE').catch(() => process.exit(0));
    }, 1200);
  } catch (err) {
    res.status(400).json({ ok: false, error: err instanceof Error ? err.message : String(err) });
  }
});

app.get('/api/run/status', async (_req, res) => {
  res.json(registerBot.getStatus());
});

app.post('/api/run/start', async (req: Request, res: Response) => {
  try {
    const args = (req.body ?? {}) as RegisterStartArgs;
    res.json(await registerBot.start({ runCountOverride: args.runCount }));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/run/stop', async (_req, res) => {
  await registerBot.stop();
  res.json({ ok: true });
});

// ===== GPT 注册机 =====
app.get('/api/gpt/state', async (_req, res) => {
  res.json(gptBot.getState());
});

app.post('/api/gpt/start', async (req, res) => {
  try {
    const args = (req.body ?? {}) as { runCount?: number };
    res.json(await gptBot.start({ runCountOverride: args.runCount }));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/gpt/stop', async (_req, res) => {
  await gptBot.stop();
  res.json({ ok: true });
});

app.post('/api/gpt/link/extract', async (_req, res) => {
  try {
    res.json(await gptBot.extractLink());
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/gpt/link/manual', async (req, res) => {
  const url = String((req.body as { url?: string } | undefined)?.url || '').trim();
  if (!gptBot.setManualLink(url).ok) {
    res.status(400).json({ error: '缺少支付链接' });
    return;
  }
  res.json({ ok: true });
});

app.post('/api/gpt/payment/inspect', async (_req, res) => {
  try {
    res.json(await gptBot.startPayment());
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/gpt/payment/fill', async (req, res) => {
  try {
    res.json(await gptBot.fillPayment((req.body ?? {}) as PaymentPayload));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/gpt/payment/submit', async (_req, res) => {
  try {
    res.json(await gptBot.confirmSubmit());
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/gpt/payment/cancel', async (_req, res) => {
  gptBot.cancel();
  res.json({ ok: true });
});

app.get('/api/accounts', async (_req, res) => {
  res.json(await listAccounts());
});

app.get('/api/mail/code', async (req: Request, res: Response) => {
  const address = String(req.query.address || '').trim();
  if (!address) {
    res.status(400).json({ error: '缺少邮箱地址' });
    return;
  }
  const settings = await loadSettings();
  const result = await fetchLatestCodeByAddress(
    address,
    { apiBase: settings.mail.apiBase, adminAuth: settings.mail.adminAuth },
    settings.proxy
  );
  res.json(result);
});

app.post('/api/sso/check', async (req: Request, res: Response) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (items.length === 0) {
    res.status(400).json({ error: '缺少待验活的 sso 列表' });
    return;
  }
  const settings = await loadSettings();
  const proxy = settings.ssoProxy || settings.proxy;

  // 限并发 5，避免对 grok 发起过多并发请求
  const CONCURRENCY = 5;
  const results: unknown[] = [];
  for (let i = 0; i < items.length; i += CONCURRENCY) {
    const batch = items.slice(i, i + CONCURRENCY) as { id: string; sso: string }[];
    const settled = await Promise.all(
      batch.map(async (item) => {
        const outcome = await checkSso(item.sso, proxy);
        return { id: item.id, ...outcome, checkedAt: new Date().toISOString() };
      })
    );
    results.push(...settled);
  }
  res.json({ results });
});

app.post('/api/verify-code', async (req, res) => {
  try {
    const jwt = req.body.jwt;
    if (!jwt) throw new Error("缺少 jwt");
    const settings = await loadSettings();
    if (!settings.mail?.apiBase) throw new Error("缺少邮箱后端地址配置");
    const emails = await fetchEmails(jwt, settings.mail.apiBase, 10);
    let code = null;
    for (const msg of emails) {
      if (msg && msg.raw) {
        code = extractVerificationCode(msg.raw);
        if (code) break;
      }
    }
    res.json({ code: code?.replace('-', '') || null });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/test/mail', async (req, res) => {
  try {
    const { apiBase, adminAuth, domain } = req.body;
    if (!apiBase || !adminAuth || !domain) {
      return res.json({ ok: false, message: '缺少邮箱后端配置参数' });
    }
    
    const response = await fetch(`${apiBase}/api/mails?limit=1`, {
      method: 'GET'
    });
    
    if (response.status === 401 || response.status === 200) {
      return res.json({ ok: true, message: '邮箱服务器连接成功' });
    } else {
      return res.json({ ok: false, message: `服务器返回了异常状态码: ${response.status}` });
    }
  } catch (e: any) {
    return res.json({ ok: false, message: `连接失败: ${e.message}` });
  }
});

app.get('/api/remail/test', async (_req, res) => {
  try {
    const settings = (await loadSettings()).remail;
    res.json(await testRemail(settings));
  } catch (err) {
    res.status(400).json({ ok: false, message: err instanceof Error ? err.message : String(err) });
  }
});

app.get('/api/remail/projects', async (_req, res) => {
  try { res.json(await listRemailProjects((await loadSettings()).remail)); }
  catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.get('/api/remail/resources', async (_req, res) => {
  try { res.json(await listRemailResources((await loadSettings()).remail)); }
  catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.get('/api/remail/orders', async (_req, res) => {
  try { res.json(await listRemailOrders((await loadSettings()).remail)); }
  catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.get('/api/remail/orders/:orderNo', async (req, res) => {
  try { res.json(await getRemailOrder((await loadSettings()).remail, String(req.params.orderNo))); }
  catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.post('/api/remail/orders', async (req, res) => {
  try {
    const input = req.body ?? {};
    const settings = await loadSettings();
    const grokSettings = {
      ...settings.remail,
      projectId: Number(input.projectId),
      emailSuffix: String(input.emailSuffix || ''),
      serviceMode: (input.serviceMode === 'purchase' ? 'purchase' : 'code') as 'code' | 'purchase'
    };
    const count = Number.isInteger(input.count) ? Number(input.count) : 1;
    if (count < 1 || count > 50) {
      res.status(400).json({ error: '批量数量必须在 1 到 50 之间' });
      return;
    }
    if (count === 1) {
      res.status(201).json(await createRemailOrder(grokSettings));
    } else {
      const items = await createRemailOrders(grokSettings, count);
      res.status(201).json({ count, items });
    }
  } catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.get('/api/remail/wallet', async (_req, res) => {
  try {
    res.json(await getRemailWallet((await loadSettings()).remail));
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

app.get('/api/remail/pricing', async (_req, res) => {
  try {
    const settings = (await loadSettings()).remail;
    const prices = await listRemailProductPrices(settings);
    const unitPrice = resolveRemailUnitPrice(settings, prices);
    res.json({
      prices,
      unitPrice,
      projectId: settings.projectId,
      serviceMode: settings.serviceMode,
      emailSuffix: settings.emailSuffix
    });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : String(err) });
  }
});

app.get('/api/remail/pickup', async (req, res) => {
  try {
    const email = String(req.query.email || '');
    const token = String(req.query.token || '');
    const data = await pickupRemail((await loadSettings()).remail, email, token);
    res.json(data);
  } catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

app.get('/api/remail/pickup/:messageId', async (req, res) => {
  try {
    const messageId = Number(req.params.messageId);
    const email = String(req.query.email || '');
    const token = String(req.query.token || '');
    if (!Number.isInteger(messageId) || messageId < 1) throw new Error('messageId 无效');
    res.json(await getRemailMessage((await loadSettings()).remail, messageId, email, token));
  } catch (err) { res.status(400).json({ error: err instanceof Error ? err.message : String(err) }); }
});

if (existsSync(STATIC_ROOT)) {
  app.use(express.static(STATIC_ROOT, { index: 'index.html' }));
  app.get(/^\/(?!api).*/, (_req, res) => {
    res.sendFile(join(STATIC_ROOT, 'index.html'));
  });
} else {
  app.get('/', (_req, res) => {
    res
      .status(503)
      .type('text/plain')
      .send(
        `Web UI not built.\nRun \`npm run server:build\` to produce ${STATIC_ROOT}.\nAPI is still online at /api.`
      );
  });
}

const httpServer = createServer(app);
const wss = new WebSocketServer({ noServer: true });
const clients = new Set<WebSocket>();

function sendEvent(ws: WebSocket, event: RunEvent) {
  if (ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify(event));
}

function broadcast(event: RunEvent) {
  for (const ws of clients) {
    sendEvent(ws, event);
  }
}

registerBot.on('event', (event: RunEvent) => {
  broadcast(event);
});

gptBot.on('event', (event: RunEvent) => {
  broadcast(event);
});

wss.on('connection', (ws) => {
  clients.add(ws);
  for (const event of registerBot.getReplay()) {
    sendEvent(ws, event);
  }
  for (const event of gptBot.getReplay()) {
    sendEvent(ws, event);
  }
  ws.on('close', () => {
    clients.delete(ws);
  });
});

httpServer.on('upgrade', async (request, socket, head) => {
  const pathname = (() => {
    try {
      return new URL(request.url || '/', 'http://localhost').pathname;
    } catch {
      return '/';
    }
  })();

  if (pathname !== '/ws') {
    socket.destroy();
    return;
  }

  const state = await getAuthStateFromCookie(request.headers.cookie);
  if (!state.authenticated) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }

  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

httpServer.listen(PORT, HOST, () => {
  console.log(`[grok-reg-tool] listening on http://${HOST}:${PORT}`);
  console.log(`[grok-reg-tool] data dir: ${dataDir()}`);
  console.log(
    `[grok-reg-tool] static UI: ${existsSync(STATIC_ROOT) ? STATIC_ROOT : '(not built)'}`
  );
  void authBootstrapInfo().then((info) => {
    console.log(`[grok-reg-tool] default account: ${info.defaultUsername}`);
    console.log(`[grok-reg-tool] default password: ${info.defaultPassword}`);
    if (info.mustChangePassword) {
      console.log('[grok-reg-tool] first login must change username/password');
    } else {
      console.log(`[grok-reg-tool] web account configured: ${info.username}`);
    }
  });
});

async function buildSystemHealth(): Promise<SystemHealth> {
  const checks: SystemHealthCheck[] = [];
  const pushCheck = (check: SystemHealthCheck) => checks.push(check);

  pushCheck(await checkRegisterScript());
  pushCheck(await checkDataDirWritable());

  const summary = checks.reduce(
    (acc, check) => {
      acc[check.level] += 1;
      acc.total += 1;
      return acc;
    },
    { ok: 0, warn: 0, error: 0, total: 0 }
  );

  return {
    checkedAt: new Date().toISOString(),
    summary,
    checks
  };
}

async function checkRegisterScript(): Promise<SystemHealthCheck> {
  const settings = await loadSettings();
  const registerDir = registerBot.resolveRegisterDir(settings.registerDir);
  const scriptPath = registerDir ? join(registerDir, 'runner.py') : '';
  const legacyScriptPath = registerDir ? join(registerDir, 'DrissionPage_example.py') : '';
  if ((scriptPath && existsSync(scriptPath)) || (legacyScriptPath && existsSync(legacyScriptPath))) {
    return {
      id: 'register-script',
      label: 'Python 注册机',
      level: 'ok',
      message: '注册脚本已就绪',
      detail: existsSync(scriptPath) ? scriptPath : legacyScriptPath
    };
  }
  return {
    id: 'register-script',
    label: 'Python 注册机',
    level: 'warn',
    message: '未找到内置注册脚本，请检查镜像或项目 register/ 目录',
    detail: settings.registerDir || process.env.REGISTER_DIR || '(未配置 registerDir)'
  };
}

async function checkDataDirWritable(): Promise<SystemHealthCheck> {
  const targetDir = dataDir();
  const probeFile = join(targetDir, `.health-${Date.now()}.tmp`);
  try {
    await fsp.mkdir(targetDir, { recursive: true });
    await fsp.writeFile(probeFile, 'ok', 'utf-8');
    await fsp.unlink(probeFile);
    return {
      id: 'data-dir',
      label: '数据目录',
      level: 'ok',
      message: '数据目录可写',
      detail: targetDir
    };
  } catch (err) {
    return {
      id: 'data-dir',
      label: '数据目录',
      level: 'error',
      message: '数据目录不可写',
      detail: err instanceof Error ? err.message : String(err)
    };
  }
}

async function shutdown(sig: string) {
  console.log(`[grok-reg-tool] received ${sig}, stopping...`);
  await registerBot.stop().catch(() => undefined);
  wss.close();
  httpServer.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 8000).unref();
}

process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
