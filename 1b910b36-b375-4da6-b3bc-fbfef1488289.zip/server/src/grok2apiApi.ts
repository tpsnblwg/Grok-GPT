/**
 * grok2api 管理 API 客户端（当前版本协议）。
 * 支持：管理登录（JWT）→ multipart 文件上传账号 → 解析 SSE 导入结果。
 * 参考 grok2api 源码：
 *   - POST {apiBase}/api/admin/v1/auth/login  -> data.tokens.accessToken
 *   - POST {apiBase}/api/admin/v1/accounts/{web/console}/import 或 /accounts/import
 *   - 上传为 multipart（字段 files/file），响应为 SSE（event: complete）
 */
import type { Grok2apiSettings } from '@shared/settings';

export interface Grok2apiUploadResult {
  ok: boolean;
  message: string;
  detail?: {
    created?: number;
    updated?: number;
    skipped?: number;
    synced?: number;
    syncFailed?: number;
  };
}

function baseUrl(value: string): string {
  return value.trim().replace(/\/+$/, '');
}

function normalizeSettings(partial?: Partial<Grok2apiSettings>): Grok2apiSettings {
  return {
    apiBase: partial?.apiBase || '',
    username: partial?.username || '',
    password: partial?.password || '',
    provider: partial?.provider || 'web'
  };
}

export async function grok2apiLogin(settings: Grok2apiSettings): Promise<{ accessToken: string }> {
  const cfg = normalizeSettings(settings);
  if (!cfg.apiBase.trim()) throw new Error('缺少 grok2api 地址');
  if (!cfg.username.trim() || !cfg.password) throw new Error('缺少 grok2api 管理账号/密码');

  const res = await fetch(`${baseUrl(cfg.apiBase)}/api/admin/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: cfg.username, password: cfg.password }),
    signal: AbortSignal.timeout(15000)
  });

  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = (body as any)?.error?.message || `HTTP ${res.status}`;
    throw new Error(`grok2api 登录失败: ${message}`);
  }
  const accessToken = (body as any)?.data?.tokens?.accessToken;
  if (!accessToken) throw new Error('grok2api 登录响应缺少 accessToken');
  return { accessToken };
}

function providerImportPath(provider: string): string {
  switch (provider) {
    case 'console':
      return '/api/admin/v1/accounts/console/import';
    case 'build':
      return '/api/admin/v1/accounts/import';
    case 'web':
    default:
      return '/api/admin/v1/accounts/web/import';
  }
}

export async function uploadSsoTokensToGrok2api(
  settings: Grok2apiSettings,
  ssoTokens: string[]
): Promise<Grok2apiUploadResult> {
  const cfg = normalizeSettings(settings);
  const tokens = (ssoTokens || [])
    .map((t) => String(t || '').trim())
    .filter(Boolean);
  if (tokens.length === 0) {
    return { ok: false, message: '没有可上传的 SSO' };
  }

  const { accessToken } = await grok2apiLogin(cfg);

  // 纯 SSO 文本：每行一个 token。grok2api 会自动清洗 sso= 前缀、; 之后的残留和空白。
  const text = tokens.join('\n') + '\n';
  const form = new FormData();
  form.append(
    'files',
    new Blob([text], { type: 'text/plain' }),
    `grok-reg-tool-sso-${Date.now()}.txt`
  );

  const res = await fetch(`${baseUrl(cfg.apiBase)}${providerImportPath(cfg.provider)}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` },
    body: form,
    signal: AbortSignal.timeout(120000)
  });

  if (!res.ok) {
    let message = `HTTP ${res.status}`;
    try {
      const body = await res.json();
      message = (body as any)?.error?.message || message;
    } catch {
      /* ignore */
    }
    throw new Error(`grok2api 上传失败: ${message}`);
  }

  const sseText = await res.text();
  const detail = parseImportSse(sseText);
  return {
    ok: true,
    message: `上传完成：新建 ${detail.created ?? 0} / 更新 ${detail.updated ?? 0} / 跳过 ${detail.skipped ?? 0} / 同步 ${detail.synced ?? 0} / 同步失败 ${detail.syncFailed ?? 0}`,
    detail
  };
}

function parseImportSse(text: string): NonNullable<Grok2apiUploadResult['detail']> {
  const detail: NonNullable<Grok2apiUploadResult['detail']> = {};
  const lines = String(text || '').split('\n');
  for (const line of lines) {
    if (!line.startsWith('data:')) continue;
    const payload = line.slice(5).trim();
    if (!payload) continue;
    try {
      const obj = JSON.parse(payload) as Record<string, unknown>;
      if (obj && typeof obj === 'object') {
        if (typeof obj.created === 'number') detail.created = obj.created;
        if (typeof obj.updated === 'number') detail.updated = obj.updated;
        if (typeof obj.skipped === 'number') detail.skipped = obj.skipped;
        if (typeof obj.synced === 'number') detail.synced = obj.synced;
        if (typeof obj.syncFailed === 'number') detail.syncFailed = obj.syncFailed;
      }
    } catch {
      /* ignore */
    }
  }
  return detail;
}

export async function testGrok2api(
  settings: Grok2apiSettings
): Promise<{ ok: boolean; message: string; ms: number }> {
  const started = Date.now();
  try {
    await grok2apiLogin(settings);
    return {
      ok: true,
      message: `grok2api 连接成功（管理员 ${settings.username || '-'}）`,
      ms: Date.now() - started
    };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : String(err),
      ms: Date.now() - started
    };
  }
}

/**
 * 获取 grok2api 中已存在的 sso token 集合。
 * 通过导出接口返回的凭据文件解析（含 sso_token / token 字段）。
 */
export async function fetchGrok2apiSsoTokens(settings: Grok2apiSettings): Promise<string[]> {
  const cfg = normalizeSettings(settings);
  const { accessToken } = await grok2apiLogin(cfg);
  // grok-reg-tool 用 web/build/console，grok2api 用 grok_web/grok_build/grok_console
  const providerMap: Record<string, string> = {
    web: 'grok_web',
    build: 'grok_build',
    console: 'grok_console'
  };
  const provider = providerMap[cfg.provider || 'web'] || 'grok_web';
  const res = await fetch(
    `${baseUrl(cfg.apiBase)}/api/admin/v1/accounts/export?provider=${encodeURIComponent(provider)}`,
    { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(60000) }
  );
  if (!res.ok) throw new Error(`grok2api 导出账号失败: HTTP ${res.status}`);
  const text = await res.text();
  const tokens: string[] = [];
  try {
    const data = JSON.parse(text) as any;
    const accounts = Array.isArray(data?.accounts)
      ? data.accounts
      : Array.isArray(data)
        ? data
        : [];
    for (const a of accounts) {
      const t = a?.sso_token || a?.token || a?.sso || a?.accessToken;
      if (t) tokens.push(String(t).trim().replace(/^sso=/, ''));
    }
  } catch {
    for (const line of String(text || '').split('\n')) {
      const t = line.trim().replace(/^sso=/, '');
      if (t) tokens.push(t);
    }
  }
  return tokens;
}
