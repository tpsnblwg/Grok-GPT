import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { AppSettings } from '@shared/settings';
import { manualCodeStore } from '../manualCodeStore.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const REGISTER_SCRIPT_NAMES = ['runner.py', 'DrissionPage_example.py'] as const;

type RuntimeSettings = Partial<AppSettings>;

export interface RegisterRuntime {
  registerDir: string;
  scriptPath: string;
  entrypoint: string;
  pythonPath: string;
}

function addCandidate(candidates: string[], value?: string) {
  const normalized = normalizeRegisterPath(value);
  if (!normalized) return;

  const key = process.platform === 'win32' ? normalized.toLowerCase() : normalized;
  const exists = candidates.some((item) => {
    const itemKey = process.platform === 'win32' ? item.toLowerCase() : item;
    return itemKey === key;
  });
  if (!exists) candidates.push(normalized);
}

function normalizeRegisterPath(value?: string): string {
  const trimmed = String(value || '').trim();
  if (!trimmed) return '';

  const resolved = path.resolve(trimmed);
  const basename = path.basename(resolved);
  if (REGISTER_SCRIPT_NAMES.includes(basename as (typeof REGISTER_SCRIPT_NAMES)[number])) {
    return path.dirname(resolved);
  }

  return resolved;
}

export function findRegisterScript(registerDir: string): string | null {
  for (const name of REGISTER_SCRIPT_NAMES) {
    const scriptPath = path.join(registerDir, name);
    if (fs.existsSync(scriptPath)) return scriptPath;
  }
  return null;
}

export function buildRegisterDirCandidates(configured?: string): string[] {
  const candidates: string[] = [];

  addCandidate(candidates, configured);
  addCandidate(candidates, process.env.REGISTER_DIR);

  // 内置注册机优先，旧的 grok-register 外部目录只作为本地兼容回退。
  addCandidate(candidates, '/app/register');
  addCandidate(candidates, path.resolve(process.cwd(), 'register'));
  addCandidate(candidates, path.resolve(__dirname, '..', '..', '..', 'register'));
  addCandidate(candidates, path.resolve(__dirname, '..', '..', '..', '..', 'register'));
  addCandidate(candidates, path.resolve(__dirname, '..', '..', '..', '..', '..', 'register'));
  addCandidate(candidates, path.resolve(process.cwd(), 'grok-register'));
  addCandidate(candidates, path.resolve(process.cwd(), '..', 'grok-register'));
  addCandidate(candidates, path.resolve(process.cwd(), '..', 'grok-register-main'));

  return candidates;
}

export function resolveRegisterRuntime(settings: RuntimeSettings = {}): RegisterRuntime | null {
  for (const registerDir of buildRegisterDirCandidates(settings.registerDir)) {
    const scriptPath = findRegisterScript(registerDir);
    if (!scriptPath) continue;

    return {
      registerDir,
      scriptPath,
      entrypoint: path.basename(scriptPath),
      pythonPath:
        settings.pythonPath ||
        process.env.PYTHON_PATH ||
        (process.platform === 'win32' ? 'python' : '/usr/local/bin/python3')
    };
  }

  return null;
}

export async function writeConfigForPython(registerDir: string, settings: RuntimeSettings, count?: number) {
  const configPath = path.join(registerDir, 'config.json');
  let config: Record<string, any> = {};

  try {
    if (fs.existsSync(configPath)) {
      config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    }
  } catch {
    config = {};
  }

  config.mail_api_base = settings.mail?.apiBase || '';
  config.mail_admin_auth = settings.mail?.adminAuth || '';
  config.mail_domain = settings.mail?.domain || '';
  config.mail_domains = Array.isArray(settings.mail?.domains)
    ? settings.mail!.domains.map((d) => String(d || '').trim()).filter(Boolean)
    : [];
  config.mail_mode = settings.mail?.mode || 'auto';

  // 选择“不使用代理”时强制写入空代理，避免 settings 中残留旧代理泄漏到注册脚本
  if ((settings as RuntimeSettings & { proxyConfig?: { selectedSource?: string } })?.proxyConfig?.selectedSource === 'none') {
    config.proxy = '';
    config.browser_proxy = '';
  } else {
    config.proxy = settings.proxy || '';
    config.browser_proxy = settings.browserProxy || settings.proxy || '';
  }
  config.browser_path = settings.browserPath || '';

  if (typeof count === 'number') {
    config.run = { ...(config.run || {}), count };
  }

  // GPT 注册机专用配置（写入后由 register/gpt_register.py 读取）
  if ((settings as RuntimeSettings & { gpt?: any }).gpt) {
    const g = (settings as RuntimeSettings & { gpt?: any }).gpt!;
    config.gpt = {
      register_password: g.registerPassword || '',
      display_name: g.displayName || '',
      birth_date: g.birthDate || '',
      use_proxy: !!g.useProxy,
      proxy: g.proxy || '',
      payment: {
        extractMode: g.payment?.extractMode || 'manual',
        extractEndpoint: g.payment?.extractEndpoint || '',
        extractToken: g.payment?.extractToken || '',
        cdk: g.payment?.cdk || '',
        linkType: g.payment?.linkType || 'paypal',
        extractUrl: g.payment?.extractUrl || 'https://pay.153.ink/',
        entryProxy: g.payment?.entryProxy || '',
        exitProxy: g.payment?.exitProxy || '',
        retryCount: Number(g.payment?.retryCount) || 10,
        promoCampaign: g.payment?.promoCampaign || '',
        channel: g.payment?.channel || 'hosted',
        country: g.payment?.country || 'US',
        currency: g.payment?.currency || 'USD',
        plan: g.payment?.plan || 'plus',
        plusTrialCheck: g.payment?.plusTrialCheck !== false,
        tryPromo: !!g.payment?.tryPromo,
        useSentinel: g.payment?.useSentinel !== false,
        extractTimeout: Number(g.payment?.extractTimeout) || 120
      }
    };
  }

  // 手动验证码队列配置：注册脚本通过该地址/token 从 WebUI 取码（阻塞等待）
  config.manual_code_api = `http://127.0.0.1:${Number(process.env.PORT || 6657)}`;
  config.manual_code_token = await manualCodeStore.getToken();
  // 0=无限等待；>0 表示最多等 N 秒后回退邮箱轮询（由环境变量 MANUAL_CODE_WAIT 控制）
  config.manual_code_wait = Number(process.env.MANUAL_CODE_WAIT) > 0 ? Number(process.env.MANUAL_CODE_WAIT) : 0;

  // 手动邮箱队列配置：注册脚本从 WebUI 邮箱队列取 Remail 邮箱（阻塞等待，不自动扣费）
  config.manual_email_api = `http://127.0.0.1:${Number(process.env.PORT || 6657)}`;
  config.manual_email_token = await manualCodeStore.getToken();
  // 0=无限等待；>0 表示最多等 N 秒后回退旧邮件协议（由环境变量 MANUAL_EMAIL_WAIT 控制）
  config.manual_email_wait = Number(process.env.MANUAL_EMAIL_WAIT) > 0 ? Number(process.env.MANUAL_EMAIL_WAIT) : 0;

  fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
}
