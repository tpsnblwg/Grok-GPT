/**
 * 手动邮箱 FIFO 队列。
 * 用户在 WebUI 手动下单 Remail 后，把交付邮箱提交到本队列；
 * Python 注册脚本通过 HTTP 长轮询取邮箱（先进先出，阻塞等待）。
 * 取码接口 token 复用 manualCodeStore 的同一 token。
 */
import { manualCodeStore } from './manualCodeStore.js';

interface Waiter {
  resolve: (email: string) => void;
  timer: NodeJS.Timeout;
}

class ManualEmailStore {
  private queue: string[] = [];
  private waiters: Waiter[] = [];

  /** 入队一个邮箱，并唤醒最早一个等待者 */
  async enqueue(email: string): Promise<void> {
    const normalized = String(email || '').trim().toLowerCase();
    if (!normalized) return;
    this.queue.push(normalized);
    this.drain();
  }

  private drain(): void {
    while (this.queue.length > 0 && this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      if (!waiter) break;
      clearTimeout(waiter.timer);
      const email = this.queue.shift();
      if (email === undefined) break;
      waiter.resolve(email);
    }
  }

  /** 出队取一个邮箱；队列为空且 timeoutMs>0 时阻塞等待，超时返回 null */
  dequeue(timeoutMs = 0): Promise<string | null> {
    if (this.queue.length > 0) {
      return Promise.resolve(this.queue.shift() ?? null);
    }
    if (timeoutMs <= 0) {
      return Promise.resolve(null);
    }
    return new Promise<string | null>((resolve) => {
      let settled = false;
      const finish = (value: string | null) => {
        if (settled) return;
        settled = true;
        resolve(value);
      };
      const onEmail = (email: string) => {
        clearTimeout(timer);
        finish(email);
      };
      const timer = setTimeout(() => {
        const idx = this.waiters.findIndex((w) => w.resolve === onEmail);
        if (idx >= 0) this.waiters.splice(idx, 1);
        finish(null);
      }, timeoutMs);
      this.waiters.push({ resolve: onEmail, timer });
    });
  }

  count(): number {
    return this.queue.length;
  }

  async verifyToken(token?: string): Promise<boolean> {
    return manualCodeStore.verifyToken(token);
  }
}

export const manualEmailStore = new ManualEmailStore();
