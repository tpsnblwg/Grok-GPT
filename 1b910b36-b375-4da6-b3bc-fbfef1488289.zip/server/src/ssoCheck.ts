/**
 * SSO 验活：用 sso token 作 cookie 请求 grok.com 的用户信息接口。
 * 200 = 存活并返回账户信息；401/403 = 失效。请求走 settings.proxy。
 */
import { proxiedRequest } from './httpClient.js';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join } from 'node:path';

const execFileAsync = promisify(execFile);

const GET_USER_URL = 'https://grok.com/rest/auth/get-user';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export interface SsoCheckOutcome {
  alive: boolean;
  status: number;
  email?: string;
  givenName?: string;
  familyName?: string;
  emailConfirmed?: boolean;
  sessionTierId?: string;
  createTime?: string;
  quota?: Record<string, unknown> | null;
  error?: string;
}

export async function checkSso(sso: string, proxy?: string): Promise<SsoCheckOutcome> {
  const token = (sso || '').replace(/^sso=/, '').trim();
  if (!token) return { alive: false, status: 0, error: '缺少 sso token' };

  try {
    const res = await proxiedRequest(GET_USER_URL, {
      headers: {
        Cookie: `sso=${token}; sso-rw=${token}`,
        'User-Agent': UA,
        Accept: 'application/json'
      },
      proxy
    });

    // 任意状态：若返回 Cloudflare 挑战 HTML（可能 200 或 403），改用浏览器化验活
    if (typeof res.data === 'string') {
      const low = (res.data as string).slice(0, 2000).toLowerCase();
      if (low.includes('<html') || low.includes('challenge') || low.includes('just a moment')) {
        const browserResult = await browserSsoCheck(token, proxy);
        if (browserResult) return browserResult;
      }
    }

    if (res.status === 200) {
      const u = res.data as Record<string, unknown>;
      const quotaKeys = ['accountDetails', 'quota', 'limits', 'usage', 'modelAccess'];
      let quota: Record<string, unknown> | null = null;
      for (const k of quotaKeys) {
        if (u[k] !== undefined) {
          quota = { [k]: u[k] };
          break;
        }
      }
      return {
        alive: true,
        status: 200,
        email: typeof u.email === 'string' ? u.email : undefined,
        givenName: typeof u.givenName === 'string' ? u.givenName : undefined,
        familyName: typeof u.familyName === 'string' ? u.familyName : undefined,
        emailConfirmed: typeof u.emailConfirmed === 'boolean' ? u.emailConfirmed : undefined,
        sessionTierId: u.sessionTierId != null ? String(u.sessionTierId) : undefined,
        createTime: typeof u.createTime === 'string' ? u.createTime : undefined,
        quota
      };
    }

    if (res.status === 401 || res.status === 403) {
      return { alive: false, status: res.status };
    }

    return { alive: false, status: res.status, error: `grok 返回 HTTP ${res.status}` };
  } catch (e) {
    return { alive: false, status: 0, error: e instanceof Error ? e.message : String(e) };
  }
}

/** 浏览器化验活：被 CF 拦截时调用 Python 脚本（DrissionPage 打开 grok.com，拟人化处理 Turnstile） */
async function browserSsoCheck(sso: string, proxy?: string): Promise<SsoCheckOutcome | null> {
  const scriptDir = process.env.REGISTER_DIR || '/app/register';
  const py = process.env.PYTHON_PATH || '/usr/local/bin/python3';
  try {
    const { stdout } = await execFileAsync(
      py,
      ['-u', join(scriptDir, 'sso_browser_check.py'), '--sso', sso, '--proxy', proxy || ''],
      { timeout: 90000, maxBuffer: 1024 * 1024 }
    );
    const text = String(stdout || '').trim();
    if (!text) return null;
    const data = JSON.parse(text) as Record<string, unknown>;
    const quotaKeys = ['accountDetails', 'quota', 'limits', 'usage', 'modelAccess'];
    let quota: Record<string, unknown> | null = null;
    for (const k of quotaKeys) {
      if (data[k] !== undefined) {
        quota = { [k]: data[k] };
        break;
      }
    }
    return {
      alive: true,
      status: 200,
      email: typeof data.email === 'string' ? data.email : undefined,
      givenName: typeof data.givenName === 'string' ? data.givenName : undefined,
      familyName: typeof data.familyName === 'string' ? data.familyName : undefined,
      emailConfirmed: typeof data.emailConfirmed === 'boolean' ? data.emailConfirmed : undefined,
      sessionTierId: data.sessionTierId != null ? String(data.sessionTierId) : undefined,
      createTime: typeof data.createTime === 'string' ? data.createTime : undefined,
      quota
    };
  } catch {
    return null;
  }
}
