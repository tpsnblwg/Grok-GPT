/**
 * 授权系统（夏稚Auth Studio / xiazhiauth）在线更新模块。
 * 通过 Open API 检查更新、获取版本详情、下载并校验更新包。
 */
import { createHash } from 'node:crypto';
import { promises as fsp, existsSync, createWriteStream } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import AdmZip from 'adm-zip';
import type { UpdateInfo, AuthUpdatePackageInfo } from '@shared/ipc';
import { loadSettings, dataDir } from './settingsStore.js';
import { currentVersion } from './updateCheck.js';

/** 把 semver 版本号转换为授权系统 version_code（主*100+次*10+修订） */
export function semverToCode(v: string): number {
  const parts = v.replace(/^v/i, '').split('.');
  const major = parseInt(parts[0] ?? '0', 10) || 0;
  const minor = parseInt(parts[1] ?? '0', 10) || 0;
  const patch = parseInt(parts[2] ?? '0', 10) || 0;
  return major * 100 + minor * 10 + patch;
}

interface OpenApiVersionPackage {
  download_url?: string;
  sha256?: string;
  size_bytes?: number;
  url_expires_at?: string | null;
}

interface OpenApiVersionItem {
  version_id?: number;
  version_name?: string;
  version_code?: number;
  force_update?: boolean;
  update_log?: string | null;
  package?: OpenApiVersionPackage | null;
  update_package?: OpenApiVersionPackage | null;
}

interface OpenApiCheckResponse {
  update_available?: boolean;
  force_update?: boolean;
  current_version_code?: number;
  latest?: OpenApiVersionItem | null;
}

interface OpenApiGetResponse extends OpenApiVersionItem {}

function toPackageInfo(p?: OpenApiVersionPackage | null): AuthUpdatePackageInfo | null {
  if (!p) return null;
  if (!p.download_url) return null;
  return {
    downloadUrl: p.download_url,
    sha256: p.sha256 ?? '',
    sizeBytes: p.size_bytes,
    urlExpiresAt: p.url_expires_at ?? null
  };
}

async function openApiConfig() {
  const settings = await loadSettings();
  const cfg = settings.authUpdate;
  if (!cfg.enabled) {
    throw new Error('未启用授权系统在线更新，请在设置中开启');
  }
  if (!cfg.server.trim()) {
    throw new Error('未配置授权系统服务器地址');
  }
  if (!cfg.apiKey.trim()) {
    throw new Error('未配置 Open API 鉴权密钥');
  }
  return cfg;
}

async function openApiPost<T>(path: string, body: unknown): Promise<T> {
  const cfg = await openApiConfig();
  const base = cfg.server.replace(/\/+$/, '');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const resp = await fetch(`${base}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.apiKey}`
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!resp.ok) {
      throw new Error(`授权服务器返回 HTTP ${resp.status}`);
    }
    const data = (await resp.json()) as { code?: number; message?: string; data?: T };
    if (data.code !== 0) {
      throw new Error(data.message || '授权服务器返回错误');
    }
    if (data.data === undefined) {
      throw new Error('授权服务器响应缺少 data 字段');
    }
    return data.data;
  } finally {
    clearTimeout(timer);
  }
}

/** 检查授权系统是否有新版本 */
export async function checkAuthUpdate(): Promise<UpdateInfo> {
  const current = currentVersion();
  const base: UpdateInfo = {
    current,
    latest: null,
    hasUpdate: false,
    htmlUrl: null,
    publishedAt: null,
    source: 'auth'
  };
  try {
    const cfg = await openApiConfig();
    const currentCode = cfg.versionCode > 0 ? cfg.versionCode : semverToCode(current);
    const data = await openApiPost<OpenApiCheckResponse>('/api/v1/open/versions/check', {
      application_id: cfg.applicationId,
      current_version_code: currentCode,
      include_log: true
    });
    if (!data.update_available || !data.latest) {
      return {
        ...base,
        hasUpdate: false,
        htmlUrl: `${cfg.server.replace(/\/+$/, '')}/admin/applications`
      };
    }
    const latest = data.latest;
    return {
      ...base,
      hasUpdate: true,
      latest: latest.version_name ?? String(latest.version_code ?? ''),
      latestVersionName: latest.version_name ?? null,
      latestVersionCode: latest.version_code ?? null,
      forceUpdate: data.force_update ?? latest.force_update ?? false,
      updateLog: latest.update_log ?? null,
      package: toPackageInfo(latest.package),
      updatePackage: toPackageInfo(latest.update_package),
      htmlUrl: `${cfg.server.replace(/\/+$/, '')}/admin/applications`
    };
  } catch (err) {
    return {
      ...base,
      error: err instanceof Error ? err.message : String(err)
    };
  }
}

/** 获取授权系统指定版本的详情（含下载链接与哈希） */
export async function getAuthUpdateDetail(versionCode?: number): Promise<UpdateInfo> {
  const current = currentVersion();
  const base: UpdateInfo = {
    current,
    latest: null,
    hasUpdate: false,
    htmlUrl: null,
    publishedAt: null,
    source: 'auth'
  };
  try {
    const cfg = await openApiConfig();
    let targetCode = versionCode && versionCode > 0 ? versionCode : undefined;
    if (!targetCode) {
      // 未指定版本号：先通过 check 获取最新版本号
      const check = await openApiPost<OpenApiCheckResponse>('/api/v1/open/versions/check', {
        application_id: cfg.applicationId,
        current_version_code: cfg.versionCode > 0 ? cfg.versionCode : semverToCode(current),
        include_log: true
      });
      targetCode = check.latest?.version_code;
      if (!targetCode) {
        return { ...base, error: '授权系统暂无可获取的版本' };
      }
    }
    const data = await openApiPost<OpenApiGetResponse>('/api/v1/open/versions/get', {
      application_id: cfg.applicationId,
      version_code: targetCode
    });
    return {
      ...base,
      hasUpdate: true,
      latest: data.version_name ?? String(data.version_code ?? ''),
      latestVersionName: data.version_name ?? null,
      latestVersionCode: data.version_code ?? null,
      forceUpdate: data.force_update ?? false,
      updateLog: data.update_log ?? null,
      package: toPackageInfo(data.package),
      updatePackage: toPackageInfo(data.update_package),
      htmlUrl: `${cfg.server.replace(/\/+$/, '')}/admin/applications`
    };
  } catch (err) {
    return {
      ...base,
      error: err instanceof Error ? err.message : String(err)
    };
  }
}

async function downloadFile(url: string, dest: string, sha256?: string): Promise<void> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5 * 60 * 1000);
  try {
    const resp = await fetch(url, { signal: controller.signal });
    if (!resp.ok || !resp.body) {
      throw new Error(`下载失败：HTTP ${resp.status}`);
    }
    await pipeline(Readable.fromWeb(resp.body as never), createWriteStream(dest));
  } finally {
    clearTimeout(timer);
  }

  if (sha256) {
    const buf = await fsp.readFile(dest);
    const actual = createHash('sha256').update(buf).digest('hex');
    if (actual.toLowerCase() !== sha256.toLowerCase()) {
      await fsp.unlink(dest).catch(() => undefined);
      throw new Error(`SHA256 校验失败：期望 ${sha256.slice(0, 16)}...，实际 ${actual.slice(0, 16)}...`);
    }
  }
}

/** 下载完整更新包到持久数据目录 /data/updates/ */
export async function downloadAuthUpdatePackage(opts?: { versionCode?: number }): Promise<{
  ok: boolean;
  versionName: string | null;
  versionCode: number | null;
  fileName: string | null;
  filePath: string | null;
  sizeBytes: number | null;
  sha256: string | null;
  error?: string;
}> {
  const detail = await getAuthUpdateDetail(opts?.versionCode);
  if (detail.error) {
    return { ok: false, versionName: null, versionCode: null, fileName: null, filePath: null, sizeBytes: null, sha256: null, error: detail.error };
  }
  const pkg = detail.package ?? detail.updatePackage;
  if (!pkg?.downloadUrl) {
    return { ok: false, versionName: null, versionCode: null, fileName: null, filePath: null, sizeBytes: null, sha256: null, error: '授权系统未提供更新包下载地址' };
  }
  const versionName = detail.latestVersionName ?? detail.latest ?? 'update';
  const fileName = `${versionName}.zip`;
  const dir = resolve(dataDir(), 'updates');
  await fsp.mkdir(dir, { recursive: true });
  const filePath = join(dir, fileName);
  try {
    // download_url 可能是相对路径（如 /api/v1/public/version-downloads/...），需要拼接服务器地址
    let downloadUrl = pkg.downloadUrl;
    if (downloadUrl.startsWith('/')) {
      const cfg = await openApiConfig();
      downloadUrl = `${cfg.server.replace(/\/+$/, '')}${downloadUrl}`;
    }
    await downloadFile(downloadUrl, filePath, pkg.sha256 || undefined);
    const stat = await fsp.stat(filePath);
    return {
      ok: true,
      versionName,
      versionCode: detail.latestVersionCode ?? null,
      fileName,
      filePath,
      sizeBytes: stat.size,
      sha256: pkg.sha256 ?? null
    };
  } catch (err) {
    return {
      ok: false,
      versionName,
      versionCode: detail.latestVersionCode ?? null,
      fileName,
      filePath,
      sizeBytes: null,
      sha256: pkg.sha256 ?? null,
      error: err instanceof Error ? err.message : String(err)
    };
  }
}

/** 列出已下载的更新包 */
export async function listDownloadedUpdatePackages(): Promise<{
  dir: string;
  packages: { fileName: string; sizeBytes: number; modifiedAt: string }[];
}> {
  const dir = resolve(dataDir(), 'updates');
  await fsp.mkdir(dir, { recursive: true });
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  const packages: { fileName: string; sizeBytes: number; modifiedAt: string }[] = [];
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const full = join(dir, entry.name);
    const stat = await fsp.stat(full);
    packages.push({
      fileName: entry.name,
      sizeBytes: stat.size,
      modifiedAt: stat.mtime.toISOString()
    });
  }
  packages.sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt));
  return { dir, packages };
}

/** 判断本地是否存在已下载的指定版本包 */
export async function hasDownloadedPackage(versionName: string): Promise<boolean> {
  const dir = resolve(dataDir(), 'updates');
  if (!existsSync(dir)) return false;
  return existsSync(join(dir, `${versionName}.zip`));
}

/** 应用更新：解压更新包覆盖 /app 代码（容器内），返回结果并触发重启 */
export async function applyAuthUpdatePackage(opts?: { versionCode?: number }): Promise<{
  ok: boolean;
  versionName: string | null;
  versionCode: number | null;
  error?: string;
}> {
  const detail = await getAuthUpdateDetail(opts?.versionCode);
  if (detail.error) {
    return { ok: false, versionName: null, versionCode: null, error: detail.error };
  }
  const versionName = detail.latestVersionName ?? detail.latest ?? 'update';
  const versionCode = detail.latestVersionCode ?? null;
  const dir = resolve(dataDir(), 'updates');
  const zipPath = join(dir, `${versionName}.zip`);
  if (!existsSync(zipPath)) {
    return { ok: false, versionName, versionCode, error: `更新包不存在：${zipPath}，请先下载更新包` };
  }

  // 应用目录：容器内为 /app；本地开发时可被 APP_ROOT 覆盖
  const appRoot = resolve(process.env.APP_ROOT || '/app');
  const tmpDir = await fsp.mkdtemp(join(tmpdir(), 'grok-apply-'));
  try {
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(tmpDir, true);

    // 校验更新包必须包含运行关键文件
    const required = ['package.json', 'server/dist', 'out'];
    for (const rel of required) {
      if (!existsSync(join(tmpDir, rel))) {
        return { ok: false, versionName, versionCode, error: `更新包内容不完整，缺少 ${rel}` };
      }
    }

    // 备份当前运行版本关键文件（备份到 /data/backups/）
    const backupDir = resolve(dataDir(), 'backups', `pre-${versionName}-${Date.now()}`);
    await fsp.mkdir(backupDir, { recursive: true });
    for (const item of ['package.json', 'server', 'out', 'register', 'src', 'docker']) {
      const srcPath = join(appRoot, item);
      if (existsSync(srcPath)) {
        await fsp.cp(srcPath, join(backupDir, item), { recursive: true, force: true });
      }
    }

    // 覆盖运行代码（保留 node_modules，不覆盖 docker/data）
    for (const item of ['package.json', 'server', 'out', 'register', 'src', 'docker']) {
      const srcPath = join(tmpDir, item);
      const destPath = join(appRoot, item);
      if (existsSync(srcPath)) {
        await fsp.cp(srcPath, destPath, { recursive: true, force: true });
      }
    }

    return { ok: true, versionName, versionCode };
  } catch (err) {
    return {
      ok: false,
      versionName,
      versionCode,
      error: `应用更新失败：${err instanceof Error ? err.message : String(err)}`
    };
  } finally {
    await fsp.rm(tmpDir, { recursive: true, force: true }).catch(() => undefined);
  }
}
